#include "Luau/Compiler.h"

#include "Luau/Ast.h"
#include "Luau/BytecodeBuilder.h"
#include "Luau/Common.h"
#include "Luau/Parser.h"
#include "Luau/InsertionOrderedMap.h"
#include "Luau/StringUtils.h"
#include "Luau/TimeTrace.h"

#include "Builtins.h"
#include "ConstantFolding.h"
#include "CostModel.h"
#include "TableShape.h"
#include "Types.h"
#include "Utils.h"
#include "ValueTracking.h"

#include <algorithm>
#include <array>
#include <bitset>

#include <math.h>
#include <stdlib.h>

LUAU_FASTINTVARIABLE(LuauCompileLoopUnrollThreshold, 25)
LUAU_FASTINTVARIABLE(LuauCompileLoopUnrollThresholdMaxBoost, 300)

LUAU_FASTINTVARIABLE(LuauCompileInlineThreshold, 25)
LUAU_FASTINTVARIABLE(LuauCompileInlineThresholdMaxBoost, 300)
LUAU_FASTINTVARIABLE(LuauCompileInlineDepth, 5)

LUAU_FASTFLAG(LuauExportValueSyntax)
LUAU_FASTFLAGVARIABLE(LuauCompileMoveElision)
LUAU_FASTFLAGVARIABLE(LuauCompileCleanBlockDeadClose)
LUAU_FASTFLAGVARIABLE(LuauCompileLoopUnrollZero)
LUAU_FASTFLAG(LuauIntegerType2)
LUAU_FASTFLAGVARIABLE(LuauCompileConcatTargetTop)
LUAU_FASTFLAG(LuauCompileRefactorFeedback)
LUAU_FASTFLAG(DebugLuauNoInline)
LUAU_FASTFLAG(LuauEmitCallFeedback)
LUAU_FASTFLAGVARIABLE(LuauOptimizeExportTable)
LUAU_FASTFLAG(LuauCompileFastpcall)
LUAU_FASTFLAGVARIABLE(LuauExportedTypesParticipateInScc)
LUAU_FLAGVERSION(LuauExportedTypesParticipateInScc, 2)
LUAU_FASTFLAG(LuauExperimentalIfLocalSyntax)
LUAU_FASTFLAGVARIABLE(LuauCompileReuseLocalRegs)

namespace Luau
{

using namespace Luau::Compile;

static const uint32_t kDefaultAllocPc = ~0u;

void escapeAndAppend(std::string& buffer, const char* str, size_t len)
{
    if (memchr(str, '%', len))
    {
        for (size_t characterIndex = 0; characterIndex < len; ++characterIndex)
        {
            char character = str[characterIndex];
            buffer.push_back(character);

            if (character == '%')
                buffer.push_back('%');
        }
    }
    else
        buffer.append(str, len);
}

CompileError::CompileError(const Location& location, std::string message)
    : location(location)
    , message(std::move(message))
{
}

CompileError::~CompileError() throw() {}

const char* CompileError::what() const throw()
{
    return message.c_str();
}

const Location& CompileError::getLocation() const
{
    return location;
}

LUAU_NOINLINE void CompileError::raise(const Location& location, const char* format, ...)
{
    va_list args;
    va_start(args, format);
    std::string message = vformat(format, args);
    va_end(args);

    throw CompileError(location, message);
}

static BytecodeBuilder::StringRef sref(AstName name)
{
    LUAU_ASSERT(name.value);
    return {name.value, strlen(name.value)};
}

static BytecodeBuilder::StringRef sref(AstArray<char> data)
{
    LUAU_ASSERT(data.data);
    return {data.data, data.size};
}

static BytecodeBuilder::StringRef sref(AstArray<const char> data)
{
    LUAU_ASSERT(data.data);
    return {data.data, data.size};
}

struct Compiler
{
    struct RegScope;

    Compiler(BytecodeBuilder& bytecode, const CompileOptions& options, AstNameTable& names)
        : bytecode(bytecode)
        , options(options)
        , builtinTypes(options.vectorType)
        , names(names)
        , exports(AstLocal(names.getOrAdd("__EXP"), Location(), nullptr, 0, 0, nullptr, true))
    {

        localStack.reserve(16);
        upvals.reserve(16);
    }

    void checkConstant(int32_t constant, const Location& location)
    {
        if (constant < 0)
            CompileError::raise(location, "Exceeded constant limit; simplify the code to compile");
    }

    int getLocalReg(AstLocal* local)
    {
        Local* l = locals.find(local);

        return l && l->allocated ? l->reg : -1;
    }

    uint8_t getUpval(AstLocal* local)
    {
        for (size_t uid = 0; uid < upvals.size(); ++uid)
            if (upvals[uid] == local)
                return uint8_t(uid);

        if (upvals.size() >= kMaxUpvalueCount)
            CompileError::raise(
                local->location, "Out of upvalue registers when trying to allocate %s: exceeded limit %d", local->name.value, kMaxUpvalueCount
            );

        Variable* v = variables.find(local);

        if (v && v->written)
        {
            if (FFlag::LuauCompileMoveElision)
            {
                Local& l = locals[local];
                l.captured = true;

                if (l.allocated)
                    regCaptured[l.reg] = true;
            }
            else
            {
                locals[local].captured = true;
            }
        }

        upvals.push_back(local);

        return uint8_t(upvals.size() - 1);
    }

    bool atTopLevel() const
    {
        return currentFunction != nullptr && currentFunction->functionDepth == 0 && blockDepth == 0 && loops.empty();
    }

    void checkExportedLocal(AstLocal* local, const Location& location)
    {
        if (local->isExported)
        {
            if (!atTopLevel())
            {

                CompileError::raise(location, "'export' may only be applied to top-level statements");
            }
        }
    }

    void ensureExportTable(AstNode* node)
    {
        exports.hasExports = true;

        if (locals.contains(&exports.exportTableLocal))
            return;

        LUAU_ASSERT(atTopLevel());

        uint8_t tableReg = allocReg(node, 1u);
        if (FFlag::LuauOptimizeExportTable && exports.exportedTableCid != -1 && exports.exportedTableCid < 32768)
        {
            bytecode.emitAD(LOP_DUPTABLE, tableReg, static_cast<int16_t>(exports.exportedTableCid));
        }
        else
        {
            bytecode.emitABC(LOP_NEWTABLE, tableReg, encodeHashSize(0), 0);
            bytecode.emitAux(0);
        }

        pushLocal(&exports.exportTableLocal, tableReg, kDefaultAllocPc);
    }

    uint8_t getExportTableReg(AstNode* node)
    {
        if (int reg = getLocalReg(&exports.exportTableLocal); reg >= 0)
            return uint8_t(reg);

        uint8_t upval = getUpval(&exports.exportTableLocal);
        uint8_t reg = allocReg(node, 1u);
        bytecode.emitABC(LOP_GETUPVAL, reg, upval, 0);
        return reg;
    }

    void buildExportTableShape()
    {
        LUAU_ASSERT(FFlag::LuauOptimizeExportTable);

        BytecodeBuilder::TableShape exportedShape;

        if (exports.exportedVariables.size() >= BytecodeBuilder::TableShape::kMaxLength)
            return;

        for (const auto& exportedLocal : exports.exportedVariables)
        {
            Variable* variable = variables.find(exportedLocal);

            if (variable == nullptr)
            {
                CompileError::raise(exportedLocal->location, "Local does not have corresponding variable");
                continue;
            }

            int32_t keyCid = bytecode.addConstantString(sref(exportedLocal->name));
            if (keyCid < 0)

                return;

            size_t idx = exportedShape.length;
            exportedShape.keys[idx] = keyCid;
            exportedShape.constants[idx] = -1;
            if (variable->constant && !variable->written)
            {
                int32_t valueCid = getConstantIndex(variable->init);

                if (valueCid < 0)
                    return;

                exportedShape.constants[idx] = valueCid;
                exportedShape.hasConstants = true;
            }
            exportedShape.length++;
        }

        if (exportedShape.length > 0)
            exports.exportedTableCid = bytecode.addConstantTable(exportedShape);
    }

    bool alwaysTerminates(AstStat* node) const
    {
        return Compile::alwaysTerminates(constants, node);
    }

    void emitLoadK(uint8_t target, int32_t cid)
    {
        LUAU_ASSERT(cid >= 0);

        if (cid < 32768)
        {
            bytecode.emitAD(LOP_LOADK, target, int16_t(cid));
        }
        else
        {
            bytecode.emitAD(LOP_LOADKX, target, 0);
            bytecode.emitAux(cid);
        }
    }

    AstExpr* tryIndexConstantTable(AstExprIndexName* expr)
    {

        AstExprLocal* tableLocal = unwrapExprOfType<AstExprLocal>(expr->expr);
        if (!tableLocal)
            return nullptr;

        Variable* lv = variables.find(tableLocal->local);
        if (!lv || lv->written || !lv->init)
            return nullptr;

        TableConstantKind* tableKind = tableConstants.find(tableLocal->local);
        if (!tableKind || *tableKind != ConstantTable)
            return nullptr;

        AstExprTable* table = unwrapExprOfType<AstExprTable>(lv->init);
        if (!table)
            return nullptr;

        AstExpr* match = nullptr;

        for (const AstExprTable::Item& item : table->items)
        {
            if (item.kind == AstExprTable::Item::Kind::Record || item.kind == AstExprTable::Item::Kind::General)
            {
                Constant* keyConstant = constants.find(item.key);

                if (!keyConstant)
                {
                    match = nullptr;
                }
                else if (keyConstant->type == Constant::Type_String && keyConstant->stringLength != 0)
                {
                    AstName keyName = names.getOrAdd(keyConstant->valueString, keyConstant->stringLength);

                    if (keyName == expr->index)
                        match = item.value;
                }
            }
        }

        return match;
    }

    AstExprFunction* getFunctionExpr(AstExpr* node)
    {
        if (AstExprLocal* expr = node->as<AstExprLocal>())
        {
            Variable* lv = variables.find(expr->local);

            if (!lv || lv->written || !lv->init)
                return nullptr;

            return getFunctionExpr(lv->init);
        }
        else if (AstExprIndexName* expr = node->as<AstExprIndexName>())
        {
            if (AstExpr* value = tryIndexConstantTable(expr))
                return getFunctionExpr(value);

            return nullptr;
        }
        else if (AstExprGroup* expr = node->as<AstExprGroup>())
            return getFunctionExpr(expr->expr);
        else if (AstExprTypeAssertion* expr = node->as<AstExprTypeAssertion>())
            return getFunctionExpr(expr->expr);
        else if (AstExprInstantiate* expr = node->as<AstExprInstantiate>())
            return getFunctionExpr(expr->expr);
        else
            return node->as<AstExprFunction>();
    }

    void compileExportTable()
    {
        LUAU_ASSERT(currentFunction);

        AstExprFunction* locNode = currentFunction;
        int8_t tableReg;

        if (!exports.isEmpty())
        {

            ensureExportTable(currentFunction);

            tableReg = getLocalReg(&exports.exportTableLocal);
            LUAU_ASSERT(tableReg >= 0);

            if (FFlag::DebugLuauUserDefinedClasses)
            {
                for (auto& [classLocal, classReg] : exports.exportedClasses)
                {
                    BytecodeBuilder::StringRef classNameRef = sref(classLocal->name);
                    int32_t classNameCid = bytecode.addConstantString(classNameRef);
                    if (classNameCid < 0)
                        CompileError::raise(locNode->location, "Exceeded constant limit; simplify the code to compile");

                    bytecode.emitABC(LOP_SETTABLEKS, classReg, tableReg, uint8_t(BytecodeBuilder::getStringHash(classNameRef)));
                    bytecode.emitAux(classNameCid);
                }
            }

            if (FFlag::LuauOptimizeExportTable)
            {
                for (auto& funcLocal : exports.exportedFunctions)
                {
                    int32_t cid = bytecode.addConstantString(sref(funcLocal->name));
                    if (cid < 0)
                        CompileError::raise(funcLocal->location, "Exceeded constant limit; simplify the code to compile");

                    uint8_t funcReg = getLocalReg(funcLocal);

                    bytecode.emitABC(LOP_SETTABLEKS, funcReg, tableReg, uint8_t(BytecodeBuilder::getStringHash(sref(funcLocal->name))));
                    bytecode.emitAux(cid);
                }
            }
        }
        else
        {

            LUAU_ASSERT(FFlag::LuauExportedTypesParticipateInScc);
            LUAU_ASSERT(exports.hasTypeExports);

            tableReg = allocReg(locNode, 1u);
            bytecode.emitABC(LOP_NEWTABLE, tableReg, encodeHashSize(0), 0);
            bytecode.emitAux(0);
        }

        uint8_t freezeReg = allocReg(locNode, 2u);
        AstName freezeName = names.getOrAdd("freeze");
        int32_t freezeCid = bytecode.addConstantString(sref(freezeName));
        if (freezeCid < 0)
            CompileError::raise(locNode->location, "Exceeded constant limit; simplify the code to compile");

        AstName tableName = names.getOrAdd("table");
        int32_t tableCid = bytecode.addConstantString(sref(tableName));
        if (tableCid < 0)
            CompileError::raise(locNode->location, "Exceeded constant limit; simplify the code to compile");

        bool getGlobalFallback = true;
        if (tableCid < 1024 && freezeCid < 1024)
        {
            uint32_t iid = BytecodeBuilder::getImportId(tableCid, freezeCid);
            int32_t cid = bytecode.addImport(iid);
            if (cid >= 0 && cid < 32768)
            {
                bytecode.emitAD(LOP_GETIMPORT, freezeReg, int16_t(cid));
                bytecode.emitAux(iid);
                getGlobalFallback = false;
            }
        }

        if (getGlobalFallback)
        {
            bytecode.emitABC(LOP_GETGLOBAL, freezeReg, 0, uint8_t(BytecodeBuilder::getStringHash(sref(tableName))));
            bytecode.emitAux(tableCid);

            bytecode.emitABC(LOP_GETTABLEKS, freezeReg, freezeReg, uint8_t(BytecodeBuilder::getStringHash(sref(freezeName))));
            bytecode.emitAux(freezeCid);
        }

        bytecode.emitABC(LOP_MOVE, uint8_t(freezeReg + 1), tableReg, 0);
        bytecode.emitABC(LOP_CALL, freezeReg, 2, 2);

        closeLocals(0);
        bytecode.emitABC(LOP_RETURN, freezeReg, 2, 0);
    }

    uint32_t compileFunction(AstExprFunction* func, uint8_t& protoflags)
    {
        LUAU_TIMETRACE_SCOPE("Compiler::compileFunction", "Compiler");

        if (func->debugname.value)
            LUAU_TIMETRACE_ARGUMENT("name", func->debugname.value);

        LUAU_ASSERT(!functions.contains(func));
        LUAU_ASSERT(regTop == 0 && stackSize == 0 && localStack.empty() && upvals.empty());
        if (FFlag::LuauExportValueSyntax)
            currentFunction = func;

        if (FFlag::LuauExportValueSyntax && FFlag::LuauOptimizeExportTable && atTopLevel())
            buildExportTableShape();

        RegScope rs(this);

        bool self = func->self != 0;
        uint32_t fid = bytecode.beginFunction(uint8_t(self + func->args.size), func->vararg);

        setDebugLine(func);

        if (func->vararg)
            bytecode.emitABC(LOP_PREPVARARGS, uint8_t(self + func->args.size), 0, 0);

        uint8_t args = allocReg(func, self + unsigned(func->args.size));

        if (func->self)
            pushLocal(func->self, args, kDefaultAllocPc);

        for (size_t i = 0; i < func->args.size; ++i)
            pushLocal(func->args.data[i], uint8_t(args + self + i), kDefaultAllocPc);

        argCount = localStack.size();

        AstStatBlock* stat = func->body;

        bool terminatesEarly = false;
        Location terminationLocation;
        currentFunction = func;

        if (FFlag::DebugLuauUserDefinedClasses && atTopLevel())
            preallocateHoistedClasses(stat);

        for (size_t i = 0; i < stat->body.size; ++i)
        {
            AstStat* bodyStat = stat->body.data[i];

            if (FFlag::LuauCompileReuseLocalRegs)
                popStatLocals(stat, bodyStat, 0u);

            compileStat(bodyStat);

            if (alwaysTerminates(bodyStat))
            {
                terminatesEarly = true;
                break;
            }
        }

        if (FFlag::LuauExportValueSyntax)
        {
            setDebugLineEnd(stat);

            if (!exports.isEmpty() && atTopLevel())
            {
                compileExportTable();
            }
            else if (FFlag::LuauExportedTypesParticipateInScc && exports.hasTypeExports && !terminatesEarly && atTopLevel())
            {
                compileExportTable();
            }
            else
            {
                if (!terminatesEarly)
                {
                    closeLocals(0);

                    bytecode.emitABC(LOP_RETURN, 0, 1, 0);
                }
            }
        }
        else
        {
            if (!terminatesEarly)
            {
                setDebugLineEnd(stat);
                closeLocals(0);

                bytecode.emitABC(LOP_RETURN, 0, 1, 0);
            }
        }

        if (options.optimizationLevel >= 1 && options.debugLevel >= 2)
            gatherConstUpvals(func);

        bytecode.setDebugFunctionLineDefined(func->location.begin.line + 1);

        if (options.debugLevel >= 1 && func->debugname.value)
            bytecode.setDebugFunctionName(sref(func->debugname));

        if (options.debugLevel >= 2 && !upvals.empty())
        {
            for (AstLocal* l : upvals)
                bytecode.pushDebugUpval(sref(l->name));
        }

        if (options.typeInfoLevel >= 1)
        {
            for (AstLocal* l : upvals)
            {
                LuauBytecodeType ty = LBC_TYPE_ANY;

                if (LuauBytecodeType* recordedTy = localTypes.find(l))
                    ty = *recordedTy;

                bytecode.pushUpvalTypeInfo(ty);
            }
        }

        if (options.optimizationLevel >= 1)
            bytecode.foldJumps();

        bool hasLongJumpError = false;
        bytecode.expandJumps(hasLongJumpError);

        if (hasLongJumpError)
            CompileError::raise(func->location, "Exceeded jump distance limit; simplify the code to compile");

        popLocals(0);

        if (bytecode.getInstructionCount() > kMaxInstructionCount)
            CompileError::raise(func->location, "Exceeded function instruction limit; split the function into parts to compile");

        if (std::string* funcType = functionTypes.find(func))
            bytecode.setFunctionTypeInfo(std::move(*funcType));

        if (func->functionDepth == 0 && !hasLoops)
            protoflags |= LPF_NATIVE_COLD;

        if (func->hasNativeAttribute())
            protoflags |= LPF_NATIVE_FUNCTION;

        if (FFlag::LuauExportValueSyntax && !exports.isEmpty() && func->functionDepth == 0)
            protoflags |= LPF_USES_EXPORT;

        if (FFlag::LuauExportedTypesParticipateInScc && exports.hasTypeExports && !terminatesEarly && func->functionDepth == 0)
            protoflags |= LPF_USES_EXPORT;

        bool isInlinable = !hasMultiRet && !getfenvUsed && !setfenvUsed;
        uint64_t costModel = 0;
        if (FFlag::LuauEmitCallFeedback && isInlinable && upvals.empty())
        {
            protoflags |= LPF_INLINABLE;
            costModel = modelCost(func->body, func->args.data, func->args.size, builtins, constants);
        }

        bytecode.endFunction(uint8_t(stackSize), uint8_t(upvals.size()), protoflags, costModel);

        Function& f = functions[func];
        f.id = fid;
        f.upvals = upvals;

        if (options.optimizationLevel >= 2 && !func->vararg && !func->self && !getfenvUsed && !setfenvUsed)
        {
            if (FFlag::DebugLuauNoInline && func->hasAttribute(AstAttr::Type::DebugNoinline))
            {
                f.canInline = false;
            }
            else
            {
                f.canInline = true;
            }
            f.stackSize = stackSize;
            f.costModel = costModel == 0 ? modelCost(func->body, func->args.data, func->args.size, builtins, constants) : costModel;

            if (alwaysTerminates(func->body))
            {
                ReturnVisitor returnVisitor(this, func);
                stat->visit(&returnVisitor);
                f.returnsOne = returnVisitor.returnsOne;

                if (FFlag::LuauCompileMoveElision)
                {
                    f.returnKind = returnVisitor.returnKind;
                    f.returnLocal = returnVisitor.returnLocal;

                    if (f.returnLocal)
                    {
                        if (Local* lc = locals.find(f.returnLocal); lc && lc->captured)
                            f.returnLocalCaptured = true;
                    }
                }
            }
        }

        upvals.clear();
        stackSize = 0;

        if (FFlag::LuauCompileReuseLocalRegs)
            freeLocalRegs.clear();

        argCount = 0;

        hasLoops = false;
        hasMultiRet = false;
        currentFunction = nullptr;

        return fid;
    }

    bool isExprMultRet(AstExpr* node)
    {
        AstExprCall* expr = node->as<AstExprCall>();
        if (!expr)
            return node->is<AstExprVarargs>();

        if (options.optimizationLevel <= 1)
            return true;

        if (isConstant(expr))
            return false;

        if (options.optimizationLevel >= 2)
        {
            if (int* bfid = builtins.find(expr); bfid && *bfid != LBF_NONE)
                return getBuiltinInfo(*bfid).results != 1;
        }

        AstExprFunction* func = getFunctionExpr(expr->func);
        Function* fi = func ? functions.find(func) : nullptr;

        if (fi && fi->returnsOne)
            return false;

        return true;
    }

    bool compileExprTempMultRet(AstExpr* node, uint8_t target)
    {
        if (AstExprCall* expr = node->as<AstExprCall>())
        {

            if (options.optimizationLevel >= 2 && !isExprMultRet(node))
            {
                compileExprTemp(node, target);
                return false;
            }

            RegScope rs(this, target);
            compileExprCall(expr, target, 0, true, true);
            return true;
        }
        else if (AstExprVarargs* expr = node->as<AstExprVarargs>())
        {

            RegScope rs(this, target);
            compileExprVarargs(expr, target, 0, true);
            return true;
        }
        else
        {
            compileExprTemp(node, target);
            return false;
        }
    }

    void compileExprTempTop(AstExpr* node, uint8_t target)
    {

        RegScope rs(this, target + 1);
        compileExprTemp(node, target);
    }

    void compileExprVarargs(AstExprVarargs* expr, uint8_t target, uint8_t targetCount, bool multRet = false)
    {
        LUAU_ASSERT(targetCount < 255);
        LUAU_ASSERT(!multRet || unsigned(target + targetCount) == regTop);

        setDebugLine(expr);

        bytecode.emitABC(LOP_GETVARARGS, target, multRet ? 0 : uint8_t(targetCount + 1), 0);
    }

    void compileExprSelectVararg(AstExprCall* expr, uint8_t target, uint8_t targetCount, bool targetTop, bool multRet, uint8_t regs)
    {
        LUAU_ASSERT(targetCount == 1);
        LUAU_ASSERT(!expr->self);
        LUAU_ASSERT(expr->args.size == 2 && expr->args.data[1]->is<AstExprVarargs>());

        AstExpr* arg = expr->args.data[0];

        uint8_t argreg;

        if (int reg = getExprLocalReg(arg); reg >= 0)
            argreg = uint8_t(reg);
        else
        {
            argreg = uint8_t(regs + 1);
            compileExprTempTop(arg, argreg);
        }

        size_t fastcallLabel = bytecode.emitLabel();

        bytecode.emitABC(LOP_FASTCALL1, LBF_SELECT_VARARG, argreg, 0);

        compileExprTemp(expr->func, regs);

        if (argreg != regs + 1)
            bytecode.emitABC(LOP_MOVE, uint8_t(regs + 1), argreg, 0);

        bytecode.emitABC(LOP_GETVARARGS, uint8_t(regs + 2), 0, 0);

        size_t callLabel = bytecode.emitLabel();
        if (!bytecode.patchSkipC(fastcallLabel, callLabel))
            CompileError::raise(expr->func->location, "Exceeded jump distance limit; simplify the code to compile");

        bytecode.emitABC(LOP_CALL, regs, 0, multRet ? 0 : uint8_t(targetCount + 1));

        if (!targetTop)
        {
            for (size_t i = 0; i < targetCount; ++i)
                bytecode.emitABC(LOP_MOVE, uint8_t(target + i), uint8_t(regs + i), 0);
        }
    }

    void compileExprFastcallN(
        AstExprCall* expr,
        uint8_t target,
        uint8_t targetCount,
        bool targetTop,
        bool multRet,
        uint8_t regs,
        int bfid,
        int bfK = -1
    )
    {
        LUAU_ASSERT(!expr->self);
        LUAU_ASSERT(expr->args.size >= 1);
        LUAU_ASSERT(expr->args.size <= 3);
        LUAU_ASSERT(bfid == LBF_BIT32_EXTRACTK ? bfK >= 0 : bfK < 0);
        LUAU_ASSERT(targetCount < 255);

        LuauOpcode opc = LOP_NOP;

        if (expr->args.size == 1)
            opc = LOP_FASTCALL1;
        else if (bfK >= 0 || (expr->args.size == 2 && isConstant(expr->args.data[1])))
            opc = LOP_FASTCALL2K;
        else if (expr->args.size == 2)
            opc = LOP_FASTCALL2;
        else
            opc = LOP_FASTCALL3;

        uint32_t args[3] = {};

        for (size_t i = 0; i < expr->args.size; ++i)
        {
            if (i > 0 && opc == LOP_FASTCALL2K)
            {
                int32_t cid = getConstantIndex(expr->args.data[i]);
                if (cid < 0)
                    CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

                args[i] = cid;
            }
            else if (int reg = getExprLocalReg(expr->args.data[i]); reg >= 0)
            {
                args[i] = uint8_t(reg);
            }
            else
            {
                args[i] = uint8_t(regs + 1 + i);

                if (FFlag::LuauCompileMoveElision)
                {

                    RegScope rs(this, args[i] + 1);
                    args[i] = compileExprAutoTemp(expr->args.data[i], uint8_t(args[i]));
                }
                else
                {
                    compileExprTempTop(expr->args.data[i], uint8_t(args[i]));
                }
            }
        }

        size_t fastcallLabel = bytecode.emitLabel();

        bytecode.emitABC(opc, uint8_t(bfid), uint8_t(args[0]), 0);

        if (opc == LOP_FASTCALL3)
        {
            LUAU_ASSERT(bfK < 0);
            bytecode.emitAux(args[1] | (args[2] << 8));
        }
        else if (opc != LOP_FASTCALL1)
        {
            bytecode.emitAux(bfK >= 0 ? bfK : args[1]);
        }

        for (size_t i = 0; i < expr->args.size; ++i)
        {
            if (i > 0 && opc == LOP_FASTCALL2K)
                emitLoadK(uint8_t(regs + 1 + i), args[i]);
            else if (args[i] != regs + 1 + i)
                bytecode.emitABC(LOP_MOVE, uint8_t(regs + 1 + i), uint8_t(args[i]), 0);
        }

        compileExprTemp(expr->func, regs);

        size_t callLabel = bytecode.emitLabel();

        if (!bytecode.patchSkipC(fastcallLabel, callLabel))
            CompileError::raise(expr->func->location, "Exceeded jump distance limit; simplify the code to compile");

        bytecode.emitABC(LOP_CALL, regs, uint8_t(expr->args.size + 1), multRet ? 0 : uint8_t(targetCount + 1));

        if (!targetTop)
        {
            for (size_t i = 0; i < targetCount; ++i)
                bytecode.emitABC(LOP_MOVE, uint8_t(target + i), uint8_t(regs + i), 0);
        }
    }

    bool tryCompileInlinedCall(
        AstExprCall* expr,
        AstExprFunction* func,
        uint8_t target,
        uint8_t targetCount,
        bool multRet,
        int thresholdBase,
        int thresholdMaxBoost,
        int depthLimit
    )
    {
        Function* fi = functions.find(func);
        LUAU_ASSERT(fi);

        if (regTop > 128 || fi->stackSize > 32)
        {
            bytecode.addDebugRemark("inlining failed: high register pressure");
            return false;
        }

        if (int(inlineFrames.size()) >= depthLimit)
        {
            bytecode.addDebugRemark("inlining failed: too many inlined frames");
            return false;
        }

        for (InlineFrame& frame : inlineFrames)
            if (frame.func == func)
            {
                bytecode.addDebugRemark("inlining failed: can't inline recursive calls");
                return false;
            }

        if (multRet)
        {
            bytecode.addDebugRemark("inlining failed: can't convert fixed returns to multret");
            return false;
        }

        bool varc[8] = {};
        bool hasConstant = false;
        for (size_t i = 0; i < func->args.size && i < expr->args.size && i < 8; ++i)
        {
            if (isConstant(expr->args.data[i]))
            {
                varc[i] = true;
                hasConstant = true;
            }
        }

        if (expr->args.size != 0 && !isExprMultRet(expr->args.data[expr->args.size - 1]))
        {
            for (size_t i = expr->args.size; i < func->args.size && i < 8; ++i)
            {
                varc[i] = true;
                hasConstant = true;
            }
        }

        uint64_t callCostModel = fi->costModel;

        if (hasConstant)
            callCostModel = costModelInlinedCall(expr, func);

        int inlinedCost = computeCost(callCostModel, varc, std::min(int(func->args.size), 8));
        int baselineCost = computeCost(fi->costModel, nullptr, 0) + 3;
        int inlineProfit = (inlinedCost == 0) ? thresholdMaxBoost : std::min(thresholdMaxBoost, 100 * baselineCost / inlinedCost);

        int threshold = thresholdBase * inlineProfit / 100;
        bool isIife = unwrapExprOfType<AstExprFunction>(expr->func) != nullptr;

        if (inlinedCost > threshold && !isIife)
        {
            bytecode.addDebugRemark("inlining failed: too expensive (cost %d, profit %.2fx)", inlinedCost, double(inlineProfit) / 100);
            return false;
        }

        bytecode.addDebugRemark(
            "inlining succeeded (cost %d, profit %.2fx, depth %d)", inlinedCost, double(inlineProfit) / 100, int(inlineFrames.size())
        );

        compileInlinedCall(expr, func, target, targetCount);
        return true;
    }

    uint64_t costModelInlinedCall(AstExprCall* expr, AstExprFunction* func)
    {
        for (size_t i = 0; i < func->args.size; ++i)
        {
            AstLocal* var = func->args.data[i];
            AstExpr* arg = i < expr->args.size ? expr->args.data[i] : nullptr;

            if (i + 1 == expr->args.size && func->args.size > expr->args.size && isExprMultRet(arg))
                break;

            if (Variable* vv = variables.find(var); vv && vv->written)
                continue;

            if (arg == nullptr)
                locstants[var] = {Constant::Type_Nil};
            else if (const Constant* cv = constants.find(arg); cv && cv->type != Constant::Type_Unknown)
                locstants[var] = *cv;
        }

        exprChanges.clear();
        localChanges.clear();

        foldConstants(
            constants,
            variables,
            locstants,
            builtinsFold,
            builtinsFoldLibraryK,
            options.vectorPrecision == 1,
            options.libraryMemberConstantCb,
            func->body,
            names,
            tableConstants,
            &exprChanges,
            &localChanges
        );

        uint64_t cost = modelCost(func->body, func->args.data, func->args.size, builtins, constants);

        for (size_t i = 0; i < func->args.size; ++i)
        {
            if (Constant* var = locstants.find(func->args.data[i]))
                var->type = Constant::Type_Unknown;
        }

        Compile::undoChanges(constants, exprChanges);
        Compile::undoChanges(locstants, localChanges);

        return cost;
    }

    struct FindRegisterUseByLocal : AstVisitor
    {
        FindRegisterUseByLocal(Compiler* self, uint8_t reg)
            : self(self)
            , reg(reg)
        {
        }

        bool visit(AstExprLocal* node) override
        {
            if (self->getLocalReg(node->local) == reg)
                used = true;

            return !used;
        }

        Compiler* self = nullptr;
        uint8_t reg = 0;
        bool used = false;
    };

    bool isRegisterUsedInCallArguments(AstExprCall* expr, size_t startArg, uint8_t reg)
    {
        FindRegisterUseByLocal visitor(this, reg);

        for (size_t i = startArg; i < expr->args.size && !visitor.used; ++i)
            expr->args.data[i]->visit(&visitor);

        return visitor.used;
    }

    void compileInlinedCall(AstExprCall* expr, AstExprFunction* func, uint8_t target, uint8_t targetCount)
    {
        Function* fi = FFlag::LuauCompileMoveElision ? functions.find(func) : nullptr;

        bool noTargetMoveElision = FFlag::LuauCompileMoveElision && (fi->returnLocalCaptured || targetCount == 0 || regCaptured[target]);

        RegScope rs(this);

        size_t oldLocals = localStack.size();

        std::vector<InlineArg> args;
        args.reserve(func->args.size);

        for (size_t i = 0; i < func->args.size; ++i)
        {
            AstLocal* var = func->args.data[i];
            AstExpr* arg = i < expr->args.size ? expr->args.data[i] : nullptr;
            bool canUseParameterTarget =
                FFlag::LuauCompileMoveElision && fi->returnKind == ReturnKind::Parameter && fi->returnLocal == var && !noTargetMoveElision;

            if (i + 1 == expr->args.size && func->args.size > expr->args.size && isExprMultRet(arg))
            {

                unsigned int tail = unsigned(func->args.size - expr->args.size) + 1;
                uint8_t reg = allocReg(arg, tail);
                uint32_t allocpc = bytecode.getDebugPC();

                if (AstExprCall* expr = arg->as<AstExprCall>())
                    compileExprCall(expr, reg, tail, true);
                else if (AstExprVarargs* expr = arg->as<AstExprVarargs>())
                    compileExprVarargs(expr, reg, tail);
                else
                    LUAU_ASSERT(!"Unexpected expression type");

                for (size_t j = i; j < func->args.size; ++j)
                    args.push_back({func->args.data[j], uint8_t(reg + (j - i)), {Constant::Type_Unknown}, allocpc});

                break;
            }
            else if (Variable* vv = variables.find(var); vv && vv->written)
            {
                if (canUseParameterTarget && !isRegisterUsedInCallArguments(expr, i + 1, target))
                {
                    if (arg)
                        compileExprTemp(arg, target);
                    else
                        bytecode.emitABC(LOP_LOADNIL, target, 0, 0);

                    args.push_back({var, target, {Constant::Type_Unknown}, kDefaultAllocPc});
                }
                else
                {

                    uint8_t reg = allocReg(arg, 1u);
                    uint32_t allocpc = bytecode.getDebugPC();

                    if (arg)
                        compileExprTemp(arg, reg);
                    else
                        bytecode.emitABC(LOP_LOADNIL, reg, 0, 0);

                    args.push_back({var, reg, {Constant::Type_Unknown}, allocpc});
                }
            }
            else if (arg == nullptr)
            {

                args.push_back({var, kInvalidReg, {Constant::Type_Nil}});
            }
            else if (const Constant* cv = constants.find(arg); cv && cv->type != Constant::Type_Unknown)
            {

                args.push_back({var, kInvalidReg, *cv});
            }
            else
            {
                AstExprLocal* le = getExprLocal(arg);
                Variable* lv = le ? variables.find(le->local) : nullptr;

                if (int reg = le ? getExprLocalReg(le) : -1; reg >= 0 && (!lv || !lv->written))
                {
                    args.push_back({var, uint8_t(reg), {Constant::Type_Unknown}, kDefaultAllocPc, lv ? lv->init : nullptr});
                }
                else if (canUseParameterTarget && !isRegisterUsedInCallArguments(expr, i + 1, target))
                {
                    compileExprTemp(arg, target);

                    args.push_back({var, target, {Constant::Type_Unknown}, kDefaultAllocPc});
                }
                else
                {
                    uint8_t temp = allocReg(arg, 1u);
                    uint32_t allocpc = bytecode.getDebugPC();

                    if (FFlag::LuauCompileMoveElision)
                        temp = compileExprAutoTemp(arg, temp, target);
                    else
                        compileExprTemp(arg, temp);

                    args.push_back({var, temp, {Constant::Type_Unknown}, allocpc, arg});
                }
            }
        }

        for (size_t i = func->args.size; i < expr->args.size; ++i)
            compileExprSide(expr->args.data[i]);

        for (InlineArg& arg : args)
        {
            if (arg.value.type == Constant::Type_Unknown)
            {
                pushLocal(arg.local, arg.reg, arg.allocpc);

                if (arg.init)
                {
                    if (Variable* lv = variables.find(arg.local))
                        lv->init = arg.init;
                }
            }
            else
            {
                locstants[arg.local] = arg.value;
            }
        }

        AstLocal* resultLocal =
            FFlag::LuauCompileMoveElision && fi->returnKind == ReturnKind::Local && !noTargetMoveElision ? fi->returnLocal : nullptr;

        inlineFrames.push_back({func, oldLocals, target, targetCount, resultLocal});

        analyzeBuiltins(inlineBuiltins, globals, variables, options, func->body, names);

        if (!inlineBuiltins.empty())
        {
            for (auto [callExpr, bfid] : inlineBuiltins)
            {
                int& builtin = builtins[callExpr];

                if (bfid != builtin)
                {
                    inlineBuiltinsBackup[callExpr] = builtin;
                    builtin = bfid;
                }
            }

            inlineBuiltins.clear();
        }

        exprChanges.clear();
        localChanges.clear();

        foldConstants(
            constants,
            variables,
            locstants,
            builtinsFold,
            builtinsFoldLibraryK,
            options.vectorPrecision == 1,
            options.libraryMemberConstantCb,
            func->body,
            names,
            tableConstants,
            &exprChanges,
            &localChanges
        );

        bool terminatesEarly = false;

        for (size_t i = 0; i < func->body->body.size; ++i)
        {
            AstStat* stat = func->body->body.data[i];

            if (FFlag::LuauCompileReuseLocalRegs)
                popStatLocals(func->body, stat, oldLocals);

            compileStat(stat);

            if (alwaysTerminates(stat))
            {
                terminatesEarly = true;

                InlineFrame& currFrame = inlineFrames.back();
                if (!currFrame.returnJumps.empty() && currFrame.returnJumps.back() == bytecode.emitLabel() - 1)
                {
                    bytecode.undoEmit(LOP_JUMP);
                    currFrame.returnJumps.pop_back();
                }
                break;
            }
        }

        if (!terminatesEarly)
        {
            for (size_t i = 0; i < targetCount; ++i)
                bytecode.emitABC(LOP_LOADNIL, uint8_t(target + i), 0, 0);

            closeLocals(oldLocals);
        }

        popLocals(oldLocals);

        size_t returnLabel = bytecode.emitLabel();
        patchJumps(expr, inlineFrames.back().returnJumps, returnLabel);

        inlineFrames.pop_back();

        for (size_t i = 0; i < func->args.size; ++i)
        {
            AstLocal* local = func->args.data[i];

            if (Constant* var = locstants.find(local))
                var->type = Constant::Type_Unknown;

            if (Variable* lv = variables.find(local))
                lv->init = nullptr;
        }

        if (!inlineBuiltinsBackup.empty())
        {
            for (auto [callExpr, bfid] : inlineBuiltinsBackup)
                builtins[callExpr] = bfid;

            inlineBuiltinsBackup.clear();
        }

        Compile::undoChanges(constants, exprChanges);
        Compile::undoChanges(locstants, localChanges);
    }

    void compileExprCall(AstExprCall* expr, uint8_t target, uint8_t targetCount, bool targetTop = false, bool multRet = false)
    {
        LUAU_ASSERT(targetCount < 255);
        LUAU_ASSERT(!targetTop || unsigned(target + targetCount) == regTop);

        setDebugLine(expr);

        if (options.optimizationLevel >= 2 && !expr->self)
        {
            AstExprFunction* func = getFunctionExpr(expr->func);
            Function* fi = func ? functions.find(func) : nullptr;

            if (fi && fi->canInline &&
                tryCompileInlinedCall(
                    expr,
                    func,
                    target,
                    targetCount,
                    multRet,
                    FInt::LuauCompileInlineThreshold,
                    FInt::LuauCompileInlineThresholdMaxBoost,
                    FInt::LuauCompileInlineDepth
                ))
                return;

            if (func && !(fi && fi->canInline))
            {
                if (func->vararg)
                    bytecode.addDebugRemark("inlining failed: function is variadic");
                else if (!fi)
                    bytecode.addDebugRemark("inlining failed: can't inline recursive calls");
                else if (getfenvUsed || setfenvUsed)
                    bytecode.addDebugRemark("inlining failed: module uses getfenv/setfenv");
            }
        }

        RegScope rs(this);

        unsigned int regCount = std::max(unsigned(1 + expr->self + expr->args.size), unsigned(targetCount));

        uint8_t regs = targetTop ? allocReg(expr, regCount - targetCount) - targetCount : allocReg(expr, regCount);

        uint8_t selfreg = 0;

        int bfid = -1;

        if (options.optimizationLevel >= 1 && !expr->self)
        {
            if (const int* id = builtins.find(expr); id && *id != LBF_NONE)
                bfid = *id;
        }

        if (bfid >= 0 && bytecode.needsDebugRemarks())
        {
            Builtin builtin = getBuiltin(expr->func, globals, variables);
            bool lastMult = expr->args.size > 0 && isExprMultRet(expr->args.data[expr->args.size - 1]);

            if (builtin.object.value)
                bytecode.addDebugRemark("builtin %s.%s/%d%s", builtin.object.value, builtin.method.value, int(expr->args.size), lastMult ? "+" : "");
            else if (builtin.method.value)
                bytecode.addDebugRemark("builtin %s/%d%s", builtin.method.value, int(expr->args.size), lastMult ? "+" : "");
        }

        if (bfid == LBF_SELECT_VARARG)
        {

            if (multRet == false && targetCount == 1)
                return compileExprSelectVararg(expr, target, targetCount, targetTop, multRet, regs);
            else
                bfid = -1;
        }

        if (bfid == LBF_BIT32_EXTRACT && expr->args.size == 3 && isConstant(expr->args.data[1]) && isConstant(expr->args.data[2]))
        {
            Constant fc = getConstant(expr->args.data[1]);
            Constant wc = getConstant(expr->args.data[2]);

            int fi = fc.type == Constant::Type_Number ? int(fc.valueNumber) : -1;
            int wi = wc.type == Constant::Type_Number ? int(wc.valueNumber) : -1;

            if (fi >= 0 && wi > 0 && fi + wi <= 32)
            {
                int fwp = fi | ((wi - 1) << 5);
                int32_t cid = bytecode.addConstantNumber(fwp);
                if (cid < 0)
                    CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

                return compileExprFastcallN(expr, target, targetCount, targetTop, multRet, regs, LBF_BIT32_EXTRACTK, cid);
            }
        }

        unsigned maxFastcallArgs = 2;

        if (bfid >= 0 && expr->args.size == 3)
        {
            for (size_t i = 0; i < expr->args.size; ++i)
            {
                if (int reg = getExprLocalReg(expr->args.data[i]); reg >= 0)
                {
                    maxFastcallArgs = 3;
                    break;
                }
            }
        }

        if (bfid >= 0 && expr->args.size >= 1 && expr->args.size <= maxFastcallArgs)
        {
            if (!isExprMultRet(expr->args.data[expr->args.size - 1]))
            {
                return compileExprFastcallN(expr, target, targetCount, targetTop, multRet, regs, bfid);
            }
            else if (options.optimizationLevel >= 2)
            {

                BuiltinInfo info = getBuiltinInfo(bfid);
                if (int(expr->args.size) == info.params && (info.flags & BuiltinInfo::Flag_NoneSafe) != 0)
                    return compileExprFastcallN(expr, target, targetCount, targetTop, multRet, regs, bfid);
            }
        }

        int fastPcallId = -1;
        if (FFlag::LuauCompileFastpcall && options.optimizationLevel >= 1 && !expr->self)
        {
            if (AstExprGlobal* g = expr->func->as<AstExprGlobal>(); g && canImport(g))
            {
                if (g->name == "pcall" && expr->args.size >= 1)
                    fastPcallId = 0;
                else if (g->name == "xpcall" && expr->args.size >= 2)
                    fastPcallId = 1;
            }
        }

        if (expr->self)
        {
            AstExprIndexName* fi = expr->func->as<AstExprIndexName>();
            LUAU_ASSERT(fi);

            if (int reg = getExprLocalReg(fi->expr); reg >= 0)
            {
                selfreg = uint8_t(reg);
            }
            else
            {

                selfreg = regs;

                compileExprTempTop(fi->expr, selfreg);
            }
        }
        else if (bfid < 0 && (!FFlag::LuauCompileFastpcall || fastPcallId < 0))
        {
            compileExprTempTop(expr->func, regs);
        }

        bool multCall = false;

        for (size_t i = 0; i < expr->args.size; ++i)
            if (i + 1 == expr->args.size)
                multCall = compileExprTempMultRet(expr->args.data[i], uint8_t(regs + 1 + expr->self + i));
            else
                compileExprTempTop(expr->args.data[i], uint8_t(regs + 1 + expr->self + i));

        setDebugLineEnd(expr->func);

        if (expr->self)
        {
            AstExprIndexName* fi = expr->func->as<AstExprIndexName>();
            LUAU_ASSERT(fi);

            setDebugLine(fi->indexLocation);

            BytecodeBuilder::StringRef iname = sref(fi->index);
            int32_t cid = bytecode.addConstantString(iname);
            if (cid < 0)
                CompileError::raise(fi->location, "Exceeded constant limit; simplify the code to compile");

            bytecode.emitABC(LOP_NAMECALL, regs, selfreg, uint8_t(BytecodeBuilder::getStringHash(iname)));
            bytecode.emitAux(cid);

            hintTemporaryExprRegType(fi->expr, selfreg, LBC_TYPE_TABLE, 2);
        }
        else if (bfid >= 0 || (FFlag::LuauCompileFastpcall && fastPcallId >= 0))
        {
            size_t fastcallLabel = bytecode.emitLabel();

            if (FFlag::LuauCompileFastpcall && fastPcallId >= 0)
            {
                uint8_t explicitArgs = uint8_t(expr->args.size - (multCall ? 1 : 0));
                bytecode.emitABC(LOP_FASTPCALL, uint8_t(fastPcallId), explicitArgs, 0);
            }
            else
            {
                bytecode.emitABC(LOP_FASTCALL, uint8_t(bfid), 0, 0);
            }

            compileExprTemp(expr->func, regs);

            size_t callLabel = bytecode.emitLabel();

            if (!bytecode.patchSkipC(fastcallLabel, callLabel))
                CompileError::raise(expr->func->location, "Exceeded jump distance limit; simplify the code to compile");
        }

        bool canInline = currentFunction->functionDepth != 0 && !multCall && !multRet;
        if (FFlag::LuauEmitCallFeedback && (bfid < 0 && (!FFlag::LuauCompileFastpcall || fastPcallId < 0)) && canInline)
        {
            uint32_t fbSlot = FFlag::LuauCompileRefactorFeedback ? bytecode.addCallTargetSlot(uint32_t(bytecode.getInstructionCount()))
                                                                 : bytecode.addFbSlot_DEPRECATED(LuauFeedbackType::LFT_CALLTARGET);
            bytecode.emitABC(LOP_CALLFB, regs, multCall ? 0 : uint8_t(expr->self + expr->args.size + 1), multRet ? 0 : uint8_t(targetCount + 1));
            bytecode.emitAux(fbSlot);
        }
        else
        {
            bytecode.emitABC(LOP_CALL, regs, multCall ? 0 : uint8_t(expr->self + expr->args.size + 1), multRet ? 0 : uint8_t(targetCount + 1));
        }

        if (!targetTop)
        {
            for (size_t i = 0; i < targetCount; ++i)
                bytecode.emitABC(LOP_MOVE, uint8_t(target + i), uint8_t(regs + i), 0);
        }
    }

    bool shouldShareClosure(AstExprFunction* func)
    {
        const Function* f = functions.find(func);
        if (!f)
            return false;

        for (AstLocal* uv : f->upvals)
        {
            Variable* ul = variables.find(uv);

            if (!ul)
                return false;

            if (ul->written)
                return false;

            if (uv->functionDepth != 0 || uv->loopDepth != 0)
            {
                AstExprFunction* uf = ul->init ? ul->init->as<AstExprFunction>() : nullptr;
                if (!uf)
                    return false;

                if (uf != func && !shouldShareClosure(uf))
                    return false;
            }
        }

        return true;
    }

    void compileExprFunction(AstExprFunction* expr, uint8_t target)
    {
        RegScope rs(this);

        const Function* f = functions.find(expr);
        LUAU_ASSERT(f);

        int16_t pid = bytecode.addChildFunction(f->id);
        if (pid < 0)
            CompileError::raise(expr->location, "Exceeded closure limit; simplify the code to compile");

        captures.clear();
        captures.reserve(f->upvals.size());

        for (AstLocal* uv : f->upvals)
        {
            LUAU_ASSERT(uv->functionDepth < expr->functionDepth);

            if (int reg = getLocalReg(uv); reg >= 0)
            {

                Variable* ul = variables.find(uv);
                bool immutable = !ul || !ul->written;

                captures.push_back({immutable ? LCT_VAL : LCT_REF, uint8_t(reg)});
            }
            else if (const Constant* uc = locstants.find(uv); uc && uc->type != Constant::Type_Unknown)
            {

                uint8_t reg = allocReg(expr, 1u);
                compileExprConstant(expr, uc, reg);

                captures.push_back({LCT_VAL, reg});
            }
            else
            {
                LUAU_ASSERT(uv->functionDepth < expr->functionDepth - 1);

                uint8_t uid = getUpval(uv);

                captures.push_back({LCT_UPVAL, uid});
            }
        }

        int16_t shared = -1;

        if (options.optimizationLevel >= 1 && shouldShareClosure(expr) && !setfenvUsed)
        {
            int32_t cid = bytecode.addConstantClosure(f->id);

            if (cid >= 0 && cid < 32768)
                shared = int16_t(cid);
        }

        if (shared < 0)
            bytecode.addDebugRemark("allocation: closure with %d upvalues", int(captures.size()));

        if (shared >= 0)
            bytecode.emitAD(LOP_DUPCLOSURE, target, shared);
        else
            bytecode.emitAD(LOP_NEWCLOSURE, target, pid);

        for (const Capture& c : captures)
        {
            bytecode.emitABC(LOP_CAPTURE, uint8_t(c.type), c.data, 0);
        }
    }

    void compileClassDeclaration(AstStatClass* decl)
    {
        LUAU_ASSERT(FFlag::DebugLuauUserDefinedClasses);

        AstLocal** classLocal = classLocals.find(decl->name->name);
        LUAU_ASSERT(classLocal);
        int destReg = getLocalReg(*classLocal);
        LUAU_ASSERT(destReg >= 0);
        uint8_t dest = uint8_t(destReg);

        if (FFlag::LuauExportValueSyntax && decl->exported)
        {

            ensureExportTable(decl);
            exports.exportedClasses[decl->name] = dest;
        }

        RegScope _(this);

        uint8_t instrCVal = decl->open ? 1u : 0u;

        if (decl->super)
        {

            int superReg = getExprLocalReg(decl->super);
            uint8_t superDest = allocReg(decl, decl->super && superReg < 0 ? 1u : 0u);

            if (superReg >= 0)
                bytecode.emitABC(LOP_NEWCLASS, dest, uint8_t(superReg), instrCVal);
            else
            {
                compileExpr(decl->super, superDest);
                bytecode.emitABC(LOP_NEWCLASS, dest, superDest, instrCVal);
            }
        }
        else
            bytecode.emitABC(LOP_NEWCLASS, dest, kInvalidReg, instrCVal);

        size_t auxOffset = bytecode.emitLabel();
        bytecode.emitAux(0xDEADBEEF);

        BytecodeBuilder::ClassShape shape;
        shape.className = bytecode.addConstantString(sref(decl->name->name));
        checkConstant(shape.className, decl->name->location);

        auto temp = allocReg(decl, 1u);

        bool hasExplicitConstructor = false;

        for (const auto& member : decl->members)
        {
            Luau::visit(
                overloaded{
                    [&](const AstClassProperty& prop)
                    {
                        int propNameCid = bytecode.addConstantString(sref(prop.name));
                        checkConstant(propNameCid, prop.nameLocation);
                        shape.propertyNames.emplace_back(propNameCid);
                    },
                    [&](const AstClassMethod& method)
                    {
                        compileExprFunction(method.function, temp);
                        int methodNameCid = bytecode.addConstantString(sref(method.functionName));
                        checkConstant(methodNameCid, method.function->location);
                        shape.methodNames.emplace_back(methodNameCid);
                        bytecode.emitABC(LOP_NEWCLASSMEMBER, dest, 0, temp);
                        bytecode.emitAux(methodNameCid);

                        if (method.functionName == "__init")
                            hasExplicitConstructor = true;
                    }
                },
                member
            );
        }

        if (!hasExplicitConstructor)
        {
            int initCid = bytecode.addConstantString(sref(names.getOrAdd("__init")));
            checkConstant(initCid, decl->location);
            shape.methodNames.emplace_back(initCid);
        }

        int32_t classConst = bytecode.addClassShape(std::move(shape));
        checkConstant(classConst, decl->location);
        bytecode.patchAux(auxOffset, classConst);
    }

    LuauOpcode getUnaryOp(AstExprUnary::Op op)
    {
        switch (op)
        {
        case AstExprUnary::Op::Not:
            return LOP_NOT;

        case AstExprUnary::Op::Minus:
            return LOP_MINUS;

        case AstExprUnary::Op::Len:
            return LOP_LENGTH;

        default:
            LUAU_ASSERT(!"Unexpected unary operation");
            return LOP_NOP;
        }
    }

    LuauOpcode getBinaryOpArith(AstExprBinary::Op op, bool k = false)
    {
        switch (op)
        {
        case AstExprBinary::Add:
            return k ? LOP_ADDK : LOP_ADD;

        case AstExprBinary::Sub:
            return k ? LOP_SUBK : LOP_SUB;

        case AstExprBinary::Mul:
            return k ? LOP_MULK : LOP_MUL;

        case AstExprBinary::Div:
            return k ? LOP_DIVK : LOP_DIV;

        case AstExprBinary::FloorDiv:
            return k ? LOP_IDIVK : LOP_IDIV;

        case AstExprBinary::Mod:
            return k ? LOP_MODK : LOP_MOD;

        case AstExprBinary::Pow:
            return k ? LOP_POWK : LOP_POW;

        default:
            LUAU_ASSERT(!"Unexpected binary operation");
            return LOP_NOP;
        }
    }

    LuauOpcode getJumpOpCompare(AstExprBinary::Op op, bool not_ = false)
    {
        switch (op)
        {
        case AstExprBinary::CompareNe:
            return not_ ? LOP_JUMPIFEQ : LOP_JUMPIFNOTEQ;

        case AstExprBinary::CompareEq:
            return not_ ? LOP_JUMPIFNOTEQ : LOP_JUMPIFEQ;

        case AstExprBinary::CompareLt:
        case AstExprBinary::CompareGt:
            return not_ ? LOP_JUMPIFNOTLT : LOP_JUMPIFLT;

        case AstExprBinary::CompareLe:
        case AstExprBinary::CompareGe:
            return not_ ? LOP_JUMPIFNOTLE : LOP_JUMPIFLE;

        default:
            LUAU_ASSERT(!"Unexpected binary operation");
            return LOP_NOP;
        }
    }

    bool isConstant(AstExpr* node)
    {
        const Constant* cv = constants.find(node);

        return (cv != nullptr) && cv->type != Constant::Type_Unknown;
    }

    bool isConstantTrue(AstExpr* node)
    {
        return Compile::isConstantTrue(constants, node);
    }

    bool isConstantFalse(AstExpr* node)
    {
        return Compile::isConstantFalse(constants, node);
    }

    bool isConstantVector(AstExpr* node)
    {
        const Constant* cv = constants.find(node);

        return (cv != nullptr) && (cv->type == Constant::Type_Vectorf || cv->type == Constant::Type_Vectord);
    }

    bool isConstantInteger(AstExpr* node)
    {
        const Constant* cv = constants.find(node);

        return cv && cv->type == Constant::Type_Integer;
    }

    Constant getConstant(AstExpr* node)
    {
        const Constant* cv = constants.find(node);

        return cv ? *cv : Constant{Constant::Type_Unknown};
    }

    size_t compileCompareJump(AstExprBinary* expr, bool not_ = false)
    {
        RegScope rs(this);

        bool isEq = (expr->op == AstExprBinary::CompareEq || expr->op == AstExprBinary::CompareNe);
        AstExpr* left = expr->left;
        AstExpr* right = expr->right;

        bool operandIsConstant = isConstant(right);
        if (isEq && !operandIsConstant)
        {
            operandIsConstant = isConstant(left);
            if (operandIsConstant)
                std::swap(left, right);
        }

        if (operandIsConstant && (isConstantVector(right) || (FFlag::LuauIntegerType2 && isConstantInteger(right))))
            operandIsConstant = false;

        uint8_t rl = compileExprAuto(left, rs);

        if (isEq && operandIsConstant)
        {
            const Constant* cv = constants.find(right);
            LUAU_ASSERT(cv && cv->type != Constant::Type_Unknown);

            LuauOpcode opc = LOP_NOP;
            int32_t cid = -1;
            uint32_t flip = (expr->op == AstExprBinary::CompareEq) == not_ ? 0x80000000 : 0;

            switch (cv->type)
            {
            case Constant::Type_Nil:
                opc = LOP_JUMPXEQKNIL;
                cid = 0;
                break;

            case Constant::Type_Boolean:
                opc = LOP_JUMPXEQKB;
                cid = cv->valueBoolean;
                break;

            case Constant::Type_Number:
                opc = LOP_JUMPXEQKN;
                cid = getConstantIndex(right);
                break;

            case Constant::Type_String:
                opc = LOP_JUMPXEQKS;
                cid = getConstantIndex(right);
                break;

            default:
                LUAU_ASSERT(!"Unexpected constant type");
            }

            if (cid < 0)
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            size_t jumpLabel = bytecode.emitLabel();

            bytecode.emitAD(opc, rl, 0);
            bytecode.emitAux(cid | flip);

            return jumpLabel;
        }
        else
        {
            LuauOpcode opc = getJumpOpCompare(expr->op, not_);

            uint8_t rr = compileExprAuto(right, rs);

            size_t jumpLabel = bytecode.emitLabel();

            if (expr->op == AstExprBinary::CompareGt || expr->op == AstExprBinary::CompareGe)
            {
                bytecode.emitAD(opc, rr, 0);
                bytecode.emitAux(rl);
            }
            else
            {
                bytecode.emitAD(opc, rl, 0);
                bytecode.emitAux(rr);
            }

            return jumpLabel;
        }
    }

    int32_t getConstantNumber(AstExpr* node)
    {
        const Constant* c = constants.find(node);

        if (c && c->type == Constant::Type_Number)
        {
            int cid = bytecode.addConstantNumber(c->valueNumber);
            if (cid < 0)
                CompileError::raise(node->location, "Exceeded constant limit; simplify the code to compile");

            return cid;
        }

        return -1;
    }

    int32_t getConstantIndex(AstExpr* node)
    {
        const Constant* c = constants.find(node);

        if (!c || c->type == Constant::Type_Unknown)
            return -1;

        int cid = -1;

        switch (c->type)
        {
        case Constant::Type_Nil:
            cid = bytecode.addConstantNil();
            break;

        case Constant::Type_Boolean:
            cid = bytecode.addConstantBoolean(c->valueBoolean);
            break;

        case Constant::Type_Number:
            cid = bytecode.addConstantNumber(c->valueNumber);
            break;

        case Constant::Type_Integer:
            cid = bytecode.addConstantInteger(c->valueInteger64);
            break;

        case Constant::Type_Vectorf:
            cid = bytecode.addConstantVectorf(c->valueVectorf[0], c->valueVectorf[1], c->valueVectorf[2], c->valueVectorf[3]);
            break;

        case Constant::Type_Vectord:
            cid = bytecode.addConstantVectord(c->valueVectord[0], c->valueVectord[1], c->valueVectord[2], c->valueVectord[3]);
            break;

        case Constant::Type_String:
            cid = bytecode.addConstantString(sref(c->getString()));
            break;

        default:
            LUAU_ASSERT(!"Unexpected constant type");
            return -1;
        }

        if (cid < 0)
            CompileError::raise(node->location, "Exceeded constant limit; simplify the code to compile");

        return cid;
    }

    void compileConditionValue(AstExpr* node, const uint8_t* target, std::vector<size_t>& skipJump, bool onlyTruth)
    {

        if (const Constant* cv = constants.find(node); cv && cv->type != Constant::Type_Unknown)
        {

            if (cv->isTruthful() == onlyTruth)
            {
                if (target)
                    compileExprTemp(node, *target);

                skipJump.push_back(bytecode.emitLabel());
                bytecode.emitAD(LOP_JUMP, 0, 0);
            }
            return;
        }

        if (AstExprBinary* expr = node->as<AstExprBinary>())
        {
            switch (expr->op)
            {
            case AstExprBinary::And:
            case AstExprBinary::Or:
            {

                if (onlyTruth == (expr->op == AstExprBinary::And))
                {

                    std::vector<size_t> elseJump;
                    compileConditionValue(expr->left, nullptr, elseJump, !onlyTruth);

                    compileConditionValue(expr->right, target, skipJump, onlyTruth);

                    size_t elseLabel = bytecode.emitLabel();

                    patchJumps(expr, elseJump, elseLabel);
                }
                else
                {

                    compileConditionValue(expr->left, target, skipJump, onlyTruth);

                    compileConditionValue(expr->right, target, skipJump, onlyTruth);
                }
                return;
            }
            break;

            case AstExprBinary::CompareNe:
            case AstExprBinary::CompareEq:
            case AstExprBinary::CompareLt:
            case AstExprBinary::CompareLe:
            case AstExprBinary::CompareGt:
            case AstExprBinary::CompareGe:
            {
                if (target)
                {

                    bytecode.emitABC(LOP_LOADB, *target, onlyTruth ? 1 : 0, 0);
                }

                size_t jumpLabel = compileCompareJump(expr, !onlyTruth);

                skipJump.push_back(jumpLabel);
                return;
            }
            break;

            default:;
            }
        }

        if (AstExprUnary* expr = node->as<AstExprUnary>())
        {

            if (!target && expr->op == AstExprUnary::Op::Not)
            {
                compileConditionValue(expr->expr, target, skipJump, !onlyTruth);
                return;
            }
        }

        if (AstExprGroup* expr = node->as<AstExprGroup>())
        {
            compileConditionValue(expr->expr, target, skipJump, onlyTruth);
            return;
        }

        RegScope rs(this);
        uint8_t reg;

        if (target)
        {
            reg = *target;
            compileExprTemp(node, reg);
        }
        else
        {
            reg = compileExprAuto(node, rs);
        }

        skipJump.push_back(bytecode.emitLabel());
        bytecode.emitAD(onlyTruth ? LOP_JUMPIF : LOP_JUMPIFNOT, reg, 0);
    }

    bool isConditionFast(AstExpr* node)
    {
        const Constant* cv = constants.find(node);

        if (cv && cv->type != Constant::Type_Unknown)
            return true;

        if (AstExprBinary* expr = node->as<AstExprBinary>())
        {
            switch (expr->op)
            {
            case AstExprBinary::And:
            case AstExprBinary::Or:
                return true;

            case AstExprBinary::CompareNe:
            case AstExprBinary::CompareEq:
            case AstExprBinary::CompareLt:
            case AstExprBinary::CompareLe:
            case AstExprBinary::CompareGt:
            case AstExprBinary::CompareGe:
                return true;

            default:
                return false;
            }
        }

        if (AstExprGroup* expr = node->as<AstExprGroup>())
            return isConditionFast(expr->expr);

        return false;
    }

    void compileExprAndOr(AstExprBinary* expr, uint8_t target, bool targetTemp)
    {
        bool and_ = (expr->op == AstExprBinary::And);

        RegScope rs(this);

        if (const Constant* cl = constants.find(expr->left); cl && cl->type != Constant::Type_Unknown)
        {
            compileExpr(and_ == cl->isTruthful() ? expr->right : expr->left, target, targetTemp);
            return;
        }

        if (!isConditionFast(expr->left))
        {

            if (int reg = getExprLocalReg(expr->right); reg >= 0)
            {
                uint8_t lr = compileExprAuto(expr->left, rs);
                uint8_t rr = uint8_t(reg);

                bytecode.emitABC(and_ ? LOP_AND : LOP_OR, target, lr, rr);
                return;
            }

            int32_t cid = getConstantIndex(expr->right);

            if (cid >= 0 && cid <= 255)
            {
                uint8_t lr = compileExprAuto(expr->left, rs);

                bytecode.emitABC(and_ ? LOP_ANDK : LOP_ORK, target, lr, uint8_t(cid));
                return;
            }
        }

        uint8_t reg = targetTemp ? target : allocReg(expr, 1u);

        std::vector<size_t> skipJump;
        compileConditionValue(expr->left, &reg, skipJump, !and_);

        compileExprTemp(expr->right, reg);

        size_t moveLabel = bytecode.emitLabel();

        patchJumps(expr, skipJump, moveLabel);

        if (target != reg)
            bytecode.emitABC(LOP_MOVE, target, reg, 0);
    }

    void compileExprUnary(AstExprUnary* expr, uint8_t target)
    {
        RegScope rs(this);

        AstExprConstantInteger* cint = expr->expr->as<AstExprConstantInteger>();
        if (FFlag::LuauIntegerType2 && (expr->op == AstExprUnary::Op::Minus) && (cint != nullptr))
        {
            int32_t cid = bytecode.addConstantInteger((int64_t)(~(uint64_t)cint->value + 1));
            if (cid < 0)
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            emitLoadK(target, cid);
            return;
        }

        uint8_t re = compileExprAuto(expr->expr, rs);

        bytecode.emitABC(getUnaryOp(expr->op), target, re, 0);
    }

    static void unrollConcats(std::vector<AstExpr*>& args)
    {
        for (;;)
        {
            AstExprBinary* be = args.back()->as<AstExprBinary>();

            if (!be || be->op != AstExprBinary::Concat)
                break;

            args.back() = be->left;
            args.push_back(be->right);
        }
    }

    void compileExprBinary(AstExprBinary* expr, uint8_t target, bool targetTemp)
    {
        RegScope rs(this);

        switch (expr->op)
        {
        case AstExprBinary::Add:
        case AstExprBinary::Sub:
        case AstExprBinary::Mul:
        case AstExprBinary::Div:
        case AstExprBinary::FloorDiv:
        case AstExprBinary::Mod:
        case AstExprBinary::Pow:
        {
            int32_t rc = getConstantNumber(expr->right);

            if (rc >= 0 && rc <= 255)
            {
                uint8_t rl = compileExprAuto(expr->left, rs);

                bytecode.emitABC(getBinaryOpArith(expr->op, true), target, rl, uint8_t(rc));

                hintTemporaryExprRegType(expr->left, rl, LBC_TYPE_NUMBER, 1);
            }
            else
            {
                if (expr->op == AstExprBinary::Sub || expr->op == AstExprBinary::Div)
                {
                    int32_t lc = getConstantNumber(expr->left);

                    if (lc >= 0 && lc <= 255)
                    {
                        uint8_t rr = compileExprAuto(expr->right, rs);
                        LuauOpcode op = (expr->op == AstExprBinary::Sub) ? LOP_SUBRK : LOP_DIVRK;

                        bytecode.emitABC(op, target, uint8_t(lc), uint8_t(rr));

                        hintTemporaryExprRegType(expr->right, rr, LBC_TYPE_NUMBER, 1);
                        return;
                    }
                }
                else if (options.optimizationLevel >= 2 && (expr->op == AstExprBinary::Add || expr->op == AstExprBinary::Mul))
                {

                    if (LuauBytecodeType* ty = exprTypes.find(expr))
                    {

                        if (*ty == LBC_TYPE_NUMBER || (*ty == LBC_TYPE_VECTOR && expr->op == AstExprBinary::Mul))
                        {
                            int32_t lc = getConstantNumber(expr->left);

                            if (lc >= 0 && lc <= 255)
                            {
                                uint8_t rr = compileExprAuto(expr->right, rs);

                                bytecode.emitABC(getBinaryOpArith(expr->op, true), target, rr, uint8_t(lc));

                                hintTemporaryExprRegType(expr->right, rr, LBC_TYPE_NUMBER, 1);
                                return;
                            }
                        }
                    }
                }

                uint8_t rl = compileExprAuto(expr->left, rs);
                uint8_t rr = compileExprAuto(expr->right, rs);

                bytecode.emitABC(getBinaryOpArith(expr->op), target, rl, rr);

                hintTemporaryExprRegType(expr->left, rl, LBC_TYPE_NUMBER, 1);
                hintTemporaryExprRegType(expr->right, rr, LBC_TYPE_NUMBER, 1);
            }
        }
        break;

        case AstExprBinary::Concat:
        {
            std::vector<AstExpr*> args = {expr->left, expr->right};

            unrollConcats(args);

            uint8_t regs = allocReg(expr, unsigned(args.size()));

            for (size_t i = 0; i < args.size(); ++i)
                if (FFlag::LuauCompileConcatTargetTop)
                    compileExprTempTop(args[i], uint8_t(regs + i));
                else
                    compileExprTemp(args[i], uint8_t(regs + i));

            bytecode.emitABC(LOP_CONCAT, target, regs, uint8_t(regs + args.size() - 1));
        }
        break;

        case AstExprBinary::CompareNe:
        case AstExprBinary::CompareEq:
        case AstExprBinary::CompareLt:
        case AstExprBinary::CompareLe:
        case AstExprBinary::CompareGt:
        case AstExprBinary::CompareGe:
        {
            size_t jumpLabel = compileCompareJump(expr);

            bytecode.emitABC(LOP_LOADB, target, 0, 1);

            size_t thenLabel = bytecode.emitLabel();

            bytecode.emitABC(LOP_LOADB, target, 1, 0);

            patchJump(expr, jumpLabel, thenLabel);
        }
        break;

        case AstExprBinary::And:
        case AstExprBinary::Or:
        {
            compileExprAndOr(expr, target, targetTemp);
        }
        break;

        default:
            LUAU_ASSERT(!"Unexpected binary operation");
        }
    }

    void compileExprIfElseAndOr(bool and_, uint8_t creg, AstExpr* other, uint8_t target)
    {
        int32_t cid = getConstantIndex(other);

        if (cid >= 0 && cid <= 255)
        {
            bytecode.emitABC(and_ ? LOP_ANDK : LOP_ORK, target, creg, uint8_t(cid));
        }
        else
        {
            RegScope rs(this);
            uint8_t oreg = compileExprAuto(other, rs);

            bytecode.emitABC(and_ ? LOP_AND : LOP_OR, target, creg, oreg);
        }
    }

    void compileExprIfElseLocal(AstExprIfElse* expr, uint8_t target, bool targetTemp)
    {
        LUAU_ASSERT(expr->conditionLocal);

        bool skipElse = isConstantTrue(expr->condition);
        size_t oldLocals = localStack.size();
        size_t elseJump = 0;

        {
            RegScope rs(this);

            uint8_t reg = allocReg(expr, 1u);
            uint32_t allocpc = bytecode.getDebugPC();

            compileExprTemp(expr->condition, reg);
            pushLocal(expr->conditionLocal, reg, allocpc);

            if (!skipElse)
            {
                elseJump = bytecode.emitLabel();
                bytecode.emitAD(LOP_JUMPIFNOT, reg, 0);
            }

            compileExpr(expr->trueExpr, target, targetTemp);

            closeLocals(oldLocals);
            popLocals(oldLocals);
        }

        if (skipElse)
            return;

        size_t thenLabel = bytecode.emitLabel();
        bytecode.emitAD(LOP_JUMP, 0, 0);

        size_t elseLabel = bytecode.emitLabel();
        compileExpr(expr->falseExpr, target, targetTemp);
        size_t endLabel = bytecode.emitLabel();

        patchJump(expr, elseJump, elseLabel);
        patchJump(expr, thenLabel, endLabel);
    }

    void compileExprIfElse(AstExprIfElse* expr, uint8_t target, bool targetTemp)
    {
        if (FFlag::LuauExperimentalIfLocalSyntax && expr->conditionLocal)
        {
            compileExprIfElseLocal(expr, target, targetTemp);
            return;
        }

        if (isConstant(expr->condition))
        {
            if (isConstantTrue(expr->condition))
            {
                compileExpr(expr->trueExpr, target, targetTemp);
            }
            else
            {
                compileExpr(expr->falseExpr, target, targetTemp);
            }
        }
        else
        {

            if (int creg = getExprLocalReg(expr->condition); creg >= 0)
            {
                if (creg == getExprLocalReg(expr->trueExpr) && (getExprLocalReg(expr->falseExpr) >= 0 || isConstant(expr->falseExpr)))
                    return compileExprIfElseAndOr(false, uint8_t(creg), expr->falseExpr, target);
                else if (creg == getExprLocalReg(expr->falseExpr) && (getExprLocalReg(expr->trueExpr) >= 0 || isConstant(expr->trueExpr)))
                    return compileExprIfElseAndOr(true, uint8_t(creg), expr->trueExpr, target);
            }

            std::vector<size_t> elseJump;
            compileConditionValue(expr->condition, nullptr, elseJump, false);
            compileExpr(expr->trueExpr, target, targetTemp);

            size_t thenLabel = bytecode.emitLabel();
            bytecode.emitAD(LOP_JUMP, 0, 0);

            size_t elseLabel = bytecode.emitLabel();
            compileExpr(expr->falseExpr, target, targetTemp);
            size_t endLabel = bytecode.emitLabel();

            patchJumps(expr, elseJump, elseLabel);
            patchJump(expr, thenLabel, endLabel);
        }
    }

    void compileExprInterpString(AstExprInterpString* expr, uint8_t target, bool targetTemp)
    {
        size_t formatCapacity = 0;
        for (AstArray<char> string : expr->strings)
        {
            formatCapacity += string.size + std::count(string.data, string.data + string.size, '%');
        }

        size_t skippedSubExpr = 0;
        for (size_t index = 0; index < expr->expressions.size; ++index)
        {
            const Constant* c = constants.find(expr->expressions.data[index]);
            if (c && c->type == Constant::Type::Type_String)
            {
                formatCapacity += c->stringLength + std::count(c->valueString, c->valueString + c->stringLength, '%');
                skippedSubExpr++;
            }
            else
                formatCapacity += 2;
        }

        std::string formatString;
        formatString.reserve(formatCapacity);

        LUAU_ASSERT(expr->strings.size == expr->expressions.size + 1);
        for (size_t idx = 0; idx < expr->strings.size; idx++)
        {
            AstArray<char> string = expr->strings.data[idx];
            escapeAndAppend(formatString, string.data, string.size);

            if (idx < expr->expressions.size)
            {
                const Constant* c = constants.find(expr->expressions.data[idx]);
                if (c && c->type == Constant::Type::Type_String)
                    escapeAndAppend(formatString, c->valueString, c->stringLength);
                else
                    formatString += "%*";
            }
        }

        int32_t formatStringIndex = -1;

        if (formatString.empty())
        {
            formatStringIndex = bytecode.addConstantString({"", 0});
        }
        else
        {
            AstName interned = names.getOrAdd(formatString.c_str(), formatString.size());
            AstArray<const char> formatStringArray{interned.value, formatString.size()};
            formatStringIndex = bytecode.addConstantString(sref(formatStringArray));
        }

        if (formatStringIndex < 0)
            CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

        RegScope rs(this);

        unsigned int regCount = unsigned(2 + expr->expressions.size - skippedSubExpr);

        bool targetTop = targetTemp && target == regTop - 1;
        uint8_t baseReg = targetTop ? allocReg(expr, regCount - 1) - 1 : allocReg(expr, regCount);

        emitLoadK(baseReg, formatStringIndex);

        size_t skipped = 0;
        for (size_t index = 0; index < expr->expressions.size; ++index)
        {
            AstExpr* subExpr = expr->expressions.data[index];
            const Constant* c = constants.find(subExpr);
            if (!c || c->type != Constant::Type::Type_String)
                compileExprTempTop(subExpr, uint8_t(baseReg + 2 + index - skipped));
            else
                skipped++;
        }

        BytecodeBuilder::StringRef formatMethod = sref(AstName("format"));

        int32_t formatMethodIndex = bytecode.addConstantString(formatMethod);
        if (formatMethodIndex < 0)
            CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

        bytecode.emitABC(LOP_NAMECALL, baseReg, baseReg, uint8_t(BytecodeBuilder::getStringHash(formatMethod)));
        bytecode.emitAux(formatMethodIndex);
        bytecode.emitABC(LOP_CALL, baseReg, uint8_t(expr->expressions.size + 2 - skippedSubExpr), 2);
        if (target != baseReg)
            bytecode.emitABC(LOP_MOVE, target, baseReg, 0);
    }

    static uint8_t encodeHashSize(unsigned int hashSize)
    {
        size_t hashSizeLog2 = 0;
        while ((1u << hashSizeLog2) < hashSize)
            hashSizeLog2++;

        return hashSize == 0 ? 0 : uint8_t(hashSizeLog2 + 1);
    }

    void compileExprTable(AstExprTable* expr, uint8_t target, bool targetTemp)
    {

        if (expr->items.size == 0)
        {
            TableShape shape = tableShapes[expr];

            bytecode.addDebugRemark("allocation: table hash %d", shape.hashSize);

            bytecode.emitABC(LOP_NEWTABLE, target, encodeHashSize(shape.hashSize), 0);
            bytecode.emitAux(shape.arraySize);
            return;
        }

        unsigned int arraySize = 0;
        unsigned int hashSize = 0;
        unsigned int recordSize = 0;
        unsigned int indexSize = 0;

        for (size_t i = 0; i < expr->items.size; ++i)
        {
            const AstExprTable::Item& item = expr->items.data[i];

            arraySize += (item.kind == AstExprTable::Item::Kind::List);
            hashSize += (item.kind != AstExprTable::Item::Kind::List);
            recordSize += (item.kind == AstExprTable::Item::Kind::Record);
        }

        if (arraySize == 0 && hashSize > 0)
        {
            for (size_t i = 0; i < expr->items.size; ++i)
            {
                const AstExprTable::Item& item = expr->items.data[i];
                LUAU_ASSERT(item.key);

                const Constant* ckey = constants.find(item.key);

                indexSize += (ckey && ckey->type == Constant::Type_Number && ckey->valueNumber == double(indexSize + 1));
            }

            if (hashSize == recordSize + indexSize)
                hashSize = recordSize;
            else
                indexSize = 0;
        }

        int encodedHashSize = encodeHashSize(hashSize);

        RegScope rs(this);

        uint8_t reg = targetTemp ? target : allocReg(expr, 1u);

        InsertionOrderedMap<int32_t, int32_t> lastKeyVal;

        if (arraySize == 0 && indexSize == 0 && hashSize == recordSize && recordSize >= 1 && recordSize <= BytecodeBuilder::TableShape::kMaxLength)
        {
            BytecodeBuilder::TableShape shape;

            for (size_t i = 0; i < expr->items.size; ++i)
            {
                const AstExprTable::Item& item = expr->items.data[i];
                LUAU_ASSERT(item.kind == AstExprTable::Item::Kind::Record);

                AstExprConstantString* ckey = item.key->as<AstExprConstantString>();
                LUAU_ASSERT(ckey);

                int keyCid = bytecode.addConstantString(sref(ckey->value));
                if (keyCid < 0)
                    CompileError::raise(ckey->location, "Exceeded constant limit; simplify the code to compile");

                int32_t valueCid = getConstantIndex(item.value);
                if (lastKeyVal.contains(keyCid) && lastKeyVal[keyCid] == -1)
                    continue;

                lastKeyVal[keyCid] = valueCid;
            }

            for (auto& [keyCid, valueCid] : lastKeyVal)
            {
                LUAU_ASSERT(shape.length < BytecodeBuilder::TableShape::kMaxLength);

                size_t idx = shape.length;
                shape.keys[idx] = keyCid;

                shape.constants[idx] = valueCid;
                if (valueCid >= 0)
                {
                    shape.hasConstants = true;
                }

                shape.length++;
            }

            int32_t tid = bytecode.addConstantTable(shape);
            if (tid < 0)
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            bytecode.addDebugRemark("allocation: table template %d", hashSize);

            if (tid < 32768)
            {
                bytecode.emitAD(LOP_DUPTABLE, reg, int16_t(tid));
            }
            else
            {

                shape.hasConstants = false;
                lastKeyVal.clear();

                bytecode.emitABC(LOP_NEWTABLE, reg, uint8_t(encodedHashSize), 0);
                bytecode.emitAux(0);
            }
        }
        else
        {

            const AstExprTable::Item* last = expr->items.size > 0 ? &expr->items.data[expr->items.size - 1] : nullptr;

            bool trailingVarargs = last && last->kind == AstExprTable::Item::Kind::List && last->value->is<AstExprVarargs>();
            LUAU_ASSERT(!trailingVarargs || arraySize > 0);

            unsigned int arrayAllocation = arraySize - trailingVarargs + indexSize;

            if (hashSize == 0)
                bytecode.addDebugRemark("allocation: table array %d", arrayAllocation);
            else if (arrayAllocation == 0)
                bytecode.addDebugRemark("allocation: table hash %d", hashSize);
            else
                bytecode.addDebugRemark("allocation: table hash %d array %d", hashSize, arrayAllocation);

            bytecode.emitABC(LOP_NEWTABLE, reg, uint8_t(encodedHashSize), 0);
            bytecode.emitAux(arrayAllocation);
        }

        unsigned int arrayChunkSize = std::min(16u, arraySize);
        uint8_t arrayChunkReg = allocReg(expr, arrayChunkSize);
        unsigned int arrayChunkCurrent = 0;

        unsigned int arrayIndex = 1;
        bool multRet = false;

        for (size_t i = 0; i < expr->items.size; ++i)
        {
            const AstExprTable::Item& item = expr->items.data[i];

            AstExpr* key = item.key;
            AstExpr* value = item.value;

            if (lastKeyVal.size() > 0 && key && key->is<AstExprConstantString>())
            {
                AstExprConstantString* ckey = item.key->as<AstExprConstantString>();
                LUAU_ASSERT(ckey);

                int keyCid = bytecode.addConstantString(sref(ckey->value));
                if (const int32_t* valueCid = lastKeyVal.get(keyCid))
                {

                    if (*valueCid >= 0)
                    {
                        continue;
                    }
                }
            }

            setDebugLine(value);

            if (options.coverageLevel >= 2)
            {
                bytecode.emitABC(LOP_COVERAGE, 0, 0, 0);
            }

            if (arrayChunkCurrent > 0 && (key || arrayChunkCurrent == arrayChunkSize))
            {
                bytecode.emitABC(LOP_SETLIST, reg, arrayChunkReg, uint8_t(arrayChunkCurrent + 1));
                bytecode.emitAux(arrayIndex);
                arrayIndex += arrayChunkCurrent;
                arrayChunkCurrent = 0;
            }

            if (key)
            {
                RegScope rsi(this);

                LValue lv = compileLValueIndex(reg, key, rsi);
                uint8_t rv = compileExprAuto(value, rsi);

                compileAssign(lv, rv, nullptr);
            }

            else
            {
                uint8_t temp = uint8_t(arrayChunkReg + arrayChunkCurrent);

                if (i + 1 == expr->items.size)
                    multRet = compileExprTempMultRet(value, temp);
                else
                    compileExprTempTop(value, temp);

                arrayChunkCurrent++;
            }
        }

        if (arrayChunkCurrent)
        {
            bytecode.emitABC(LOP_SETLIST, reg, arrayChunkReg, multRet ? 0 : uint8_t(arrayChunkCurrent + 1));
            bytecode.emitAux(arrayIndex);
        }

        if (target != reg)
            bytecode.emitABC(LOP_MOVE, target, reg, 0);
    }

    bool canImport(AstExprGlobal* expr)
    {
        return options.optimizationLevel >= 1 && getGlobalState(globals, expr->name) != Global::Written;
    }

    bool canImportChain(AstExprGlobal* expr)
    {
        return options.optimizationLevel >= 1 && getGlobalState(globals, expr->name) == Global::Default;
    }

    void compileExprIndexName(AstExprIndexName* expr, uint8_t target, bool targetTemp = false)
    {
        setDebugLine(expr);

        AstExprGlobal* importRoot = 0;
        AstExprIndexName* import1 = 0;
        AstExprIndexName* import2 = 0;

        if (AstExprIndexName* index = expr->expr->as<AstExprIndexName>())
        {
            importRoot = index->expr->as<AstExprGlobal>();
            import1 = index;
            import2 = expr;
        }
        else
        {
            importRoot = expr->expr->as<AstExprGlobal>();
            import1 = expr;
        }

        if (importRoot && canImportChain(importRoot) && !(FFlag::DebugLuauUserDefinedClasses && classLocals.contains(importRoot->name)))
        {
            int32_t id0 = bytecode.addConstantString(sref(importRoot->name));
            int32_t id1 = bytecode.addConstantString(sref(import1->index));
            int32_t id2 = import2 ? bytecode.addConstantString(sref(import2->index)) : -1;

            if (id0 < 0 || id1 < 0 || (import2 && id2 < 0))
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            if (id0 < 1024 && id1 < 1024 && id2 < 1024)
            {
                uint32_t iid = import2 ? BytecodeBuilder::getImportId(id0, id1, id2) : BytecodeBuilder::getImportId(id0, id1);
                int32_t cid = bytecode.addImport(iid);

                if (cid >= 0 && cid < 32768)
                {
                    bytecode.emitAD(LOP_GETIMPORT, target, int16_t(cid));
                    bytecode.emitAux(iid);
                    return;
                }
            }
        }

        RegScope rs(this);

        uint8_t reg = target;

        if (int localReg = getExprLocalReg(expr->expr); localReg >= 0)
            reg = uint8_t(localReg);
        else if (targetTemp && FFlag::LuauCompileMoveElision)
            reg = compileExprAutoTemp(expr->expr, target);
        else if (targetTemp && !FFlag::LuauCompileMoveElision)
            compileExprTemp(expr->expr, target);
        else
            reg = compileExprAuto(expr->expr, rs);

        setDebugLine(expr->indexLocation);

        BytecodeBuilder::StringRef iname = sref(expr->index);
        int32_t cid = bytecode.addConstantString(iname);
        if (cid < 0)
            CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

        bytecode.emitABC(LOP_GETTABLEKS, target, reg, uint8_t(BytecodeBuilder::getStringHash(iname)));
        bytecode.emitAux(cid);

        hintTemporaryExprRegType(expr->expr, reg, LBC_TYPE_TABLE, 2);
    }

    void compileExprIndexExpr(AstExprIndexExpr* expr, uint8_t target)
    {
        RegScope rs(this);

        Constant cv = getConstant(expr->index);

        if (cv.type == Constant::Type_Number && cv.valueNumber >= 1 && cv.valueNumber <= 256 && double(int(cv.valueNumber)) == cv.valueNumber)
        {
            uint8_t i = uint8_t(int(cv.valueNumber) - 1);

            uint8_t rt = compileExprAuto(expr->expr, rs);

            setDebugLine(expr->index);

            bytecode.emitABC(LOP_GETTABLEN, target, rt, i);

            hintTemporaryExprRegType(expr->expr, rt, LBC_TYPE_TABLE, 1);
        }
        else if (cv.type == Constant::Type_String)
        {
            BytecodeBuilder::StringRef iname = sref(cv.getString());
            int32_t cid = bytecode.addConstantString(iname);
            if (cid < 0)
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            uint8_t rt = compileExprAuto(expr->expr, rs);

            setDebugLine(expr->index);

            bytecode.emitABC(LOP_GETTABLEKS, target, rt, uint8_t(BytecodeBuilder::getStringHash(iname)));
            bytecode.emitAux(cid);

            hintTemporaryExprRegType(expr->expr, rt, LBC_TYPE_TABLE, 2);
        }
        else
        {
            uint8_t rt = compileExprAuto(expr->expr, rs);
            uint8_t ri = compileExprAuto(expr->index, rs);

            bytecode.emitABC(LOP_GETTABLE, target, rt, ri);

            hintTemporaryExprRegType(expr->expr, rt, LBC_TYPE_TABLE, 1);
            hintTemporaryExprRegType(expr->index, ri, LBC_TYPE_NUMBER, 1);
        }
    }

    void compileExprGlobal(AstExprGlobal* expr, uint8_t target)
    {
        if (FFlag::DebugLuauUserDefinedClasses)
        {
            if (AstLocal** local = classLocals.find(expr->name))
            {
                int reg = getLocalReg(*local);
                if (reg >= 0)
                {
                    if (target != uint8_t(reg))
                        bytecode.emitABC(LOP_MOVE, target, uint8_t(reg), 0);
                }
                else
                {
                    uint8_t uid = getUpval(*local);
                    bytecode.emitABC(LOP_GETUPVAL, target, uid, 0);
                }
                return;
            }
        }

        if (canImport(expr))
        {
            int32_t id0 = bytecode.addConstantString(sref(expr->name));
            if (id0 < 0)
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            if (id0 < 1024)
            {
                uint32_t iid = BytecodeBuilder::getImportId(id0);
                int32_t cid = bytecode.addImport(iid);

                if (cid >= 0 && cid < 32768)
                {
                    bytecode.emitAD(LOP_GETIMPORT, target, int16_t(cid));
                    bytecode.emitAux(iid);
                    return;
                }
            }
        }

        BytecodeBuilder::StringRef gname = sref(expr->name);
        int32_t cid = bytecode.addConstantString(gname);
        if (cid < 0)
            CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

        bytecode.emitABC(LOP_GETGLOBAL, target, 0, uint8_t(BytecodeBuilder::getStringHash(gname)));
        bytecode.emitAux(cid);
    }

    void compileExprConstant(AstExpr* node, const Constant* cv, uint8_t target)
    {
        switch (cv->type)
        {
        case Constant::Type_Nil:
            bytecode.emitABC(LOP_LOADNIL, target, 0, 0);
            break;

        case Constant::Type_Boolean:
            bytecode.emitABC(LOP_LOADB, target, cv->valueBoolean, 0);
            break;

        case Constant::Type_Number:
        {
            double d = cv->valueNumber;

            if (d >= std::numeric_limits<int16_t>::min() && d <= std::numeric_limits<int16_t>::max() && double(int16_t(d)) == d &&
                !(d == 0.0 && signbit(d)))
            {

                bytecode.emitAD(LOP_LOADN, target, int16_t(d));
            }
            else
            {

                int32_t cid = bytecode.addConstantNumber(d);
                if (cid < 0)
                    CompileError::raise(node->location, "Exceeded constant limit; simplify the code to compile");

                emitLoadK(target, cid);
            }
        }
        break;

        case Constant::Type_Integer:
        {
            int64_t l = cv->valueInteger64;

            int32_t cid = bytecode.addConstantInteger(l);
            if (cid < 0)
                CompileError::raise(node->location, "Exceeded constant limit; simplify the code to compile");

            emitLoadK(target, cid);
        }
        break;

        case Constant::Type_Vectorf:
        {
            int32_t cid = bytecode.addConstantVectorf(cv->valueVectorf[0], cv->valueVectorf[1], cv->valueVectorf[2], cv->valueVectorf[3]);
            if (cid < 0)
                CompileError::raise(node->location, "Exceeded constant limit; simplify the code to compile");

            emitLoadK(target, cid);
        }
        break;

        case Constant::Type_Vectord:
        {
            int32_t cid = bytecode.addConstantVectord(cv->valueVectord[0], cv->valueVectord[1], cv->valueVectord[2], cv->valueVectord[3]);
            if (cid < 0)
                CompileError::raise(node->location, "Exceeded constant limit; simplify the code to compile");

            emitLoadK(target, cid);
        }
        break;

        case Constant::Type_String:
        {
            int32_t cid = bytecode.addConstantString(sref(cv->getString()));
            if (cid < 0)
                CompileError::raise(node->location, "Exceeded constant limit; simplify the code to compile");

            emitLoadK(target, cid);
        }
        break;

        default:
            LUAU_ASSERT(!"Unexpected constant type");
        }
    }

    void compileExpr(AstExpr* node, uint8_t target, bool targetTemp = false)
    {
        setDebugLine(node);

        if (options.coverageLevel >= 2 && needsCoverage(node))
        {
            bytecode.emitABC(LOP_COVERAGE, 0, 0, 0);
        }

        if (const Constant* cv = constants.find(node); cv && cv->type != Constant::Type_Unknown)
        {
            compileExprConstant(node, cv, target);
            return;
        }

        if (AstExprGroup* expr = node->as<AstExprGroup>())
        {
            compileExpr(expr->expr, target, targetTemp);
        }
        else if (node->is<AstExprConstantNil>())
        {
            bytecode.emitABC(LOP_LOADNIL, target, 0, 0);
        }
        else if (AstExprConstantBool* expr = node->as<AstExprConstantBool>())
        {
            bytecode.emitABC(LOP_LOADB, target, expr->value, 0);
        }
        else if (AstExprConstantNumber* expr = node->as<AstExprConstantNumber>())
        {
            int32_t cid = bytecode.addConstantNumber(expr->value);
            if (cid < 0)
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            emitLoadK(target, cid);
        }
        else if (AstExprConstantInteger* expr = node->as<AstExprConstantInteger>())
        {
            int32_t cid = bytecode.addConstantInteger(expr->value);
            if (cid < 0)
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            emitLoadK(target, cid);
        }
        else if (AstExprConstantString* expr = node->as<AstExprConstantString>())
        {
            int32_t cid = bytecode.addConstantString(sref(expr->value));
            if (cid < 0)
                CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

            emitLoadK(target, cid);
        }
        else if (AstExprLocal* expr = node->as<AstExprLocal>())
        {
            if (FFlag::LuauExportValueSyntax && expr->local->isExported && !exports.exportedClasses.contains(expr->local) &&
                (!FFlag::LuauOptimizeExportTable || !exports.exportedFunctions.contains(expr->local)))

            {
                BytecodeBuilder::StringRef name = sref(expr->local->name);
                int32_t cid = bytecode.addConstantString(name);
                if (cid < 0)
                    CompileError::raise(expr->location, "Exceeded constant limit; simplify the code to compile");

                if (int tableReg = getLocalReg(&exports.exportTableLocal); tableReg >= 0)
                {
                    bytecode.emitABC(LOP_GETTABLEKS, target, tableReg, uint8_t(BytecodeBuilder::getStringHash(name)));
                    bytecode.emitAux(cid);
                }
                else
                {

                    uint8_t upval = getUpval(&exports.exportTableLocal);
                    bytecode.emitABC(LOP_GETUPVAL, target, upval, 0);
                    bytecode.emitABC(LOP_GETTABLEKS, target, target, uint8_t(BytecodeBuilder::getStringHash(name)));
                    bytecode.emitAux(cid);
                }
            }
            else
            {

                if (int reg = getExprLocalReg(expr); reg >= 0)
                {

                    if (options.optimizationLevel == 0 || target != reg)
                        bytecode.emitABC(LOP_MOVE, target, uint8_t(reg), 0);
                }
                else
                {
                    LUAU_ASSERT(expr->upvalue);
                    uint8_t uid = getUpval(expr->local);

                    bytecode.emitABC(LOP_GETUPVAL, target, uid, 0);
                }
            }
        }
        else if (AstExprGlobal* expr = node->as<AstExprGlobal>())
        {
            compileExprGlobal(expr, target);
        }
        else if (AstExprVarargs* expr = node->as<AstExprVarargs>())
        {
            compileExprVarargs(expr, target, 1);
        }
        else if (AstExprCall* expr = node->as<AstExprCall>())
        {

            if (targetTemp && target == regTop - 1)
                compileExprCall(expr, target, 1, true);
            else
                compileExprCall(expr, target, 1);
        }
        else if (AstExprIndexName* expr = node->as<AstExprIndexName>())
        {
            compileExprIndexName(expr, target, targetTemp);
        }
        else if (AstExprIndexExpr* expr = node->as<AstExprIndexExpr>())
        {
            compileExprIndexExpr(expr, target);
        }
        else if (AstExprFunction* expr = node->as<AstExprFunction>())
        {
            compileExprFunction(expr, target);
        }
        else if (AstExprTable* expr = node->as<AstExprTable>())
        {
            compileExprTable(expr, target, targetTemp);
        }
        else if (AstExprUnary* expr = node->as<AstExprUnary>())
        {
            compileExprUnary(expr, target);
        }
        else if (AstExprBinary* expr = node->as<AstExprBinary>())
        {
            compileExprBinary(expr, target, targetTemp);
        }
        else if (AstExprTypeAssertion* expr = node->as<AstExprTypeAssertion>())
        {
            compileExpr(expr->expr, target, targetTemp);
        }
        else if (AstExprIfElse* expr = node->as<AstExprIfElse>())
        {
            compileExprIfElse(expr, target, targetTemp);
        }
        else if (AstExprInterpString* interpString = node->as<AstExprInterpString>())
        {
            compileExprInterpString(interpString, target, targetTemp);
        }
        else if (AstExprInstantiate* expr = node->as<AstExprInstantiate>())
        {
            compileExpr(expr->expr, target, targetTemp);
        }
        else
        {
            LUAU_ASSERT(!"Unknown expression type");
        }
    }

    void compileExprTemp(AstExpr* node, uint8_t target)
    {
        return compileExpr(node, target, true);
    }

    uint8_t compileExprAutoTemp(AstExpr* node, uint8_t target, uint8_t forbiddenSourceReg = kInvalidReg)
    {
        LUAU_ASSERT(FFlag::LuauCompileMoveElision);

        if (options.optimizationLevel == 0)
        {
            compileExprTemp(node, target);
            return target;
        }

        size_t marker = bytecode.emitLabel();
        compileExprTemp(node, target);

        if (bytecode.emitLabel() == marker + 1)
        {
            unsigned insn = bytecode.lastInstruction();

            if (LUAU_INSN_OP(insn) == LOP_MOVE && LUAU_INSN_A(insn) == target)
            {
                uint8_t src = LUAU_INSN_B(insn);

                if (!regCaptured[src] && src != forbiddenSourceReg)
                {
                    bytecode.undoEmit(LOP_MOVE);
                    target = src;
                }
            }
        }

        return target;
    }

    uint8_t compileExprAuto(AstExpr* node, RegScope&)
    {

        if (int reg = getExprLocalReg(node); reg >= 0)
            return uint8_t(reg);

        uint8_t reg = allocReg(node, 1u);

        if (FFlag::LuauCompileMoveElision)
        {
            return compileExprAutoTemp(node, reg);
        }
        else
        {
            compileExprTemp(node, reg);

            return reg;
        }
    }

    void compileExprSide(AstExpr* node)
    {

        if (node->is<AstExprLocal>() || node->is<AstExprGlobal>() || node->is<AstExprVarargs>() || node->is<AstExprFunction>() || isConstant(node))
            return;

        if (!node->is<AstExprCall>())
            bytecode.addDebugRemark("expression only compiled for side effects");

        RegScope rsi(this);
        compileExprAuto(node, rsi);
    }

    void compileExprTempN(AstExpr* node, uint8_t target, uint8_t targetCount, bool targetTop)
    {

        LUAU_ASSERT(!targetTop || unsigned(target + targetCount) == regTop);

        if (targetCount == 255)
            CompileError::raise(node->location, "Exceeded result count limit; simplify the code to compile");

        if (AstExprCall* expr = node->as<AstExprCall>())
        {
            compileExprCall(expr, target, targetCount, targetTop);
        }
        else if (AstExprVarargs* expr = node->as<AstExprVarargs>())
        {
            compileExprVarargs(expr, target, targetCount);
        }
        else
        {
            compileExprTemp(node, target);

            for (size_t i = 1; i < targetCount; ++i)
                bytecode.emitABC(LOP_LOADNIL, uint8_t(target + i), 0, 0);
        }
    }

    void compileExprListTemp(const AstArray<AstExpr*>& list, uint8_t target, uint8_t targetCount, bool targetTop)
    {

        LUAU_ASSERT(!targetTop || unsigned(target + targetCount) == regTop);

        if (list.size == targetCount)
        {
            for (size_t i = 0; i < list.size; ++i)
                compileExprTemp(list.data[i], uint8_t(target + i));
        }
        else if (list.size > targetCount)
        {
            for (size_t i = 0; i < targetCount; ++i)
                compileExprTemp(list.data[i], uint8_t(target + i));

            for (size_t i = targetCount; i < list.size; ++i)
                compileExprSide(list.data[i]);
        }
        else if (list.size > 0)
        {
            for (size_t i = 0; i < list.size - 1; ++i)
                compileExprTemp(list.data[i], uint8_t(target + i));

            compileExprTempN(list.data[list.size - 1], uint8_t(target + list.size - 1), uint8_t(targetCount - (list.size - 1)), targetTop);
        }
        else
        {
            for (size_t i = 0; i < targetCount; ++i)
                bytecode.emitABC(LOP_LOADNIL, uint8_t(target + i), 0, 0);
        }
    }

    struct LValue
    {
        enum Kind
        {
            Kind_Local,
            Kind_Upvalue,
            Kind_Global,
            Kind_IndexName,
            Kind_IndexNumber,
            Kind_IndexExpr,
        };

        Kind kind;
        uint8_t reg;
        uint8_t upval;
        uint8_t index;
        uint8_t number;
        BytecodeBuilder::StringRef name;
        Location location;
    };

    LValue compileLValueIndex(uint8_t reg, AstExpr* index, RegScope& rs)
    {
        Constant cv = getConstant(index);

        if (cv.type == Constant::Type_Number && cv.valueNumber >= 1 && cv.valueNumber <= 256 && double(int(cv.valueNumber)) == cv.valueNumber)
        {
            LValue result = {LValue::Kind_IndexNumber};
            result.reg = reg;
            result.number = uint8_t(int(cv.valueNumber) - 1);
            result.location = index->location;

            return result;
        }
        else if (cv.type == Constant::Type_String)
        {
            LValue result = {LValue::Kind_IndexName};
            result.reg = reg;
            result.name = sref(cv.getString());
            result.location = index->location;

            return result;
        }
        else
        {
            LValue result = {LValue::Kind_IndexExpr};
            result.reg = reg;
            result.index = compileExprAuto(index, rs);
            result.location = index->location;

            return result;
        }
    }

    LValue compileLValue(AstExpr* node, RegScope& rs)
    {
        setDebugLine(node);

        if (AstExprLocal* expr = node->as<AstExprLocal>())
        {
            if (FFlag::LuauExportValueSyntax && expr->local->isExported &&
                (!FFlag::LuauOptimizeExportTable || !exports.exportedFunctions.contains(expr->local)))
            {
                uint8_t tableReg = getExportTableReg(node);

                LValue result = {LValue::Kind_IndexName};
                result.reg = tableReg;
                result.name = sref(expr->local->name);
                result.location = node->location;

                return result;
            }

            if (int reg = getExprLocalReg(expr); reg >= 0)
            {
                LValue result = {LValue::Kind_Local};
                result.reg = uint8_t(reg);
                result.location = node->location;

                return result;
            }
            else
            {
                LUAU_ASSERT(expr->upvalue);

                LValue result = {LValue::Kind_Upvalue};
                result.upval = getUpval(expr->local);
                result.location = node->location;

                return result;
            }
        }
        else if (AstExprGlobal* expr = node->as<AstExprGlobal>())
        {
            if (FFlag::DebugLuauUserDefinedClasses)
            {
                if (AstLocal** classLocal = classLocals.find(expr->name))
                    CompileError::raise(
                        expr->location,
                        "'%s' refers to a class and cannot be used as a variable name (defined on line %d)",
                        expr->name.value,
                        (*classLocal)->location.begin.line + 1
                    );
            }

            LValue result = {LValue::Kind_Global};
            result.name = sref(expr->name);
            result.location = node->location;

            return result;
        }
        else if (AstExprIndexName* expr = node->as<AstExprIndexName>())
        {
            LValue result = {LValue::Kind_IndexName};
            result.reg = compileExprAuto(expr->expr, rs);
            result.name = sref(expr->index);
            result.location = node->location;

            return result;
        }
        else if (AstExprIndexExpr* expr = node->as<AstExprIndexExpr>())
        {
            uint8_t reg = compileExprAuto(expr->expr, rs);

            return compileLValueIndex(reg, expr->index, rs);
        }
        else
        {
            LUAU_ASSERT(!"Unknown assignment expression");

            return LValue();
        }
    }

    void compileLValueUse(const LValue& lv, uint8_t reg, bool set, AstExpr* targetExpr)
    {
        setDebugLine(lv.location);

        switch (lv.kind)
        {
        case LValue::Kind_Local:
            if (set)
                bytecode.emitABC(LOP_MOVE, lv.reg, reg, 0);
            else
                bytecode.emitABC(LOP_MOVE, reg, lv.reg, 0);
            break;

        case LValue::Kind_Upvalue:
            bytecode.emitABC(set ? LOP_SETUPVAL : LOP_GETUPVAL, reg, lv.upval, 0);
            break;

        case LValue::Kind_Global:
        {
            int32_t cid = bytecode.addConstantString(lv.name);
            if (cid < 0)
                CompileError::raise(lv.location, "Exceeded constant limit; simplify the code to compile");

            bytecode.emitABC(set ? LOP_SETGLOBAL : LOP_GETGLOBAL, reg, 0, uint8_t(BytecodeBuilder::getStringHash(lv.name)));
            bytecode.emitAux(cid);
        }
        break;

        case LValue::Kind_IndexName:
        {
            int32_t cid = bytecode.addConstantString(lv.name);
            if (cid < 0)
                CompileError::raise(lv.location, "Exceeded constant limit; simplify the code to compile");

            bytecode.emitABC(set ? LOP_SETTABLEKS : LOP_GETTABLEKS, reg, lv.reg, uint8_t(BytecodeBuilder::getStringHash(lv.name)));
            bytecode.emitAux(cid);

            if (targetExpr)
            {
                if (AstExprIndexName* targetExprIndexName = targetExpr->as<AstExprIndexName>())
                    hintTemporaryExprRegType(targetExprIndexName->expr, lv.reg, LBC_TYPE_TABLE, 2);
            }
        }
        break;

        case LValue::Kind_IndexNumber:
            bytecode.emitABC(set ? LOP_SETTABLEN : LOP_GETTABLEN, reg, lv.reg, lv.number);

            if (targetExpr)
            {
                if (AstExprIndexExpr* targetExprIndexExpr = targetExpr->as<AstExprIndexExpr>())
                    hintTemporaryExprRegType(targetExprIndexExpr->expr, lv.reg, LBC_TYPE_TABLE, 1);
            }
            break;

        case LValue::Kind_IndexExpr:
            bytecode.emitABC(set ? LOP_SETTABLE : LOP_GETTABLE, reg, lv.reg, lv.index);

            if (targetExpr)
            {
                if (AstExprIndexExpr* targetExprIndexExpr = targetExpr->as<AstExprIndexExpr>())
                {
                    hintTemporaryExprRegType(targetExprIndexExpr->expr, lv.reg, LBC_TYPE_TABLE, 1);
                    hintTemporaryExprRegType(targetExprIndexExpr->index, lv.index, LBC_TYPE_NUMBER, 1);
                }
            }
            break;

        default:
            LUAU_ASSERT(!"Unknown lvalue kind");
        }
    }

    void compileAssign(const LValue& lv, uint8_t source, AstExpr* targetExpr)
    {
        compileLValueUse(lv, source, true, targetExpr);
    }

    AstExprLocal* getExprLocal(AstExpr* node)
    {
        return unwrapExprOfType<AstExprLocal>(node);
    }

    int getExprLocalReg(AstExpr* node)
    {
        if (AstExprLocal* expr = getExprLocal(node))
        {

            Local* l = locals.find(expr->local);

            return l && l->allocated ? l->reg : -1;
        }
        else if (FFlag::DebugLuauUserDefinedClasses)
        {
            if (AstExprGlobal* g = node->as<AstExprGlobal>())
            {
                if (AstLocal** local = classLocals.find(g->name))
                    return getLocalReg(*local);
            }
        }
        return -1;
    }

    bool isStatBreak(AstStat* node)
    {
        if (AstStatBlock* stat = node->as<AstStatBlock>())
            return stat->body.size == 1 && stat->body.data[0]->is<AstStatBreak>();

        return node->is<AstStatBreak>();
    }

    AstStatContinue* extractStatContinue(AstStatBlock* block)
    {
        if (block->body.size == 1)
            return block->body.data[0]->as<AstStatContinue>();
        else
            return nullptr;
    }

    void compileStatIfLocal(AstStatIf* stat)
    {
        LUAU_ASSERT(stat->conditionLocal);

        bool thenTerminates = alwaysTerminates(stat->thenbody);
        bool skipElse = isConstantTrue(stat->condition);
        size_t oldLocals = localStack.size();
        size_t elseJump = 0;

        {
            RegScope rs(this);

            uint8_t reg = allocReg(stat, 1u);
            uint32_t allocpc = bytecode.getDebugPC();

            compileExprTemp(stat->condition, reg);
            pushLocal(stat->conditionLocal, reg, allocpc);

            if (!skipElse)
            {
                elseJump = bytecode.emitLabel();
                bytecode.emitAD(LOP_JUMPIFNOT, reg, 0);
            }

            compileStat(stat->thenbody);

            if (!thenTerminates)
                closeLocals(oldLocals);

            popLocals(oldLocals);
        }

        if (skipElse)
            return;

        if (stat->elsebody)
        {
            if (thenTerminates)
            {
                size_t elseLabel = bytecode.emitLabel();
                compileStat(stat->elsebody);
                patchJump(stat, elseJump, elseLabel);
            }
            else
            {
                size_t thenLabel = bytecode.emitLabel();
                bytecode.emitAD(LOP_JUMP, 0, 0);

                size_t elseLabel = bytecode.emitLabel();
                compileStat(stat->elsebody);

                size_t endLabel = bytecode.emitLabel();
                patchJump(stat, elseJump, elseLabel);
                patchJump(stat, thenLabel, endLabel);
            }
        }
        else
        {
            size_t endLabel = bytecode.emitLabel();
            patchJump(stat, elseJump, endLabel);
        }
    }

    void compileStatIf(AstStatIf* stat)
    {

        if (isConstantFalse(stat->condition))
        {
            if (stat->elsebody)
                compileStat(stat->elsebody);
            return;
        }

        if (AstExprBinary* cand = stat->condition->as<AstExprBinary>(); cand && cand->op == AstExprBinary::And && isConstantFalse(cand->right))
        {
            compileExprSide(cand->left);
            if (stat->elsebody)
                compileStat(stat->elsebody);
            return;
        }

        if (FFlag::LuauExperimentalIfLocalSyntax && stat->conditionLocal)
        {
            compileStatIfLocal(stat);
            return;
        }

        if (!stat->elsebody && isStatBreak(stat->thenbody) && !areLocalsCaptured(loops.back().localOffset))
        {

            std::vector<size_t> elseJump;
            compileConditionValue(stat->condition, nullptr, elseJump, true);

            for (size_t jump : elseJump)
                loopJumps.push_back({LoopJump::Break, jump});
            return;
        }

        AstStatContinue* continueStatement = extractStatContinue(stat->thenbody);

        if (!stat->elsebody && continueStatement != nullptr && !areLocalsCaptured(loops.back().localOffsetContinue))
        {

            if (!loops.back().continueUsed)
                loops.back().continueUsed = continueStatement;

            std::vector<size_t> elseJump;
            compileConditionValue(stat->condition, nullptr, elseJump, true);

            for (size_t jump : elseJump)
                loopJumps.push_back({LoopJump::Continue, jump});
            return;
        }

        std::vector<size_t> elseJump;
        compileConditionValue(stat->condition, nullptr, elseJump, false);

        compileStat(stat->thenbody);

        if (stat->elsebody && elseJump.size() > 0)
        {

            if (alwaysTerminates(stat->thenbody))
            {
                size_t elseLabel = bytecode.emitLabel();

                compileStat(stat->elsebody);

                patchJumps(stat, elseJump, elseLabel);
            }
            else
            {
                size_t thenLabel = bytecode.emitLabel();

                bytecode.emitAD(LOP_JUMP, 0, 0);

                size_t elseLabel = bytecode.emitLabel();

                compileStat(stat->elsebody);

                size_t endLabel = bytecode.emitLabel();

                patchJumps(stat, elseJump, elseLabel);
                patchJump(stat, thenLabel, endLabel);
            }
        }
        else
        {
            size_t endLabel = bytecode.emitLabel();

            patchJumps(stat, elseJump, endLabel);
        }
    }

    void compileStatWhile(AstStatWhile* stat)
    {

        if (isConstantFalse(stat->condition))
            return;

        size_t oldJumps = loopJumps.size();
        size_t oldLocals = localStack.size();

        loops.push_back({oldLocals, oldLocals, nullptr});
        hasLoops = true;

        size_t loopLabel = bytecode.emitLabel();

        std::vector<size_t> elseJump;
        compileConditionValue(stat->condition, nullptr, elseJump, false);

        compileStat(stat->body);

        size_t contLabel = bytecode.emitLabel();

        size_t backLabel = bytecode.emitLabel();

        setDebugLine(stat->condition);

        bytecode.emitAD(LOP_JUMPBACK, 0, 0);

        size_t endLabel = bytecode.emitLabel();

        patchJump(stat, backLabel, loopLabel);
        patchJumps(stat, elseJump, endLabel);

        patchLoopJumps(stat, oldJumps, endLabel, contLabel);
        loopJumps.resize(oldJumps);

        loops.pop_back();
    }

    void compileStatRepeat(AstStatRepeat* stat)
    {
        size_t oldJumps = loopJumps.size();
        size_t oldLocals = localStack.size();

        loops.push_back({oldLocals, oldLocals, nullptr});
        hasLoops = true;

        size_t loopLabel = bytecode.emitLabel();

        AstStatBlock* body = stat->body;

        RegScope rs(this);

        bool continueValidated = false;
        size_t conditionLocals = 0;

        for (size_t i = 0; i < body->body.size; ++i)
        {
            if (FFlag::LuauCompileReuseLocalRegs)
                popStatLocals(body, body->body.data[i], oldLocals);

            compileStat(body->body.data[i]);

            if (!loops.back().continueUsed)
                loops.back().localOffsetContinue = localStack.size();

            if (loops.back().continueUsed && !continueValidated)
            {
                validateContinueUntil(loops.back().continueUsed, stat->condition, body, i + 1);
                continueValidated = true;
                conditionLocals = localStack.size();
            }
        }

        if (continueValidated)
        {

            setDebugLineEnd(body->body.data[body->body.size - 1]);

            closeLocals(conditionLocals);

            popLocals(conditionLocals);
        }

        size_t contLabel = bytecode.emitLabel();

        size_t endLabel;

        setDebugLine(stat->condition);

        if (isConstantTrue(stat->condition))
        {
            closeLocals(oldLocals);

            endLabel = bytecode.emitLabel();
        }
        else
        {
            std::vector<size_t> skipJump;
            compileConditionValue(stat->condition, nullptr, skipJump, true);

            closeLocals(oldLocals);

            size_t backLabel = bytecode.emitLabel();

            bytecode.emitAD(LOP_JUMPBACK, 0, 0);

            size_t skipLabel = bytecode.emitLabel();

            closeLocals(oldLocals);

            endLabel = bytecode.emitLabel();

            patchJump(stat, backLabel, loopLabel);
            patchJumps(stat, skipJump, skipLabel);
        }

        popLocals(oldLocals);

        patchLoopJumps(stat, oldJumps, endLabel, contLabel);
        loopJumps.resize(oldJumps);

        loops.pop_back();
    }

    void compileInlineReturn(AstStatReturn* stat, bool fallthrough)
    {
        setDebugLine(stat);

        InlineFrame frame = inlineFrames.back();

        compileExprListTemp(stat->list, frame.target, frame.targetCount, false);

        closeLocals(frame.localOffset);

        size_t jumpLabel = bytecode.emitLabel();
        bytecode.emitAD(LOP_JUMP, 0, 0);

        inlineFrames.back().returnJumps.push_back(jumpLabel);
    }

    void compileStatReturn(AstStatReturn* stat)
    {

        if (stat->list.size >= 255)
            CompileError::raise(stat->location, "Exceeded return count limit; simplify the code to compile");

        RegScope rs(this);

        uint8_t temp = 0;
        bool consecutive = false;
        bool multRet = false;

        if (int reg = stat->list.size > 0 ? getExprLocalReg(stat->list.data[0]) : -1; reg >= 0)
        {
            temp = uint8_t(reg);
            consecutive = true;

            for (size_t i = 1; i < stat->list.size; ++i)
                if (getExprLocalReg(stat->list.data[i]) != int(temp + i))
                {
                    consecutive = false;
                    break;
                }
        }

        if (FFlag::LuauCompileReuseLocalRegs && !consecutive && stat->list.size > 1)
        {
            AstArray<AstExpr*>& list = stat->list;
            bool allLocals = true;

            for (AstExpr* expr : list)
            {
                if (getExprLocalReg(expr) == -1)
                    allLocals = false;
            }

            if (allLocals)
            {
                uint8_t base = uint8_t(getExprLocalReg(list.data[0]));
                size_t prefix = 1;

                while (prefix < list.size && getExprLocalReg(list.data[prefix]) == int(base + prefix))
                    prefix++;

                if (base + prefix == regTop)
                {
                    uint8_t tail = allocReg(stat, unsigned(list.size - prefix));
                    LUAU_ASSERT(tail == base + prefix);

                    for (size_t i = prefix; i < list.size; i++)
                        bytecode.emitABC(LOP_MOVE, uint8_t(base + i), uint8_t(getExprLocalReg(list.data[i])), 0);

                    temp = base;
                    consecutive = true;
                }
            }
        }

        if (FFlag::LuauCompileMoveElision && !consecutive && stat->list.size == 1 && !isExprMultRet(stat->list.data[0]))
        {

            temp = allocReg(stat, 1u);
            temp = compileExprAutoTemp(stat->list.data[0], temp);
        }
        else if (!consecutive && stat->list.size > 0)
        {
            temp = allocReg(stat, unsigned(stat->list.size));

            for (size_t i = 0; i < stat->list.size; ++i)
                if (i + 1 == stat->list.size)
                    multRet = compileExprTempMultRet(stat->list.data[i], uint8_t(temp + i));
                else
                    compileExprTempTop(stat->list.data[i], uint8_t(temp + i));
        }

        closeLocals(0);

        if (multRet)
            hasMultiRet = true;

        bytecode.emitABC(LOP_RETURN, uint8_t(temp), multRet ? 0 : uint8_t(stat->list.size + 1), 0);
    }

    bool areLocalsRedundant(AstStatLocal* stat)
    {

        if (stat->values.size > stat->vars.size)
            return false;

        for (AstLocal* local : stat->vars)
        {
            Variable* v = variables.find(local);
            if (!v || !v->constant)
                return false;

            if (FFlag::LuauExportValueSyntax && local->isExported && (!FFlag::LuauOptimizeExportTable || exports.exportedTableCid == -1))
            {

                return false;
            }
        }

        return true;
    }

    void compileStatLocal(AstStatLocal* stat)
    {

        if (options.optimizationLevel >= 1 && options.debugLevel <= 1 && areLocalsRedundant(stat))
            return;

        if (options.optimizationLevel >= 1 && stat->vars.size == 1 && stat->values.size == 1)
        {
            if (AstExprLocal* re = getExprLocal(stat->values.data[0]))
            {
                Variable* lv = variables.find(stat->vars.data[0]);
                Variable* rv = variables.find(re->local);

                if (int reg = getExprLocalReg(re);
                    reg >= 0 && (!lv || !lv->written) && (!rv || !rv->written) && !stat->vars.data[0]->isExported && !re->local->isExported)
                {
                    pushLocal(stat->vars.data[0], uint8_t(reg), kDefaultAllocPc);
                    return;
                }
            }

            if (FFlag::LuauCompileMoveElision && !inlineFrames.empty() && inlineFrames.back().resultLocal == stat->vars.data[0])
            {
                compileExprTemp(stat->values.data[0], inlineFrames.back().target);

                for (size_t i = stat->vars.size; i < stat->values.size; ++i)
                    compileExprSide(stat->values.data[i]);

                pushLocal(stat->vars.data[0], inlineFrames.back().target, kDefaultAllocPc);
                return;
            }

            if (FFlag::LuauCompileReuseLocalRegs)
            {
                uint8_t target = kInvalidReg;
                if (tryReuseLocalReg(stat->vars.data[0], target))
                {
                    uint32_t allocpc = bytecode.getDebugPC();
                    compileExprTemp(stat->values.data[0], target);
                    pushLocal(stat->vars.data[0], target, allocpc);
                    return;
                }
            }
        }

        uint8_t vars = allocReg(stat, unsigned(stat->vars.size));
        uint32_t allocpc = bytecode.getDebugPC();

        compileExprListTemp(stat->values, vars, uint8_t(stat->vars.size), true);

        for (size_t i = 0; i < stat->vars.size; ++i)
        {
            AstLocal* local = stat->vars.data[i];
            Variable* localVariable = variables.find(local);
            if (FFlag::LuauExportValueSyntax && local->isExported &&
                (!FFlag::LuauOptimizeExportTable || !localVariable->constant || exports.exportedTableCid == -1))
            {
                ensureExportTable(stat);

                int32_t cid = bytecode.addConstantString(sref(local->name));
                if (cid < 0)
                    CompileError::raise(local->location, "Exceeded constant limit; simplify the code to compile");

                uint8_t tableReg = getExportTableReg(stat);
                bytecode.emitABC(LOP_SETTABLEKS, uint8_t(vars + i), tableReg, uint8_t(BytecodeBuilder::getStringHash(sref(local->name))));
                bytecode.emitAux(cid);
            }
            else
            {
                pushLocal(local, uint8_t(vars + i), allocpc);
            }
        }
    }

    bool tryCompileUnrolledFor(AstStatFor* stat, int thresholdBase, int thresholdMaxBoost)
    {
        Constant one = {Constant::Type_Number};
        one.valueNumber = 1.0;

        Constant fromc = getConstant(stat->from);
        Constant toc = getConstant(stat->to);
        Constant stepc = stat->step ? getConstant(stat->step) : one;

        int tripCount = (fromc.type == Constant::Type_Number && toc.type == Constant::Type_Number && stepc.type == Constant::Type_Number)
                            ? getTripCount(fromc.valueNumber, toc.valueNumber, stepc.valueNumber)
                            : -1;

        if (tripCount < 0)
        {
            bytecode.addDebugRemark("loop unroll failed: invalid iteration count");
            return false;
        }

        if (FFlag::LuauCompileLoopUnrollZero && tripCount == 0)
        {
            bytecode.addDebugRemark("loop unroll succeeded: empty loop");
            return true;
        }

        if (tripCount > thresholdBase)
        {
            bytecode.addDebugRemark("loop unroll failed: too many iterations (%d)", tripCount);
            return false;
        }

        if (Variable* lv = variables.find(stat->var); lv && lv->written)
        {
            bytecode.addDebugRemark("loop unroll failed: mutable loop variable");
            return false;
        }

        AstLocal* var = stat->var;
        uint64_t costModel = modelCost(stat->body, &var, 1, builtins, constants);

        bool varc = true;
        int unrolledCost = computeCost(costModel, &varc, 1) * tripCount;
        int baselineCost = (computeCost(costModel, nullptr, 0) + 1) * tripCount;
        int unrollProfit = (unrolledCost == 0) ? thresholdMaxBoost : std::min(thresholdMaxBoost, 100 * baselineCost / unrolledCost);

        int threshold = thresholdBase * unrollProfit / 100;

        if (unrolledCost > threshold)
        {
            bytecode.addDebugRemark(
                "loop unroll failed: too expensive (iterations %d, cost %d, profit %.2fx)", tripCount, unrolledCost, double(unrollProfit) / 100
            );
            return false;
        }

        bytecode.addDebugRemark("loop unroll succeeded (iterations %d, cost %d, profit %.2fx)", tripCount, unrolledCost, double(unrollProfit) / 100);

        compileUnrolledFor(stat, tripCount, fromc.valueNumber, stepc.valueNumber);
        return true;
    }

    void compileUnrolledFor(AstStatFor* stat, int tripCount, double from, double step)
    {
        AstLocal* var = stat->var;

        size_t oldLocals = localStack.size();
        size_t oldJumps = loopJumps.size();

        loops.push_back({oldLocals, oldLocals, nullptr});

        exprChanges.clear();
        localChanges.clear();

        for (int iv = 0; iv < tripCount; ++iv)
        {

            locstants[var].type = Constant::Type_Number;
            locstants[var].valueNumber = from + iv * step;

            if (iv == 0)
                foldConstants(
                    constants,
                    variables,
                    locstants,
                    builtinsFold,
                    builtinsFoldLibraryK,
                    options.vectorPrecision == 1,
                    options.libraryMemberConstantCb,
                    stat,
                    names,
                    tableConstants,
                    &exprChanges,
                    &localChanges
                );
            else
                foldConstants(
                    constants,
                    variables,
                    locstants,
                    builtinsFold,
                    builtinsFoldLibraryK,
                    options.vectorPrecision == 1,
                    options.libraryMemberConstantCb,
                    stat,
                    names,
                    tableConstants
                );

            size_t iterJumps = loopJumps.size();

            compileStat(stat->body);

            size_t contLabel = bytecode.emitLabel();

            for (size_t i = iterJumps; i < loopJumps.size(); ++i)
                if (loopJumps[i].type == LoopJump::Continue)
                    patchJump(stat, loopJumps[i].label, contLabel);
        }

        size_t endLabel = bytecode.emitLabel();

        for (size_t i = oldJumps; i < loopJumps.size(); ++i)
            if (loopJumps[i].type == LoopJump::Break)
                patchJump(stat, loopJumps[i].label, endLabel);

        loopJumps.resize(oldJumps);

        loops.pop_back();

        locstants[var].type = Constant::Type_Unknown;

        Compile::undoChanges(constants, exprChanges);
        Compile::undoChanges(locstants, localChanges);
    }

    void compileStatFor(AstStatFor* stat)
    {
        RegScope rs(this);

        if (options.optimizationLevel >= 2 && isConstant(stat->to) && isConstant(stat->from) && (!stat->step || isConstant(stat->step)))
            if (tryCompileUnrolledFor(stat, FInt::LuauCompileLoopUnrollThreshold, FInt::LuauCompileLoopUnrollThresholdMaxBoost))
                return;

        size_t oldLocals = localStack.size();
        size_t oldJumps = loopJumps.size();

        loops.push_back({oldLocals, oldLocals, nullptr});
        hasLoops = true;

        uint8_t regs = allocReg(stat, 3u);

        uint8_t varreg = regs + 2;
        uint32_t varregallocpc = bytecode.getDebugPC();

        if (Variable* il = variables.find(stat->var); il && il->written)
            varreg = allocReg(stat, 1u);

        compileExprTemp(stat->from, uint8_t(regs + 2));
        compileExprTemp(stat->to, uint8_t(regs + 0));

        if (stat->step)
            compileExprTemp(stat->step, uint8_t(regs + 1));
        else
            bytecode.emitABC(LOP_LOADN, uint8_t(regs + 1), 1, 0);

        size_t forLabel = bytecode.emitLabel();

        bytecode.emitAD(LOP_FORNPREP, regs, 0);

        size_t loopLabel = bytecode.emitLabel();

        if (varreg != regs + 2)
            bytecode.emitABC(LOP_MOVE, varreg, regs + 2, 0);

        pushLocal(stat->var, varreg, varregallocpc);

        compileStat(stat->body);

        closeLocals(oldLocals);
        popLocals(oldLocals);

        setDebugLine(stat);

        size_t contLabel = bytecode.emitLabel();

        size_t backLabel = bytecode.emitLabel();

        bytecode.emitAD(LOP_FORNLOOP, regs, 0);

        size_t endLabel = bytecode.emitLabel();

        patchJump(stat, forLabel, endLabel);
        patchJump(stat, backLabel, loopLabel);

        patchLoopJumps(stat, oldJumps, endLabel, contLabel);
        loopJumps.resize(oldJumps);

        loops.pop_back();
    }

    void compileStatForIn(AstStatForIn* stat)
    {
        RegScope rs(this);

        size_t oldLocals = localStack.size();
        size_t oldJumps = loopJumps.size();

        loops.push_back({oldLocals, oldLocals, nullptr});
        hasLoops = true;

        uint8_t regs = allocReg(stat, 3u);

        compileExprListTemp(stat->values, regs, 3, true);

        uint8_t vars = allocReg(stat, std::max(unsigned(stat->vars.size), 2u));
        LUAU_ASSERT(vars == regs + 3);
        uint32_t varsallocpc = bytecode.getDebugPC();

        LuauOpcode skipOp = LOP_FORGPREP;

        if (options.optimizationLevel >= 1 && stat->vars.size <= 2)
        {
            if (stat->values.size == 1 && stat->values.data[0]->is<AstExprCall>())
            {
                Builtin builtin = getBuiltin(stat->values.data[0]->as<AstExprCall>()->func, globals, variables);

                if (builtin.isGlobal("ipairs"))
                    skipOp = LOP_FORGPREP_INEXT;
                else if (builtin.isGlobal("pairs"))
                    skipOp = LOP_FORGPREP_NEXT;
            }
            else if (stat->values.size == 2 && (!getfenvUsed && !setfenvUsed))
            {
                Builtin builtin = getBuiltin(stat->values.data[0], globals, variables);

                if (builtin.isGlobal("next"))
                    skipOp = LOP_FORGPREP_NEXT;
            }
        }

        size_t skipLabel = bytecode.emitLabel();

        bytecode.emitAD(skipOp, regs, 0);

        size_t loopLabel = bytecode.emitLabel();

        for (size_t i = 0; i < stat->vars.size; ++i)
            pushLocal(stat->vars.data[i], uint8_t(vars + i), varsallocpc);

        compileStat(stat->body);

        closeLocals(oldLocals);
        popLocals(oldLocals);

        setDebugLine(stat);

        size_t contLabel = bytecode.emitLabel();

        size_t backLabel = bytecode.emitLabel();

        bytecode.emitAD(LOP_FORGLOOP, regs, 0);
        bytecode.emitAux((skipOp == LOP_FORGPREP_INEXT ? 0x80000000 : 0) | uint32_t(stat->vars.size));

        size_t endLabel = bytecode.emitLabel();

        patchJump(stat, skipLabel, backLabel);
        patchJump(stat, backLabel, loopLabel);

        patchLoopJumps(stat, oldJumps, endLabel, contLabel);
        loopJumps.resize(oldJumps);

        loops.pop_back();
    }

    struct Assignment
    {
        LValue lvalue;

        uint8_t conflictReg = kInvalidReg;
        uint8_t valueReg = kInvalidReg;
    };

    void resolveAssignConflicts(AstStat* stat, std::vector<Assignment>& vars, const AstArray<AstExpr*>& values)
    {
        struct Visitor : AstVisitor
        {
            Compiler* self;

            std::bitset<256> conflict;
            std::bitset<256> assigned;

            Visitor(Compiler* self)
                : self(self)
            {
            }

            bool visit(AstExprLocal* node) override
            {
                int reg = self->getLocalReg(node->local);

                if (reg >= 0 && assigned[reg])
                    conflict[reg] = true;

                return true;
            }
        };

        Visitor visitor(this);

        for (size_t i = 0; i < vars.size(); ++i)
        {
            const LValue& li = vars[i].lvalue;

            if (li.kind == LValue::Kind_Local)
            {
                if (i < values.size)
                    values.data[i]->visit(&visitor);

                visitor.assigned[li.reg] = true;
            }
        }

        for (size_t i = 0; i < vars.size(); ++i)
        {
            const LValue& li = vars[i].lvalue;

            if (li.kind != LValue::Kind_Local && i < values.size)
                values.data[i]->visit(&visitor);
        }

        for (size_t i = vars.size(); i < values.size; ++i)
            values.data[i]->visit(&visitor);

        for (const Assignment& var : vars)
        {
            const LValue& li = var.lvalue;

            if ((li.kind == LValue::Kind_IndexName || li.kind == LValue::Kind_IndexNumber || li.kind == LValue::Kind_IndexExpr) &&
                visitor.assigned[li.reg])
                visitor.conflict[li.reg] = true;

            if (li.kind == LValue::Kind_IndexExpr && visitor.assigned[li.index])
                visitor.conflict[li.index] = true;
        }

        for (Assignment& var : vars)
        {
            const LValue& li = var.lvalue;

            if (li.kind == LValue::Kind_Local && visitor.conflict[li.reg])
                var.conflictReg = allocReg(stat, 1u);
        }
    }

    void compileStatAssign(AstStatAssign* stat)
    {
        RegScope rs(this);

        if (stat->vars.size == 1 && stat->values.size == 1)
        {
            LValue var = compileLValue(stat->vars.data[0], rs);

            if (var.kind == LValue::Kind_Local)
            {
                compileExpr(stat->values.data[0], var.reg);
            }
            else
            {
                uint8_t reg = compileExprAuto(stat->values.data[0], rs);

                setDebugLine(stat->vars.data[0]);
                compileAssign(var, reg, stat->vars.data[0]);
            }
            return;
        }

        std::vector<Assignment> vars(stat->vars.size);

        for (size_t i = 0; i < stat->vars.size; ++i)
            vars[i].lvalue = compileLValue(stat->vars.data[i], rs);

        resolveAssignConflicts(stat, vars, stat->values);

        for (size_t i = 0; i < stat->vars.size && i < stat->values.size; ++i)
        {
            AstExpr* value = stat->values.data[i];

            if (i + 1 == stat->values.size && stat->vars.size > stat->values.size)
            {

                unsigned rest = unsigned(stat->vars.size - stat->values.size + 1);
                uint8_t temp = allocReg(stat, rest);

                compileExprTempN(value, temp, uint8_t(rest), true);

                for (size_t j = i; j < stat->vars.size; ++j)
                    vars[j].valueReg = uint8_t(temp + (j - i));
            }
            else
            {
                Assignment& var = vars[i];

                if (var.lvalue.kind == LValue::Kind_Local)
                {
                    var.valueReg = (var.conflictReg == kInvalidReg) ? var.lvalue.reg : var.conflictReg;

                    compileExpr(stat->values.data[i], var.valueReg);
                }
                else
                {
                    var.valueReg = compileExprAuto(stat->values.data[i], rs);
                }
            }
        }

        for (size_t i = stat->vars.size; i < stat->values.size; ++i)
            compileExprSide(stat->values.data[i]);

        size_t varPos = 0;
        for (const Assignment& var : vars)
        {
            LUAU_ASSERT(var.valueReg != kInvalidReg);

            if (var.lvalue.kind != LValue::Kind_Local)
            {
                setDebugLine(var.lvalue.location);

                if (varPos < stat->vars.size)
                    compileAssign(var.lvalue, var.valueReg, stat->vars.data[varPos]);
                else
                    compileAssign(var.lvalue, var.valueReg, nullptr);
            }

            varPos++;
        }

        for (const Assignment& var : vars)
        {
            if (var.lvalue.kind == LValue::Kind_Local && var.valueReg != var.lvalue.reg)
                bytecode.emitABC(LOP_MOVE, var.lvalue.reg, var.valueReg, 0);
        }
    }

    void compileStatCompoundAssign(AstStatCompoundAssign* stat)
    {
        RegScope rs(this);

        LValue var = compileLValue(stat->var, rs);

        uint8_t target = (var.kind == LValue::Kind_Local) ? var.reg : allocReg(stat, 1u);

        switch (stat->op)
        {
        case AstExprBinary::Add:
        case AstExprBinary::Sub:
        case AstExprBinary::Mul:
        case AstExprBinary::Div:
        case AstExprBinary::FloorDiv:
        case AstExprBinary::Mod:
        case AstExprBinary::Pow:
        {
            if (var.kind != LValue::Kind_Local)
                compileLValueUse(var, target, false, stat->var);

            int32_t rc = getConstantNumber(stat->value);

            if (rc >= 0 && rc <= 255)
            {
                bytecode.emitABC(getBinaryOpArith(stat->op, true), target, target, uint8_t(rc));
            }
            else
            {
                uint8_t rr = compileExprAuto(stat->value, rs);

                bytecode.emitABC(getBinaryOpArith(stat->op), target, target, rr);

                if (var.kind != LValue::Kind_Local)
                    hintTemporaryRegType(stat->var, target, LBC_TYPE_NUMBER, 1);

                hintTemporaryExprRegType(stat->value, rr, LBC_TYPE_NUMBER, 1);
            }
        }
        break;

        case AstExprBinary::Concat:
        {
            std::vector<AstExpr*> args = {stat->value};

            unrollConcats(args);

            uint8_t regs = allocReg(stat, unsigned(1 + args.size()));

            compileLValueUse(var, regs, false, stat->var);

            for (size_t i = 0; i < args.size(); ++i)
                if (FFlag::LuauCompileConcatTargetTop)
                    compileExprTempTop(args[i], uint8_t(regs + 1 + i));
                else
                    compileExprTemp(args[i], uint8_t(regs + 1 + i));

            bytecode.emitABC(LOP_CONCAT, target, regs, uint8_t(regs + args.size()));
        }
        break;

        default:
            LUAU_ASSERT(!"Unexpected compound assignment operation");
        }

        if (var.kind != LValue::Kind_Local)
            compileAssign(var, target, stat->var);
    }

    void compileStatFunction(AstStatFunction* stat)
    {

        if (int reg = getExprLocalReg(stat->name); reg >= 0)
        {
            compileExpr(stat->func, uint8_t(reg));
            return;
        }

        RegScope rs(this);
        uint8_t reg = allocReg(stat, 1u);

        compileExprTemp(stat->func, reg);

        LValue var = compileLValue(stat->name, rs);
        compileAssign(var, reg, stat->name);
    }

    void compileStat(AstStat* node)
    {
        setDebugLine(node);

        if (options.coverageLevel >= 1 && needsCoverage(node))
        {
            bytecode.emitABC(LOP_COVERAGE, 0, 0, 0);
        }

        if (AstStatBlock* stat = node->as<AstStatBlock>())
        {
            RegScope rs(this);

            size_t oldLocals = localStack.size();
            if (FFlag::LuauExportValueSyntax)
                blockDepth++;

            bool terminatesEarly = false;

            for (size_t i = 0; i < stat->body.size; ++i)
            {
                AstStat* bodyStat = stat->body.data[i];

                if (FFlag::LuauCompileReuseLocalRegs)
                    popStatLocals(stat, bodyStat, 0u);

                compileStat(bodyStat);

                if (FFlag::LuauCompileCleanBlockDeadClose)
                {
                    if (alwaysTerminates(bodyStat))
                    {
                        terminatesEarly = true;
                        break;
                    }
                }
                else
                {
                    if (alwaysTerminates(bodyStat))
                        break;
                }
            }

            if (FFlag::LuauExportValueSyntax)
                blockDepth--;

            if (FFlag::LuauCompileCleanBlockDeadClose)
            {
                if (!terminatesEarly)
                    closeLocals(oldLocals);
            }
            else
            {
                closeLocals(oldLocals);
            }

            popLocals(oldLocals);
        }
        else if (AstStatIf* stat = node->as<AstStatIf>())
        {
            compileStatIf(stat);
        }
        else if (AstStatWhile* stat = node->as<AstStatWhile>())
        {
            compileStatWhile(stat);
        }
        else if (AstStatRepeat* stat = node->as<AstStatRepeat>())
        {
            compileStatRepeat(stat);
        }
        else if (node->is<AstStatBreak>())
        {
            LUAU_ASSERT(!loops.empty());

            closeLocals(loops.back().localOffset);

            size_t label = bytecode.emitLabel();

            bytecode.emitAD(LOP_JUMP, 0, 0);

            loopJumps.push_back({LoopJump::Break, label});
        }
        else if (AstStatContinue* stat = node->as<AstStatContinue>())
        {
            LUAU_ASSERT(!loops.empty());

            if (!loops.back().continueUsed)
                loops.back().continueUsed = stat;

            closeLocals(loops.back().localOffsetContinue);

            size_t label = bytecode.emitLabel();

            bytecode.emitAD(LOP_JUMP, 0, 0);

            loopJumps.push_back({LoopJump::Continue, label});
        }
        else if (AstStatReturn* stat = node->as<AstStatReturn>())
        {
            if (options.optimizationLevel >= 2 && !inlineFrames.empty())
                compileInlineReturn(stat, false);
            else
                compileStatReturn(stat);
        }
        else if (AstStatExpr* stat = node->as<AstStatExpr>())
        {

            if (AstExprCall* expr = stat->expr->as<AstExprCall>())
            {
                uint8_t target = uint8_t(regTop);

                compileExprCall(expr, target, 0);
            }
            else
            {
                compileExprSide(stat->expr);
            }
        }
        else if (AstStatLocal* stat = node->as<AstStatLocal>())
        {
            if (FFlag::LuauExportValueSyntax)
            {
                for (auto& local : stat->vars)
                {
                    checkExportedLocal(local, stat->location);
                }
            }
            compileStatLocal(stat);
        }
        else if (AstStatFor* stat = node->as<AstStatFor>())
        {
            compileStatFor(stat);
        }
        else if (AstStatForIn* stat = node->as<AstStatForIn>())
        {
            compileStatForIn(stat);
        }
        else if (AstStatAssign* stat = node->as<AstStatAssign>())
        {
            compileStatAssign(stat);
        }
        else if (AstStatCompoundAssign* stat = node->as<AstStatCompoundAssign>())
        {
            compileStatCompoundAssign(stat);
        }
        else if (AstStatFunction* stat = node->as<AstStatFunction>())
        {
            compileStatFunction(stat);
        }
        else if (AstStatLocalFunction* stat = node->as<AstStatLocalFunction>())
        {
            if (FFlag::LuauExportValueSyntax && !FFlag::LuauOptimizeExportTable && stat->name->isExported)
            {
                checkExportedLocal(stat->name, stat->location);

                ensureExportTable(stat);

                RegScope rs(this);
                uint8_t var = allocReg(stat, 1u);
                compileExprFunction(stat->func, var);

                int32_t cid = bytecode.addConstantString(sref(stat->name->name));
                if (cid < 0)
                    CompileError::raise(stat->name->location, "Exceeded constant limit; simplify the code to compile");

                uint8_t tableReg = getExportTableReg(stat);
                bytecode.emitABC(LOP_SETTABLEKS, var, tableReg, uint8_t(BytecodeBuilder::getStringHash(sref(stat->name->name))));
                bytecode.emitAux(cid);
            }
            else
            {
                uint8_t var = kInvalidReg;

                if (FFlag::LuauCompileReuseLocalRegs)
                {
                    if (!tryReuseLocalReg(stat->name, var))
                        var = allocReg(stat, 1u);
                }
                else
                {
                    var = allocReg(stat, 1u);
                }

                pushLocal(stat->name, var, kDefaultAllocPc);
                compileExprFunction(stat->func, var);

                Local& l = locals[stat->name];

                l.debugpc = bytecode.getDebugPC();
            }
        }
        else if (AstStatTypeAlias* alias = node->as<AstStatTypeAlias>())
        {
            if (FFlag::LuauExportedTypesParticipateInScc && alias->exported && atTopLevel())
                exports.hasTypeExports = true;
        }
        else if (node->is<AstStatTypeFunction>())
        {
        }
        else if (FFlag::DebugLuauUserDefinedClasses && node->is<AstStatClass>())
        {
            compileClassDeclaration(node->as<AstStatClass>());
        }
        else
        {
            LUAU_ASSERT(!"Unknown statement type");
        }
    }

    void validateContinueUntil(AstStat* cont, AstExpr* condition, AstStatBlock* body, size_t start)
    {
        UndefinedLocalVisitor visitor(this);

        for (size_t i = start; i < body->body.size; ++i)
        {
            if (AstStatLocal* stat = body->body.data[i]->as<AstStatLocal>())
            {
                for (AstLocal* local : stat->vars)
                    visitor.locals.insert(local);
            }
            else if (AstStatLocalFunction* stat = body->body.data[i]->as<AstStatLocalFunction>())
            {
                visitor.locals.insert(stat->name);
            }
        }

        condition->visit(&visitor);

        if (visitor.undef)
            CompileError::raise(
                condition->location,
                "Local %s used in the repeat..until condition is undefined because continue statement on line %d jumps over it",
                visitor.undef->name.value,
                cont->location.begin.line + 1
            );
    }

    void preallocateHoistedClasses(AstStatBlock* body)
    {
        LUAU_ASSERT(FFlag::DebugLuauUserDefinedClasses);

        for (AstStat* stat : body->body)
        {
            if (AstStatClass* decl = stat->as<AstStatClass>())
            {
                uint8_t reg = allocReg(decl, 1u);
                pushLocal(decl->name, reg, kDefaultAllocPc);
                bytecode.emitABC(LOP_LOADNIL, reg, 0, 0);
            }
        }
    }

    void gatherConstUpvals(AstExprFunction* func)
    {
        ConstUpvalueVisitor visitor(this);
        func->body->visit(&visitor);

        for (AstLocal* local : visitor.upvals)
            getUpval(local);
    }

    void pushLocal(AstLocal* local, uint8_t reg, uint32_t allocpc)
    {
        if (localStack.size() >= kMaxLocalCount)
            CompileError::raise(
                local->location, "Out of local registers when trying to allocate %s: exceeded limit %d", local->name.value, kMaxLocalCount
            );

        localStack.push_back(local);

        Local& l = locals[local];

        LUAU_ASSERT(!l.allocated);

        l.reg = reg;
        l.allocated = true;
        l.debugpc = bytecode.getDebugPC();
        l.allocpc = allocpc == kDefaultAllocPc ? l.debugpc : allocpc;

        if (FFlag::LuauCompileMoveElision)
            regCaptured[reg] = l.captured;

        if (FFlag::LuauCompileReuseLocalRegs)
            localUses[reg]++;
    }

    bool areLocalsCaptured(size_t start)
    {
        LUAU_ASSERT(start <= localStack.size());

        for (size_t i = start; i < localStack.size(); ++i)
        {
            Local* l = locals.find(localStack[i]);
            LUAU_ASSERT(l);

            if (l->captured)
                return true;
        }

        return false;
    }

    void closeLocals(size_t start)
    {
        LUAU_ASSERT(start <= localStack.size());

        bool captured = false;
        uint8_t captureReg = 255;

        for (size_t i = start; i < localStack.size(); ++i)
        {
            Local* l = locals.find(localStack[i]);
            LUAU_ASSERT(l);

            if (l->captured)
            {
                captured = true;
                captureReg = std::min(captureReg, l->reg);
            }
        }

        if (captured)
        {
            bytecode.emitABC(LOP_CLOSEUPVALS, captureReg, 0, 0);
        }
    }

    struct Local
    {
        uint8_t reg = 0;
        bool allocated = false;
        bool captured = false;
        bool reused = false;
        uint32_t debugpc = 0;
        uint32_t allocpc = 0;
    };

    void recordLocalDebugInfo(AstLocal* astLocal, Local* l, bool isArgument, uint32_t endpc)
    {
        if (options.debugLevel >= 2)
        {
            bytecode.pushDebugLocal(sref(astLocal->name), l->reg, l->debugpc, endpc);
        }

        if (options.typeInfoLevel >= 1 && !isArgument)
        {
            LuauBytecodeType ty = LBC_TYPE_ANY;

            if (LuauBytecodeType* recordedTy = localTypes.find(astLocal))
                ty = *recordedTy;

            bytecode.pushLocalTypeInfo(ty, l->reg, l->allocpc, endpc);
        }
    }

    bool releaseLocal(Local* l)
    {
        LUAU_ASSERT(FFlag::LuauCompileReuseLocalRegs);

        l->allocated = false;

        if (FFlag::LuauCompileMoveElision)
            regCaptured[l->reg] = false;

        LUAU_ASSERT(localUses[l->reg] != 0);
        localUses[l->reg]--;
        return localUses[l->reg] == 0;
    }

    void popLocals(size_t start)
    {
        LUAU_ASSERT(start <= localStack.size());

        for (size_t i = start; i < localStack.size(); ++i)
        {
            Local* l = locals.find(localStack[i]);
            LUAU_ASSERT(l);

            if (FFlag::LuauCompileReuseLocalRegs)
            {
                if (l->reused)
                {

                    auto it = std::lower_bound(
                        freeLocalRegs.begin(),
                        freeLocalRegs.end(),
                        l->reg,
                        [](const FreeLocal& el, uint8_t pred)
                        {
                            return el.reg < pred;
                        }
                    );
                    if (it != freeLocalRegs.end() && it->reg == l->reg)
                    {
                        recordLocalDebugInfo(it->astLocal, &it->local, it->isArgument, bytecode.getDebugPC());
                        freeLocalRegs.erase(it);
                    }

                    l->allocated = false;
                    l->reused = false;
                }
                else if (l->allocated)
                {
                    releaseLocal(l);
                    recordLocalDebugInfo(localStack[i], l, i < argCount, bytecode.getDebugPC());
                }
            }
            else
            {
                LUAU_ASSERT(l->allocated);
                l->allocated = false;

                if (FFlag::LuauCompileMoveElision)
                    regCaptured[l->reg] = false;

                if (options.debugLevel >= 2)
                {
                    uint32_t debugpc = bytecode.getDebugPC();

                    bytecode.pushDebugLocal(sref(localStack[i]->name), l->reg, l->debugpc, debugpc);
                }

                if (options.typeInfoLevel >= 1 && i >= argCount)
                {
                    uint32_t debugpc = bytecode.getDebugPC();
                    LuauBytecodeType ty = LBC_TYPE_ANY;

                    if (LuauBytecodeType* recordedTy = localTypes.find(localStack[i]))
                        ty = *recordedTy;

                    bytecode.pushLocalTypeInfo(ty, l->reg, l->allocpc, debugpc);
                }
            }
        }

        localStack.resize(start);
    }

    void popStatLocals(AstStatBlock* owner, AstStat* beforeStat, size_t start)
    {
        if (options.optimizationLevel == 0)
            return;

        LUAU_ASSERT(FFlag::LuauCompileReuseLocalRegs);
        LUAU_ASSERT(start <= localStack.size());

        for (size_t i = start; i < localStack.size(); ++i)
        {
            Local* l = locals.find(localStack[i]);
            LUAU_ASSERT(l);

            if (!l->allocated || l->reused)
                continue;

            if (l->captured)
                continue;

            auto var = variables.find(localStack[i]);

            if (!var)
                continue;

            if (var->owner != owner || var->nonLexicalUse)
                continue;

            Position localEnd = var->lastUsed ? var->lastUsed->location.end : Position::missing();
            Position statStart = beforeStat->location.begin;

            if (!var->lastUsed || statStart.line > localEnd.line || (statStart.line == localEnd.line && statStart.column > localEnd.column))
            {
                if (releaseLocal(l))
                {
                    FreeLocal free;
                    free.reg = l->reg;
                    free.local = *l;
                    free.astLocal = localStack[i];
                    free.isArgument = i < argCount;

                    auto it = std::lower_bound(
                        freeLocalRegs.begin(),
                        freeLocalRegs.end(),
                        l->reg,
                        [](const FreeLocal& el, uint8_t pred)
                        {
                            return el.reg < pred;
                        }
                    );
                    freeLocalRegs.insert(it, free);

                    l->reused = true;
                }
                else
                {
                    recordLocalDebugInfo(localStack[i], l, i < argCount, bytecode.getDebugPC());
                }
            }
        }
    }

    void patchJump(AstNode* node, size_t label, size_t target)
    {
        if (!bytecode.patchJumpD(label, target))
            CompileError::raise(node->location, "Exceeded jump distance limit; simplify the code to compile");
    }

    void patchJumps(AstNode* node, std::vector<size_t>& labels, size_t target)
    {
        for (size_t l : labels)
            patchJump(node, l, target);
    }

    void patchLoopJumps(AstNode* node, size_t oldJumps, size_t endLabel, size_t contLabel)
    {
        LUAU_ASSERT(oldJumps <= loopJumps.size());

        for (size_t i = oldJumps; i < loopJumps.size(); ++i)
        {
            const LoopJump& lj = loopJumps[i];

            switch (lj.type)
            {
            case LoopJump::Break:
                patchJump(node, lj.label, endLabel);
                break;

            case LoopJump::Continue:
                patchJump(node, lj.label, contLabel);
                break;

            default:
                LUAU_ASSERT(!"Unknown loop jump type");
            }
        }
    }

    uint8_t allocReg(AstNode* node, unsigned int count)
    {
        unsigned int top = regTop;
        if (top + count > kMaxRegisterCount)
            CompileError::raise(node->location, "Out of registers when trying to allocate %d registers: exceeded limit %d", count, kMaxRegisterCount);

        regTop += count;
        stackSize = std::max(stackSize, regTop);

        return uint8_t(top);
    }

    template<typename T>
    uint8_t allocReg(AstNode* node, T count) = delete;

    bool tryReuseLocalReg(AstLocal* local, uint8_t& reg)
    {
        LUAU_ASSERT(FFlag::LuauCompileReuseLocalRegs);

        if (local->isExported || freeLocalRegs.empty())
            return false;

        Variable* lv = variables.find(local);

        if (!lv)
            return false;

        Local* l = locals.find(local);

        if (l && l->captured)
            return false;

        FreeLocal free = freeLocalRegs.back();
        freeLocalRegs.pop_back();

        recordLocalDebugInfo(free.astLocal, &free.local, free.isArgument, bytecode.getDebugPC());
        reg = free.reg;

        LUAU_ASSERT(reg < regTop);
        return true;
    }

    void setDebugLine(AstNode* node)
    {
        if (options.debugLevel >= 1)
            bytecode.setDebugLine(node->location.begin.line + 1);
    }

    void setDebugLine(const Location& location)
    {
        if (options.debugLevel >= 1)
            bytecode.setDebugLine(location.begin.line + 1);
    }

    void setDebugLineEnd(AstNode* node)
    {
        if (options.debugLevel >= 1)
            bytecode.setDebugLine(node->location.end.line + 1);
    }

    bool needsCoverage(AstNode* node)
    {
        return !node->is<AstStatBlock>() && !node->is<AstStatTypeAlias>();
    }

    void hintTemporaryRegType(AstExpr* expr, int reg, LuauBytecodeType expectedType, int instLength)
    {

        if (LuauBytecodeType* ty = exprTypes.find(expr))
        {
            if (*ty != expectedType)
                bytecode.pushLocalTypeInfo(*ty, reg, bytecode.getDebugPC() - instLength, bytecode.getDebugPC());
        }
    }

    void hintTemporaryExprRegType(AstExpr* expr, int reg, LuauBytecodeType expectedType, int instLength)
    {

        if (!getExprLocal(expr))
            hintTemporaryRegType(expr, reg, expectedType, instLength);
    }

    struct FenvVisitor : AstVisitor
    {
        bool& getfenvUsed;
        bool& setfenvUsed;

        FenvVisitor(bool& getfenvUsed, bool& setfenvUsed)
            : getfenvUsed(getfenvUsed)
            , setfenvUsed(setfenvUsed)
        {
        }

        bool visit(AstExprGlobal* node) override
        {
            if (node->name == "getfenv")
                getfenvUsed = true;
            if (node->name == "setfenv")
                setfenvUsed = true;

            return false;
        }
    };

    struct FunctionVisitor : AstVisitor
    {
        std::vector<AstExprFunction*>& functions;
        bool hasTypes = false;
        bool hasNativeFunction = false;

        FunctionVisitor(std::vector<AstExprFunction*>& functions)
            : functions(functions)
        {
            functions.reserve(16);
        }

        bool visit(AstExprFunction* node) override
        {
            node->body->visit(this);

            for (AstLocal* arg : node->args)
                hasTypes |= arg->annotation != nullptr;

            LUAU_ASSERT(functions.end() == std::find(functions.begin(), functions.end(), node));
            functions.push_back(node);

            if (!hasNativeFunction && node->hasNativeAttribute())
                hasNativeFunction = true;

            return false;
        }

        bool visit(AstStatTypeFunction* node) override
        {
            return false;
        }
    };

    struct UndefinedLocalVisitor : AstVisitor
    {
        UndefinedLocalVisitor(Compiler* self)
            : self(self)
            , undef(nullptr)
        {
        }

        void check(AstLocal* local)
        {
            if (!undef && locals.contains(local))
                undef = local;
        }

        bool visit(AstExprLocal* node) override
        {
            if (!node->upvalue)
                check(node->local);

            return false;
        }

        bool visit(AstExprFunction* node) override
        {
            const Function* f = self->functions.find(node);
            LUAU_ASSERT(f);

            for (AstLocal* uv : f->upvals)
            {
                LUAU_ASSERT(uv->functionDepth < node->functionDepth);

                if (uv->functionDepth == node->functionDepth - 1)
                    check(uv);
            }

            return false;
        }

        Compiler* self;
        AstLocal* undef;
        DenseHashSet<AstLocal*> locals;
    };

    struct ConstUpvalueVisitor : AstVisitor
    {
        ConstUpvalueVisitor(Compiler* self)
            : self(self)
        {
        }

        bool visit(AstExprLocal* node) override
        {
            if (node->upvalue && self->isConstant(node))
            {
                upvals.push_back(node->local);
            }

            return false;
        }

        bool visit(AstExprFunction* node) override
        {
            return false;
        }

        Compiler* self;
        std::vector<AstLocal*> upvals;
    };

    enum class ReturnKind
    {
        None,
        Expression,
        Parameter,
        Local,

        Unknown
    };

    struct ReturnVisitor : AstVisitor
    {
        Compiler* self = nullptr;
        AstExprFunction* func = nullptr;

        bool returnsOne = true;
        ReturnKind returnKind = ReturnKind::None;
        AstLocal* returnLocal = nullptr;

        ReturnVisitor(Compiler* self, AstExprFunction* func)
            : self(self)
            , func(func)
        {
        }

        bool visit(AstExpr* expr) override
        {
            return false;
        }

        bool visit(AstStatReturn* stat) override
        {
            if (FFlag::LuauCompileMoveElision)
            {
                if (stat->list.size == 1 && !self->isExprMultRet(stat->list.data[0]))
                {
                    if (AstExprLocal* exprLocal = unwrapExprOfType<AstExprLocal>(stat->list.data[0]))
                    {
                        ReturnKind kind = ReturnKind::Local;
                        AstLocal* local = exprLocal->local;

                        for (auto el : func->args)
                        {
                            if (el == local)
                            {
                                kind = ReturnKind::Parameter;
                                break;
                            }
                        }

                        if (exprLocal->upvalue)
                        {
                            kind = ReturnKind::Expression;
                            local = nullptr;
                        }

                        if (returnKind == ReturnKind::None)
                        {
                            returnKind = kind;
                            returnLocal = local;
                        }
                        else if (returnKind != kind || returnLocal != local)
                        {
                            returnKind = ReturnKind::Unknown;
                            returnLocal = nullptr;
                        }
                    }
                    else
                    {
                        if (returnKind == ReturnKind::None)
                        {
                            returnKind = ReturnKind::Expression;
                        }
                        else if (returnKind != ReturnKind::Expression)
                        {
                            returnKind = ReturnKind::Unknown;
                            returnLocal = nullptr;
                        }
                    }
                }
                else
                {
                    returnsOne = false;
                    returnKind = ReturnKind::Unknown;
                    returnLocal = nullptr;
                }
            }
            else
            {
                returnsOne &= stat->list.size == 1 && !self->isExprMultRet(stat->list.data[0]);
            }

            return false;
        }
    };

    struct RegScope
    {
        RegScope(Compiler* self)
            : self(self)
            , oldTop(self->regTop)
        {
        }

        RegScope(Compiler* self, unsigned int top)
            : self(self)
            , oldTop(self->regTop)
        {
            LUAU_ASSERT(top <= self->regTop);
            self->regTop = top;
        }

        ~RegScope()
        {
            self->regTop = oldTop;
        }

        Compiler* self;
        unsigned int oldTop;
    };

    struct Function
    {
        uint32_t id;
        std::vector<AstLocal*> upvals;

        uint64_t costModel = 0;
        unsigned int stackSize = 0;
        bool canInline = false;
        bool returnsOne = false;

        ReturnKind returnKind = ReturnKind::None;
        AstLocal* returnLocal = nullptr;
        bool returnLocalCaptured = false;
    };

    struct LoopJump
    {
        enum Type
        {
            Break,
            Continue
        };

        Type type;
        size_t label;
    };

    struct Loop
    {
        size_t localOffset;
        size_t localOffsetContinue;

        AstStatContinue* continueUsed;
    };

    struct InlineArg
    {
        AstLocal* local;

        uint8_t reg;
        Constant value;
        uint32_t allocpc;

        AstExpr* init;
    };

    struct InlineFrame
    {
        AstExprFunction* func;

        size_t localOffset;

        uint8_t target;
        uint8_t targetCount;

        AstLocal* resultLocal = nullptr;

        std::vector<size_t> returnJumps;
    };

    struct Capture
    {
        LuauCaptureType type;
        uint8_t data;
    };

    BytecodeBuilder& bytecode;

    CompileOptions options;

    DenseHashMap<AstExprFunction*, Function> functions;
    DenseHashMap<AstLocal*, Local> locals;
    DenseHashMap<AstName, Global> globals;
    DenseHashMap<AstLocal*, Variable> variables;
    DenseHashMap<AstExpr*, Constant> constants;
    DenseHashMap<AstLocal*, Constant> locstants;
    DenseHashMap<AstLocal*, TableConstantKind> tableConstants;
    DenseHashMap<AstExprTable*, TableShape> tableShapes;
    DenseHashMap<AstExprCall*, int> builtins;
    DenseHashMap<AstName, uint8_t> userdataTypes;
    DenseHashMap<AstExprFunction*, std::string> functionTypes;
    DenseHashMap<AstLocal*, LuauBytecodeType> localTypes;
    DenseHashMap<AstExpr*, LuauBytecodeType> exprTypes;
    DenseHashMap<AstName, AstLocal*> classLocals{};

    DenseHashMap<AstExprCall*, int> inlineBuiltins;
    DenseHashMap<AstExprCall*, int> inlineBuiltinsBackup;

    Compile::ExprConstantChangeLog exprChanges;
    Compile::LocalConstantChangeLog localChanges;

    BuiltinAstTypes builtinTypes;
    AstNameTable& names;

    const DenseHashMap<AstExprCall*, int>* builtinsFold = nullptr;
    bool builtinsFoldLibraryK = false;

    unsigned int regTop = 0;
    unsigned int stackSize = 0;
    size_t argCount = 0;
    bool hasLoops = false;
    bool hasMultiRet = false;
    AstExprFunction* currentFunction = nullptr;

    size_t blockDepth = 0;

    bool getfenvUsed = false;
    bool setfenvUsed = false;

    std::vector<AstLocal*> localStack;
    std::array<bool, kMaxRegisterCount> regCaptured{};
    std::vector<AstLocal*> upvals;
    std::vector<LoopJump> loopJumps;
    std::vector<Loop> loops;
    std::vector<InlineFrame> inlineFrames;
    std::vector<Capture> captures;

    struct FreeLocal
    {
        uint8_t reg = 0;

        Local local;
        AstLocal* astLocal = nullptr;
        bool isArgument = false;
    };
    std::array<int, kMaxRegisterCount> localUses{};
    std::vector<FreeLocal> freeLocalRegs;

    struct Exports
    {
        AstLocal exportTableLocal;
        DenseHashMap<AstLocal*, uint8_t> exportedClasses;
        DenseHashSet<AstLocal*> exportedFunctions;
        std::vector<AstLocal*> exportedVariables;
        int32_t exportedTableCid = -1;
        bool hasExports = false;
        bool hasTypeExports = false;

        explicit Exports(AstLocal tableLocal)
            : exportTableLocal(tableLocal)
        {
        }

        bool isEmpty() const
        {
            return !hasExports && exportedClasses.empty() && exportedFunctions.empty() && exportedVariables.empty();
        }
    };

    Exports exports;
};

static void setCompileOptionsForNativeCompilation(CompileOptions& options)
{
    options.optimizationLevel = 2;
    options.typeInfoLevel = 1;
}

void compileOrThrow(BytecodeBuilder& bytecode, const ParseResult& parseResult, AstNameTable& names, const CompileOptions& inputOptions)
{
    LUAU_TIMETRACE_SCOPE("compileOrThrow", "Compiler");

    LUAU_ASSERT(parseResult.root);
    LUAU_ASSERT(parseResult.errors.empty());

    CompileOptions options = inputOptions;
    uint8_t mainFlags = 0;

    for (const HotComment& hc : parseResult.hotcomments)
    {
        if (hc.header && hc.content.compare(0, 9, "optimize ") == 0)
            options.optimizationLevel = std::max(0, std::min(2, atoi(hc.content.c_str() + 9)));

        if (hc.header && hc.content == "native")
        {
            mainFlags |= LPF_NATIVE_MODULE;
            setCompileOptionsForNativeCompilation(options);
        }
    }

    AstStatBlock* root = parseResult.root;

    std::vector<AstExprFunction*> functions;
    Compiler::FunctionVisitor functionVisitor(functions);
    root->visit(&functionVisitor);

    if (functionVisitor.hasNativeFunction)
        setCompileOptionsForNativeCompilation(options);

    Compiler compiler(bytecode, options, names);

    assignMutable(compiler.globals, names, options.mutableGlobals);

    if (FFlag::LuauOptimizeExportTable)
        trackValues(
            compiler.globals, compiler.variables, compiler.classLocals, compiler.exports.exportedFunctions, compiler.exports.exportedVariables, root
        );
    else
        trackValues_DEPRECATED(compiler.globals, compiler.variables, compiler.classLocals, root);

    if (options.optimizationLevel >= 1 && (names.get("getfenv").value || names.get("setfenv").value))
    {
        Compiler::FenvVisitor fenvVisitor(compiler.getfenvUsed, compiler.setfenvUsed);
        root->visit(&fenvVisitor);
    }

    if (options.optimizationLevel >= 2 && (!compiler.getfenvUsed && !compiler.setfenvUsed))
    {
        compiler.builtinsFold = &compiler.builtins;

        if (AstName math = names.get("math"); math.value && getGlobalState(compiler.globals, math) == Global::Default)
        {
            compiler.builtinsFoldLibraryK = true;
        }
        else if (const char* const* ptr = options.librariesWithKnownMembers)
        {
            for (; *ptr; ++ptr)
            {
                if (AstName name = names.get(*ptr); name.value && getGlobalState(compiler.globals, name) == Global::Default)
                {
                    compiler.builtinsFoldLibraryK = true;
                    break;
                }
            }
        }
    }

    if (options.optimizationLevel >= 1)
    {

        analyzeBuiltins(compiler.builtins, compiler.globals, compiler.variables, options, root, names);

        buildTableConstantMap(compiler.tableConstants, compiler.variables, root);

        foldConstants(
            compiler.constants,
            compiler.variables,
            compiler.locstants,
            compiler.builtinsFold,
            compiler.builtinsFoldLibraryK,
            options.vectorPrecision == 1,
            options.libraryMemberConstantCb,
            root,
            names,
            compiler.tableConstants
        );

        predictTableShapes(compiler.tableShapes, root);
    }

    if (const char* const* ptr = options.userdataTypes)
    {
        for (; *ptr; ++ptr)
        {

            if (AstName name = names.get(*ptr); name.value)
                compiler.userdataTypes[name] = bytecode.addUserdataType(name.value);
        }

        if (uintptr_t(ptr - options.userdataTypes) > (LBC_TYPE_TAGGED_USERDATA_END - LBC_TYPE_TAGGED_USERDATA_BASE))
            CompileError::raise(root->location, "Exceeded userdata type limit in the compilation options");
    }

    if (options.typeInfoLevel >= 1 || options.optimizationLevel >= 2)
        buildTypeMap(
            compiler.functionTypes,
            compiler.localTypes,
            compiler.exprTypes,
            root,
            options.vectorType,
            compiler.userdataTypes,
            compiler.builtinTypes,
            compiler.builtins,
            compiler.globals,
            options.libraryMemberTypeCb,
            bytecode
        );

    for (AstExprFunction* expr : functions)
    {
        uint8_t protoflags = 0;
        compiler.compileFunction(expr, protoflags);

        if ((protoflags & LPF_NATIVE_FUNCTION) && !(mainFlags & LPF_NATIVE_MODULE))
            mainFlags |= LPF_NATIVE_FUNCTION;
    }

    AstExprFunction main(
        root->location,
        AstArray<AstAttr*>({nullptr, 0}),
        AstArray<AstGenericType*>(),
        AstArray<AstGenericTypePack*>(),
        nullptr,
        AstArray<AstLocal*>(),
        true,
        Luau::Location(),
        root,
        0,
        AstName(),
        nullptr
    );
    uint32_t mainid = compiler.compileFunction(&main, mainFlags);

    const Compiler::Function* mainf = compiler.functions.find(&main);
    LUAU_ASSERT(mainf && mainf->upvals.empty());

    bytecode.setMainFunction(mainid);
    bytecode.finalize();
}

void compileOrThrow(BytecodeBuilder& bytecode, const std::string& source, const CompileOptions& options, const ParseOptions& parseOptions)
{
    Allocator allocator;
    AstNameTable names(allocator);
    ParseResult result = Parser::parse(source.c_str(), source.size(), names, allocator, parseOptions);

    if (!result.errors.empty())
        throw ParseErrors(result.errors);

    compileOrThrow(bytecode, result, names, options);
}

std::string compile(const std::string& source, const CompileOptions& options, const ParseOptions& parseOptions, BytecodeEncoder* encoder)
{
    LUAU_TIMETRACE_SCOPE("compile", "Compiler");

    Allocator allocator;
    AstNameTable names(allocator);
    ParseResult result = Parser::parse(source.c_str(), source.size(), names, allocator, parseOptions);

    if (!result.errors.empty())
    {

        const Luau::ParseError& parseError = result.errors.front();
        std::string error = format(":%d: %s", parseError.getLocation().begin.line + 1, parseError.what());

        return BytecodeBuilder::getError(error);
    }

    try
    {
        BytecodeBuilder bcb(encoder);
        compileOrThrow(bcb, result, names, options);

        return bcb.getBytecode();
    }
    catch (CompileError& e)
    {
        std::string error = format(":%d: %s", e.getLocation().begin.line + 1, e.what());
        return BytecodeBuilder::getError(error);
    }
}

void setCompileConstantNil(CompileConstant* constant)
{
    Compile::Constant* target = reinterpret_cast<Compile::Constant*>(constant);

    target->type = Compile::Constant::Type_Nil;
}

void setCompileConstantBoolean(CompileConstant* constant, bool b)
{
    Compile::Constant* target = reinterpret_cast<Compile::Constant*>(constant);

    target->type = Compile::Constant::Type_Boolean;
    target->valueBoolean = b;
}

void setCompileConstantNumber(CompileConstant* constant, double n)
{
    Compile::Constant* target = reinterpret_cast<Compile::Constant*>(constant);

    target->type = Compile::Constant::Type_Number;
    target->valueNumber = n;
}

void setCompileConstantInteger64(CompileConstant* constant, int64_t l)
{
    Compile::Constant* target = reinterpret_cast<Compile::Constant*>(constant);

    target->type = Compile::Constant::Type_Integer;
    target->valueInteger64 = l;
}

void setCompileConstantVector(CompileConstant* constant, float x, float y, float z, float w)
{
    Compile::Constant* target = reinterpret_cast<Compile::Constant*>(constant);

    target->type = Compile::Constant::Type_Vectorf;
    target->valueVectorf[0] = x;
    target->valueVectorf[1] = y;
    target->valueVectorf[2] = z;
    target->valueVectorf[3] = w;
}

void setCompileConstantVectord(CompileConstant* constant, double x, double y, double z, double w)
{
    Compile::Constant* target = reinterpret_cast<Compile::Constant*>(constant);

    target->type = Compile::Constant::Type_Vectord;
    target->valueVectord[0] = x;
    target->valueVectord[1] = y;
    target->valueVectord[2] = z;
    target->valueVectord[3] = w;
}

void setCompileConstantString(CompileConstant* constant, const char* s, size_t l)
{
    Compile::Constant* target = reinterpret_cast<Compile::Constant*>(constant);

    if (l > std::numeric_limits<unsigned int>::max())
        CompileError::raise({}, "Exceeded custom string constant length limit");

    target->type = Compile::Constant::Type_String;
    target->stringLength = unsigned(l);
    target->valueString = s;
}

}
