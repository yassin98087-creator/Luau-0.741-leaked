#pragma once

#include "Luau/Ast.h"
#include "Luau/DenseHash.h"

#include <vector>

namespace Luau
{
class AstNameTable;
}

namespace Luau
{
namespace Compile
{

enum class Global
{
    Default = 0,
    Mutable,
    Written,
};

struct Variable
{
    AstExpr* init = nullptr;
    AstStatBlock* owner = nullptr;
    AstExprLocal* lastUsed = nullptr;
    bool written = false;
    bool constant = false;
    bool nonLexicalUse = false;
};

void assignMutable(DenseHashMap<AstName, Global>& globals, const AstNameTable& names, const char* const* mutableGlobals);
void trackValues(
    DenseHashMap<AstName, Global>& globals,
    DenseHashMap<AstLocal*, Variable>& variables,
    DenseHashMap<AstName, AstLocal*>& classLocals,
    DenseHashSet<AstLocal*>& exportedFunctions,
    std::vector<AstLocal*>& exportedVariables,
    AstNode* root
);
void trackValues_DEPRECATED(
    DenseHashMap<AstName, Global>& globals,
    DenseHashMap<AstLocal*, Variable>& variables,
    DenseHashMap<AstName, AstLocal*>& classLocals,
    AstNode* root
);

inline Global getGlobalState(const DenseHashMap<AstName, Global>& globals, AstName name)
{
    const Global* it = globals.find(name);

    return it ? *it : Global::Default;
}

}
}
