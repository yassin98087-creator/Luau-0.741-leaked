#pragma once

#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>

#include "luaconf.h"

#if LUAU_ROBLOX_INTEGRATION
#include <memory>
#include <cstddef>
struct lua_State;
#include <Roblox/Offsets.hpp>
#include <Roblox/Encryptions.hpp>

namespace Hyperion
{
inline void LuaD_Throw(lua_State* L, int errcode)
{
    Roblox::LuaD_Throw(L, errcode);
}
inline void Luau_Execute(lua_State* L)
{
    Roblox::Luau_Execute(L);
}
}

struct Shared
{
    unsigned char allThreads[0x10];
    void* scriptContext;
    void* scriptVmState;
    void* needToFree;
    int threadCount;
    char gap_0[0x4];
};

struct RobloxExtraSpace
{
    RobloxExtraSpace* next;
    void* _container;
    RobloxExtraSpace* prev;
    std::shared_ptr<Shared> shared;
    char gap_0[0x18];
    void* flyweightPtr;
    uint64_t identity;
    char gap_identity[0x8];
    void* scriptContext;
    char gap_1[0x8];
    std::weak_ptr<uintptr_t> script;
    char gap_2[0x8];
    uint64_t capabilities;
    std::weak_ptr<uintptr_t> InstanceDefiningCapabilities;
    std::weak_ptr<uintptr_t> actor;
    char gap_3[0x10];
};

#endif

#define LUA_MULTRET (-1)

#define LUA_REGISTRYINDEX (-LUAI_MAXCSTACK - 2000)
#define LUA_ENVIRONINDEX (-LUAI_MAXCSTACK - 2001)
#define LUA_GLOBALSINDEX (-LUAI_MAXCSTACK - 2002)
#define lua_upvalueindex(i) (LUA_GLOBALSINDEX - (i))
#define lua_ispseudo(i) ((i) <= LUA_REGISTRYINDEX)

enum lua_Status
{
    LUA_OK = 0,
    LUA_YIELD,
    LUA_ERRRUN,
    LUA_ERRSYNTAX,
    LUA_ERRMEM,
    LUA_ERRERR,
    LUA_BREAK,
};

enum lua_CoStatus
{
    LUA_CORUN = 0,
    LUA_COSUS,
    LUA_CONOR,
    LUA_COFIN,
    LUA_COERR,
};

typedef struct lua_State lua_State;

typedef int (*lua_CFunction)(lua_State* L);
typedef int (*lua_Continuation)(lua_State* L, int status);

typedef void* (*lua_Alloc)(void* ud, void* ptr, size_t osize, size_t nsize);

typedef void* (*lua_CageAlloc)(void* ud, void* ptr, size_t osize, size_t nsize, int type);

#define l_noret void LUA_NORETURN

#define LUA_TNONE (-1)

enum lua_Type
{
    LUA_TNIL = 0,
    LUA_TBOOLEAN = 1,

    LUA_TLIGHTUSERDATA,
    LUA_TNUMBER,
    LUA_TINTEGER,

#if LUA_VECTOR_DOUBLE == 0
    LUA_TVECTOR,
#endif

    LUA_TSTRING,

    LUA_TTABLE,
    LUA_TFUNCTION,
    LUA_TUSERDATA,
    LUA_TTHREAD,
    LUA_TBUFFER,
    LUA_TCLASS,
    LUA_TOBJECT,

#if LUA_VECTOR_DOUBLE == 1
    LUA_TVECTOR,
#endif

    LUA_TDEADKEY,

    LUA_TPROTO,
    LUA_TUPVAL,

    LUA_T_ALL,

    LUA_T_COUNT = LUA_TDEADKEY,
};

typedef double lua_Number;

typedef int lua_Integer;

typedef unsigned lua_Unsigned;

LUA_API lua_State* lua_newstate(lua_Alloc allocator, void* ud);
LUA_API void lua_close(lua_State* L);
LUA_API lua_State* lua_newthread(lua_State* L);
LUA_API lua_State* lua_mainthread(lua_State* L);
LUA_API void lua_resetthread(lua_State* L);
LUA_API int lua_isthreadreset(lua_State* L);

LUA_API int lua_absindex(lua_State* L, int idx);
LUA_API int lua_gettop(lua_State* L);
LUA_API void lua_settop(lua_State* L, int idx);
LUA_API void lua_pushvalue(lua_State* L, int idx);
LUA_API void lua_remove(lua_State* L, int idx);
LUA_API void lua_insert(lua_State* L, int idx);
LUA_API void lua_replace(lua_State* L, int idx);
LUA_API int lua_checkstack(lua_State* L, int sz);
LUA_API void lua_rawcheckstack(lua_State* L, int sz);

LUA_API void lua_xmove(lua_State* from, lua_State* to, int n);
LUA_API void lua_xpush(lua_State* from, lua_State* to, int idx);

LUA_API int lua_isnumber(lua_State* L, int idx);
LUA_API int lua_isstring(lua_State* L, int idx);
LUA_API int lua_isinteger64(lua_State* L, int idx);
LUA_API int lua_iscfunction(lua_State* L, int idx);
LUA_API int lua_isLfunction(lua_State* L, int idx);
LUA_API int lua_isuserdata(lua_State* L, int idx);
LUA_API int lua_type(lua_State* L, int idx);
LUA_API const char* lua_typename(lua_State* L, int tp);

LUA_API int lua_equal(lua_State* L, int idx1, int idx2);
LUA_API int lua_rawequal(lua_State* L, int idx1, int idx2);
LUA_API int lua_lessthan(lua_State* L, int idx1, int idx2);

LUA_API double lua_tonumberx(lua_State* L, int idx, int* isnum);
LUA_API int lua_tointegerx(lua_State* L, int idx, int* isnum);
LUA_API unsigned lua_tounsignedx(lua_State* L, int idx, int* isnum);
LUA_API const LUA_VECTOR_TYPE* lua_tovector(lua_State* L, int idx);
LUA_API int lua_toboolean(lua_State* L, int idx);
LUA_API int64_t lua_tointeger64(lua_State* L, int idx, int* isinteger);
LUA_API const char* lua_tolstring(lua_State* L, int idx, size_t* len);
LUA_API const char* lua_tostringatom(lua_State* L, int idx, int* atom);
LUA_API const char* lua_tolstringatom(lua_State* L, int idx, size_t* len, int* atom);
LUA_API const char* lua_namecallatom(lua_State* L, int* atom);
LUA_API int lua_objlen(lua_State* L, int idx);
LUA_API lua_CFunction lua_tocfunction(lua_State* L, int idx);
LUA_API void* lua_tolightuserdata(lua_State* L, int idx);
LUA_API void* lua_tolightuserdatatagged(lua_State* L, int idx, int tag);
LUA_API void* lua_touserdata(lua_State* L, int idx);
LUA_API void* lua_touserdatatagged(lua_State* L, int idx, int tag);
LUA_API int lua_userdatatag(lua_State* L, int idx);
LUA_API int lua_lightuserdatatag(lua_State* L, int idx);
LUA_API lua_State* lua_tothread(lua_State* L, int idx);
LUA_API void* lua_tobuffer(lua_State* L, int idx, size_t* len);
LUA_API const void* lua_topointer(lua_State* L, int idx);

LUA_API void lua_pushnil(lua_State* L);
LUA_API void lua_pushnumber(lua_State* L, double n);
LUA_API void lua_pushinteger(lua_State* L, int n);
LUA_API void lua_pushinteger64(lua_State* L, int64_t n);
LUA_API void lua_pushunsigned(lua_State* L, unsigned n);
#if LUA_VECTOR_SIZE == 4
LUA_API void lua_pushvector(lua_State* L, LUA_VECTOR_TYPE x, LUA_VECTOR_TYPE y, LUA_VECTOR_TYPE z, LUA_VECTOR_TYPE w);
#else
LUA_API void lua_pushvector(lua_State* L, LUA_VECTOR_TYPE x, LUA_VECTOR_TYPE y, LUA_VECTOR_TYPE z);
#endif
LUA_API void lua_pushlstring(lua_State* L, const char* s, size_t l);
LUA_API void lua_pushstring(lua_State* L, const char* s);
LUA_API const char* lua_pushvfstring(lua_State* L, const char* fmt, va_list argp);
LUA_API LUA_PRINTF_ATTR(2, 3) const char* lua_pushfstringL(lua_State* L, const char* fmt, ...);
LUA_API void lua_pushcclosurek(lua_State* L, lua_CFunction fn, const char* debugname, int nup, lua_Continuation cont);
LUA_API void lua_pushboolean(lua_State* L, int b);
LUA_API int lua_pushthread(lua_State* L);

typedef void (*lua_Destructor)(lua_State* L, void* userdata);

LUA_API void lua_pushlightuserdatatagged(lua_State* L, void* p, int tag);
LUA_API void* lua_newuserdatatagged(lua_State* L, size_t sz, int tag);
LUA_API void* lua_newuserdatataggedwithmetatable(lua_State* L, size_t sz, int tag);
LUA_API void* lua_newuserdatadtor(lua_State* L, size_t sz, lua_Destructor dtor);

LUA_API void* lua_newbuffer(lua_State* L, size_t sz);

LUA_API int lua_gettable(lua_State* L, int idx);
LUA_API int lua_getfield(lua_State* L, int idx, const char* k);
LUA_API int lua_rawgetfield(lua_State* L, int idx, const char* k);
LUA_API int lua_rawget(lua_State* L, int idx);
LUA_API int lua_rawgeti(lua_State* L, int idx, int n);
LUA_API int lua_rawgetptagged(lua_State* L, int idx, void* p, int tag);
LUA_API void lua_createtable(lua_State* L, int narr, int nrec);

LUA_API void lua_setreadonly(lua_State* L, int idx, int enabled);
LUA_API int lua_getreadonly(lua_State* L, int idx);
LUA_API void lua_setsafeenv(lua_State* L, int idx, int enabled);

LUA_API int lua_getmetatable(lua_State* L, int objindex);
LUA_API void lua_getfenv(lua_State* L, int idx);

LUA_API void lua_settable(lua_State* L, int idx);
LUA_API void lua_setfield(lua_State* L, int idx, const char* k);
LUA_API void lua_rawsetfield(lua_State* L, int idx, const char* k);
LUA_API void lua_rawset(lua_State* L, int idx);
LUA_API void lua_rawseti(lua_State* L, int idx, int n);
LUA_API void lua_rawsetptagged(lua_State* L, int idx, void* p, int tag);
LUA_API int lua_setmetatable(lua_State* L, int objindex);
LUA_API int lua_setfenv(lua_State* L, int idx);

LUA_API int luau_load(lua_State* L, const char* chunkname, const char* data, size_t size, int env);
LUA_API void lua_call(lua_State* L, int nargs, int nresults);
LUA_API int lua_pcall(lua_State* L, int nargs, int nresults, int errfunc);
LUA_API int lua_cpcall(lua_State* L, lua_CFunction func, void* ud);

LUA_API int lua_callyieldable(lua_State* L, int nargs, int nresults);
LUA_API int lua_pcallyieldable(lua_State* L, int nargs, int nresults, int errfunc);

LUA_API int lua_yield(lua_State* L, int nresults);
LUA_API int lua_break(lua_State* L);
LUA_API int lua_resume(lua_State* L, lua_State* from, int narg);
LUA_API int lua_resumeerror(lua_State* L, lua_State* from);
LUA_API int lua_status(lua_State* L);
LUA_API int lua_isyieldable(lua_State* L);
LUA_API void* lua_getthreaddata(lua_State* L);
#if LUAU_ROBLOX_INTEGRATION
LUA_API void lua_setthreaddata(lua_State* L, RobloxExtraSpace* data);
#else
LUA_API void lua_setthreaddata(lua_State* L, void* data);
#endif
LUA_API int lua_costatus(lua_State* L, lua_State* co);

LUA_API int lua_hasfinalizers(lua_State* L);
LUA_API void lua_pushfinalizerfunction(lua_State* L);
LUA_API void lua_addfinalizer(lua_State* L, lua_State* co, int idx);

enum lua_GCOp
{

    LUA_GCSTOP,
    LUA_GCRESTART,

    LUA_GCCOLLECT,

    LUA_GCCOUNT,
    LUA_GCCOUNTB,

    LUA_GCISRUNNING,

    LUA_GCSTEP,

    LUA_GCSETGOAL,
    LUA_GCSETSTEPMUL,
    LUA_GCSETSTEPSIZE,

    LUA_GCISPAUSED,
};

LUA_API int lua_gc(lua_State* L, int what, int data);

typedef const char* (*lua_CategoryName)(lua_State* L, uint8_t memcat);

LUA_API void lua_memorydump(lua_State* L, void* file, lua_CategoryName categoryName);

LUA_API void lua_setmemcat(lua_State* L, int category);
LUA_API size_t lua_totalbytes(lua_State* L, int category);

LUA_API int64_t lua_allocationrate(lua_State* L);

LUA_API l_noret lua_error(lua_State* L);

LUA_API int lua_next(lua_State* L, int idx);
LUA_API int lua_rawiter(lua_State* L, int idx, int iter);

LUA_API void lua_concat(lua_State* L, int n);

LUA_API void lua_setpointerencodekey(lua_State* L, uint64_t a, uint64_t b, uint64_t c, uint64_t d);
LUA_API uintptr_t lua_encodepointer(lua_State* L, uintptr_t p);

LUA_API double lua_clock();

LUA_API void lua_setuserdatatag(lua_State* L, int idx, int tag);

LUA_API void lua_setuserdatadtor(lua_State* L, int tag, lua_Destructor dtor);
LUA_API lua_Destructor lua_getuserdatadtor(lua_State* L, int tag);

typedef void (*lua_UserdataMark)(lua_State* L, void* ud);
LUA_API void lua_setuserdatamark(lua_State* L, int tag, lua_UserdataMark markfn);
typedef void (*lua_EmbedderMark)(lua_State* L, int ref);
typedef void (*lua_EmbedderGc)(lua_State* L, lua_EmbedderMark markref);
LUA_API void lua_setembeddergc(lua_State* L, lua_EmbedderGc fn);

LUA_API int lua_weakref(lua_State* L, int idx);
LUA_API int lua_weakunref(lua_State* L, int ref);
LUA_API int lua_getweakref(lua_State* L, int ref);

LUA_API void lua_setuserdatametatable(lua_State* L, int tag);
LUA_API void lua_getuserdatametatable(lua_State* L, int tag);

LUA_API const char* lua_getuserdataname(lua_State* L, int tag);

typedef void (*lua_UserdataDirectAccess)(lua_State* L, void* data, int atom, uint16_t* cachedslot, int utag);
typedef int (*lua_UserdataDirectNamecall)(lua_State* L, void* data, int atom, uint16_t* cachedslot, int utag);

LUA_API int lua_registeruserdatadirectaccess(
    lua_State* L,
    int tag,
    lua_UserdataDirectAccess get,
    lua_UserdataDirectAccess set,
    lua_UserdataDirectNamecall namecall
);

typedef void (*lua_UserdataDirectFieldGet)(void* ud, void* result);
LUA_API void lua_registeruserdatadirectfieldget(lua_State* L, int tag, const char* field, lua_UserdataDirectFieldGet fn);

LUA_API void lua_userdatadirectfield_setnumber(void* result, double n);
#if LUA_VECTOR_SIZE == 4
LUA_API void lua_userdatadirectfield_setvector(void* result, LUA_VECTOR_TYPE x, LUA_VECTOR_TYPE y, LUA_VECTOR_TYPE z, LUA_VECTOR_TYPE w);
#else
LUA_API void lua_userdatadirectfield_setvector(void* result, LUA_VECTOR_TYPE x, LUA_VECTOR_TYPE y, LUA_VECTOR_TYPE z);
#endif
LUA_API void lua_userdatadirectfield_setboolean(void* result, int b);
LUA_API void lua_userdatadirectfield_setinteger64(void* result, int64_t n);
LUA_API void lua_userdatadirectfield_setnil(void* result);

LUA_API void lua_setlightuserdataname(lua_State* L, int tag, const char* name);
LUA_API const char* lua_getlightuserdataname(lua_State* L, int tag);

LUA_API void lua_clonefunction(lua_State* L, int idx);
LUA_API int lua_usesexport(lua_State* L, int idx);

LUA_API void lua_cleartable(lua_State* L, int idx);
LUA_API void lua_clonetable(lua_State* L, int idx);

LUA_API lua_Alloc lua_getallocf(lua_State* L, void** ud);

#define LUA_NOREF -1
#define LUA_REFNIL 0

LUA_API int lua_ref(lua_State* L, int idx);
LUA_API int lua_unref(lua_State* L, int ref);

#define lua_getref(L, ref) lua_rawgeti(L, LUA_REGISTRYINDEX, (ref))

#define lua_tonumber(L, i) lua_tonumberx(L, i, NULL)
#define lua_tointeger(L, i) lua_tointegerx(L, i, NULL)
#define lua_tounsigned(L, i) lua_tounsignedx(L, i, NULL)

#define lua_pop(L, n) lua_settop(L, -(n) - 1)

#define lua_newtable(L) lua_createtable(L, 0, 0)
#define lua_newuserdata(L, s) lua_newuserdatatagged(L, s, 0)

#define lua_strlen(L, i) lua_objlen(L, (i))

#define lua_isfunction(L, n) (lua_type(L, (n)) == LUA_TFUNCTION)
#define lua_istable(L, n) (lua_type(L, (n)) == LUA_TTABLE)
#define lua_islightuserdata(L, n) (lua_type(L, (n)) == LUA_TLIGHTUSERDATA)
#define lua_isnil(L, n) (lua_type(L, (n)) == LUA_TNIL)
#define lua_isboolean(L, n) (lua_type(L, (n)) == LUA_TBOOLEAN)
#define lua_isinteger64(L, n) (lua_type(L, (n)) == LUA_TINTEGER)
#define lua_isvector(L, n) (lua_type(L, (n)) == LUA_TVECTOR)
#define lua_isthread(L, n) (lua_type(L, (n)) == LUA_TTHREAD)
#define lua_isbuffer(L, n) (lua_type(L, (n)) == LUA_TBUFFER)
#define lua_isnone(L, n) (lua_type(L, (n)) == LUA_TNONE)
#define lua_isnoneornil(L, n) (lua_type(L, (n)) <= LUA_TNIL)
#define lua_isclass(L, n) (lua_type(L, (n)) == LUA_TCLASS)
#define lua_isobject(L, n) (lua_type(L, (n)) == LUA_TOBJECT)

#define lua_pushliteral(L, s) lua_pushlstring(L, "" s, (sizeof(s) / sizeof(char)) - 1)
#define lua_pushcfunction(L, fn, debugname) lua_pushcclosurek(L, fn, debugname, 0, NULL)
#define lua_pushcclosure(L, fn, debugname, nup) lua_pushcclosurek(L, fn, debugname, nup, NULL)
#define lua_pushlightuserdata(L, p) lua_pushlightuserdatatagged(L, p, 0)

#define lua_rawgetp(L, idx, p) lua_rawgetptagged(L, idx, p, 0)
#define lua_rawsetp(L, idx, p) lua_rawsetptagged(L, idx, p, 0)

#define lua_setglobal(L, s) lua_setfield(L, LUA_GLOBALSINDEX, (s))
#define lua_getglobal(L, s) lua_getfield(L, LUA_GLOBALSINDEX, (s))

#define lua_tostring(L, i) lua_tolstring(L, (i), NULL)

#define lua_pushfstring(L, fmt, ...) lua_pushfstringL(L, fmt, ##__VA_ARGS__)

typedef struct lua_Debug lua_Debug;

typedef void (*lua_Hook)(lua_State* L, lua_Debug* ar);

LUA_API void lua_callhook(lua_State* L, lua_Hook hook, void* userdata);

LUA_API int lua_stackdepth(lua_State* L);
LUA_API int lua_getinfo(lua_State* L, int level, const char* what, lua_Debug* ar);
LUA_API int lua_getargument(lua_State* L, int level, int n);
LUA_API const char* lua_getlocal(lua_State* L, int level, int n);
LUA_API const char* lua_setlocal(lua_State* L, int level, int n);
LUA_API const char* lua_getupvalue(lua_State* L, int funcindex, int n);
LUA_API const char* lua_setupvalue(lua_State* L, int funcindex, int n);

LUA_API int lua_hascustomexecution(lua_State* L, int level);
LUA_API int lua_incustomexecution(lua_State* L, int level);

LUA_API void lua_singlestep(lua_State* L, int enabled);
LUA_API int lua_breakpoint(lua_State* L, int funcindex, int line, int enabled);

LUA_API int lua_atbreakpoint(lua_State* L);

LUA_API const char* lua_debugtrace(lua_State* L);

#if LUAU_ROBLOX_INTEGRATION
struct lua_Debug
{
    const char* name;
    const char* what;
    const char* source;
    const char* short_src;
    int linedefined;
    int currentline;
    unsigned char nupvals;
    unsigned char nparams;
    unsigned char isvararg;
    int protoid;
    int bytecodeid;
    void* userdata;
    char ssbuf[256];
};
#else
struct lua_Debug
{
    const char* name;
    const char* what;
    const char* source;
    const char* short_src;
    int linedefined;
    int currentline;
    int protoid;
    int bytecodeid;
    unsigned char nupvals;
    unsigned char nparams;
    char isvararg;
    void* userdata;

    char ssbuf[LUA_IDSIZE];
};
#endif

typedef void (*lua_Coverage)(void* context, const char* function, int linedefined, int depth, const int* hits, size_t size);

LUA_API void lua_getcoverage(lua_State* L, int funcindex, void* context, lua_Coverage callback);

typedef void (*lua_CounterFunction)(void* context, const char* function, int linedefined);
typedef void (*lua_CounterValue)(void* context, int kind, int line, uint64_t hits);

LUA_API void lua_getcounters(lua_State* L, int funcindex, void* context, lua_CounterFunction functionvisit, lua_CounterValue countervisit);

#if LUAU_ROBLOX_INTEGRATION
struct lua_Callbacks
{
    void* userdata;
    void (*debugbreak)(lua_State* L, lua_Debug* ar);
    void (*interrupt)(lua_State* L, int gc);
    void (*onfree)(lua_State* L, void* block);
    void (*preresume)(lua_State* L);
    void (*postresume)(lua_State* L);
    void (*onallocate)(lua_State* L, void* block, size_t osize, size_t nsize, uint8_t memcat, int tt, int tag);
    void (*debugprotectederror)(lua_State* L);
    void (*panic)(lua_State* L, int errcode);
    void (*debugstep)(lua_State* L, lua_Debug* ar);
    void (*userthread)(lua_State* LP, lua_State* L);
    void (*userfinalizer)(lua_State* L, lua_State* co);
    int16_t (*useratom)(lua_State* L, const char* s, size_t l);
    void (*debuginterrupt)(lua_State* L, lua_Debug* ar);
};
#else
struct lua_Callbacks
{
    void* userdata;

    void (*interrupt)(lua_State* L, int gc);
    void (*panic)(lua_State* L, int errcode);

    void (*userthread)(lua_State* LP, lua_State* L);
    int16_t (*useratom)(lua_State* L, const char* s, size_t l);

    void (*userfinalizer)(lua_State* L, lua_State* co);

    void (*debugbreak)(lua_State* L, lua_Debug* ar);
    void (*debugstep)(lua_State* L, lua_Debug* ar);
    void (*debuginterrupt)(lua_State* L, lua_Debug* ar);
    void (*debugprotectederror)(lua_State* L);

    void (*onallocate)(lua_State* L, void* block, size_t osize, size_t nsize, uint8_t memcat, int tt, int tag);

    void (*preresume)(lua_State* L);
    void (*postresume)(lua_State* L);

    void (*onfree)(lua_State* L, void* block);
};
#endif
typedef struct lua_Callbacks lua_Callbacks;

LUA_API lua_Callbacks* lua_callbacks(lua_State* L);

LUA_API void lua_setmemorycage(lua_State* L, lua_CageAlloc alloc, void* ud);

#define lua_normalisestack(L, mxs) \
    do \
    { \
        if (lua_gettop(L) > (mxs)) \
            lua_settop(L, (mxs)); \
    } while (0)
#define lua_pushrawclosure(L, rawClosure) \
    do \
    { \
        setclvalue(L, L->top, rawClosure); \
    } while (0)

#if LUAU_ROBLOX_INTEGRATION

static_assert(sizeof(void*) == 8, "Supplied layouts require x64");
static_assert(offsetof(Shared, allThreads) == 0, "Shared.allThreads offset");
static_assert(offsetof(Shared, scriptContext) == 16, "Shared.scriptContext offset");
static_assert(offsetof(Shared, scriptVmState) == 24, "Shared.scriptVmState offset");
static_assert(offsetof(Shared, needToFree) == 32, "Shared.needToFree offset");
static_assert(offsetof(Shared, threadCount) == 40, "Shared.threadCount offset");
static_assert(sizeof(Shared) == 48, "Shared size");
static_assert(offsetof(RobloxExtraSpace, next) == 0, "RobloxExtraSpace.next offset");
static_assert(offsetof(RobloxExtraSpace, _container) == 8, "RobloxExtraSpace._container offset");
static_assert(offsetof(RobloxExtraSpace, prev) == 16, "RobloxExtraSpace.prev offset");
static_assert(offsetof(RobloxExtraSpace, shared) == 24, "RobloxExtraSpace.shared offset");
static_assert(offsetof(RobloxExtraSpace, flyweightPtr) == 64, "RobloxExtraSpace.flyweightPtr offset");
static_assert(offsetof(RobloxExtraSpace, identity) == 72, "RobloxExtraSpace.identity offset");
static_assert(offsetof(RobloxExtraSpace, scriptContext) == 88, "RobloxExtraSpace.scriptContext offset");
static_assert(offsetof(RobloxExtraSpace, script) == 104, "RobloxExtraSpace.script offset");
static_assert(offsetof(RobloxExtraSpace, capabilities) == 128, "RobloxExtraSpace.capabilities offset");
static_assert(offsetof(RobloxExtraSpace, InstanceDefiningCapabilities) == 136, "RobloxExtraSpace.InstanceDefiningCapabilities offset");
static_assert(offsetof(RobloxExtraSpace, actor) == 152, "RobloxExtraSpace.actor offset");
static_assert(sizeof(RobloxExtraSpace) == 184, "RobloxExtraSpace size");
static_assert(offsetof(lua_Callbacks, userdata) == 0, "lua_Callbacks.userdata offset");
static_assert(offsetof(lua_Callbacks, debugbreak) == 8, "lua_Callbacks.debugbreak offset");
static_assert(offsetof(lua_Callbacks, onfree) == 24, "lua_Callbacks.onfree offset");
static_assert(offsetof(lua_Callbacks, onallocate) == 48, "lua_Callbacks.onallocate offset");
static_assert(offsetof(lua_Callbacks, debugstep) == 72, "lua_Callbacks.debugstep offset");
static_assert(offsetof(lua_Callbacks, userthread) == 80, "lua_Callbacks.userthread offset");
static_assert(offsetof(lua_Callbacks, useratom) == 96, "lua_Callbacks.useratom offset");
static_assert(sizeof(lua_Callbacks) == 112, "lua_Callbacks size");
#endif
