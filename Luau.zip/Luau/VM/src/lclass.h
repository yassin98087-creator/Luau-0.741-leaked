#pragma once

#include "lmem.h"
#include "lobject.h"

LUAI_FUNC LuauClass* luaR_newclass(
    lua_State* L,
    TString* name,
    LuaTable* memberstooffset,
    TString** offsettomember,
    uint32_t numberofinstancemembers,
    uint32_t numberofstaticmembers,
    LuaTable* envt
);

LUAI_FUNC LuauClass* luaR_cloneclass(lua_State* L, LuauClass* classobject);

LUAI_FUNC void luaR_inheritclass(lua_State* L, LuauClass* child, LuauClass* parent);

LUAI_FUNC void luaR_addclassmember(lua_State* L, LuauClass* classobject, TString* name, TValue* value);

LUAI_FUNC void luaR_freeclass(lua_State* L, LuauClass* classobject, lua_Page* page);

LUAI_FUNC int luaR_defaultcreateobject(lua_State* L);

LUAI_FUNC int luaR_constructobject(lua_State* L);

LUAI_FUNC void luaR_freeobject(lua_State* L, LuauObject* classinstance, lua_Page* page);

#define luaR_checkoffsetinbounds(inst, offset) (offset < (inst)->lclass->numberofallmembers)

#define luaR_lookupmemberatoffset(inst, offset) \
    (LUAU_ASSERT(luaR_checkoffsetinbounds(inst, offset)), \
     offset < (inst)->lclass->numberofinstancemembers ? &(inst)->members[offset] \
                                                      : &(inst)->lclass->staticmembers[offset - inst->lclass->numberofinstancemembers])
