#pragma once

#include "lobject.h"
#include "ltm.h"
#include "ludata.h"

#define registry(L) (&L->global->registry)

#define EXTRA_STACK 5

#define BASIC_CI_SIZE 8

#define BASIC_STACK_SIZE (2 * LUA_MINSTACK)

typedef struct stringtable
{
    TString** hash;
    uint32_t nuse;
    int size;
} stringtable;

typedef struct CallInfo
{
    StkId base;
    StkId func;
    StkId top;
    Proto* p;

    union
    {
        const Instruction* savedpc;
        int errfunc;
    };

    int nresults;
    unsigned int flags;
} CallInfo;

#define LUA_CALLINFO_RETURN (1 << 0)
#define LUA_CALLINFO_HANDLE (1 << 1)
#define LUA_CALLINFO_NATIVE (1 << 2)
#define LUA_CALLINFO_OPYIELD (1 << 3)
#define LUA_CALLINFO_PCALL (1 << 4)

#define curr_func(L) (clvalue(L->ci->func))
#define ci_func(ci) (clvalue((ci)->func))
#define f_isLua(ci) (!ci_func(ci)->isC)
#define isLua(ci) (ttisfunction((ci)->func) && f_isLua(ci))

struct GCStats
{

    int32_t triggerterms[32] = {0};
    uint32_t triggertermpos = 0;
    int32_t triggerintegral = 0;

    size_t atomicstarttotalsizebytes = 0;
    size_t endtotalsizebytes = 0;
    size_t heapgoalsizebytes = 0;

    double starttimestamp = 0;
    double atomicstarttimestamp = 0;
    double endtimestamp = 0;
};

#ifdef LUAI_GCMETRICS
struct GCCycleMetrics
{
    size_t starttotalsizebytes = 0;
    size_t heaptriggersizebytes = 0;

    double pausetime = 0.0;

    double starttimestamp = 0.0;
    double endtimestamp = 0.0;

    double marktime = 0.0;
    double markassisttime = 0.0;
    double markmaxexplicittime = 0.0;
    size_t markexplicitsteps = 0;
    size_t markwork = 0;

    double atomicstarttimestamp = 0.0;
    size_t atomicstarttotalsizebytes = 0;
    double atomictime = 0.0;

    double atomictimeupval = 0.0;
    double atomictimeweak = 0.0;
    double atomictimegray = 0.0;
    double atomictimeembedder = 0.0;
    double atomictimeclear = 0.0;

    double sweeptime = 0.0;
    double sweepassisttime = 0.0;
    double sweepmaxexplicittime = 0.0;
    size_t sweepexplicitsteps = 0;
    size_t sweepwork = 0;

    size_t assistwork = 0;
    size_t explicitwork = 0;

    size_t propagatework = 0;
    size_t propagateagainwork = 0;

    size_t endtotalsizebytes = 0;
};

struct GCMetrics
{
    double stepexplicittimeacc = 0.0;
    double stepassisttimeacc = 0.0;

    uint64_t completedcycles = 0;

    GCCycleMetrics lastcycle;
    GCCycleMetrics currcycle;
};
#endif

struct lua_ExecutionCallbacks
{
    void* context;
    void (*close)(lua_State* L);
    void (*destroy)(lua_State* L, Proto* proto);
    int (*enter)(lua_State* L, Proto* proto);
    void (*disable)(lua_State* L, Proto* proto);
    size_t (*getmemorysize)(lua_State* L, Proto* proto);
    uint8_t (*gettypemapping)(lua_State* L, const char* str, size_t len);
    char* (*getcounterdata)(lua_State* L, Proto* proto, size_t* count);
    Proto* (*inlinefunction)(lua_State* L, Closure* caller, Closure* target, uint32_t pc);
};

struct lua_UdataDirectAccessData
{
    TValue indextm;
    TValue newindextm;
    TValue namecalltm;
    lua_UserdataDirectAccess index;
    lua_UserdataDirectAccess newindex;
    lua_UserdataDirectNamecall namecall;
};

#if LUAU_ROBLOX_INTEGRATION
struct registryfree_value
{
private:
    int _value;

public:
    registryfree_value()
        : _value(0)
    {
    }
    registryfree_value(int val)
        : _value(val)
    {
    }
    registryfree_value(const registryfree_value& other)
        : _value(other._value)
    {
    }

    void operator=(const registryfree_value& value)
    {
        _value = value._value;
    }

    void operator=(const int& value)
    {
        _value = (_value & 0xF0000000) | (value & 0xFFFFFFF);
    }

    operator const int() const
    {
        return _value & 0xFFFFFFF;
    }

    bool operator==(const int& value) const
    {
        return (_value & 0xFFFFFFF) == value;
    }

    bool operator!=(const int& value) const
    {
        return (_value & 0xFFFFFFF) != value;
    }
};

typedef registryfree_value registryfree_t;
#endif

#if LUAU_ROBLOX_INTEGRATION
struct global_State
{
    stringtable strt;
    size_t GCthreshold;
    size_t totalbytes;
    unsigned char currentwhite;
    unsigned char gcstate;
    char gap_0[0x6];
    lua_Alloc frealloc;
    void* ud;
    GCObject* weak;
    GCObject* grayagain;
    GCObject* gray;
    int gcgoal;
    int gcstepsize;
    int gcstepmul;
    char gap_1[0x4];
    lua_Page* freepages[40];
    lua_Page* freegcopages[40];
    lua_Page* sweepgcopage;
    lua_State* mainthread;
    struct lua_Page* allpages;
    lua_Page* allgcopages;
    UpVal uvhead;
    LuaTable* mt[LUA_T_COUNT];
    TString* ttname[LUA_T_COUNT];
    TString* tmname[TM_N];
    lua_Page* freegcopages_cage[40];
    lua_Page* allgcopages_cage;
    lua_Page* sweepgcopage_cage;
    struct lua_jmpbuf* errorjmp;
    lua_CageAlloc cagealloc;
    TValue pseudotemp;
    TValue registry;
    registryfree_t registryfree;
    char gap_2[0x4];
    void* cageud;
    unsigned __int64 ptrenckey[4];
    unsigned __int64 rngstate;
    lua_Callbacks cb;
    lua_ExecutionCallbacks ecb;
    alignas(16) uint8_t ecbdata[LUA_EXECUTION_CALLBACK_STORAGE];
    lua_UdataDirectAccessData udatadirect[UTAG_INTERNAL_LIMIT];
    size_t memcatbytes[LUA_MEMORY_CATEGORIES];
    void (*udatagc[LUA_UTAG_LIMIT])(struct lua_State*, void*);
    lua_UserdataMark udatamark[LUA_UTAG_LIMIT];
    LuaTable* udatamt[LUA_UTAG_LIMIT];
    TValue weakregistry;
    int weakregistryfree;
    int weakregistrytop;
    lua_EmbedderGc embeddergc;
    TString* lightuserdataname[LUA_LUTAG_LIMIT];
    struct LuaTable* udatadirectfields[UTAG_INTERNAL_LIMIT];
    Closure* builtinPcall;
    Closure* builtinXpcall;
    unsigned __int64 ptrenckeynew[8];
    bool ptrencactive;
    char gap_3[0x7];
    struct GCStats gcstats;
    unsigned int lastprotoid;
    char gap_4[0x4];
#ifdef LUAI_GCMETRICS
    GCMetrics gcmetrics;
#endif
};
#else
typedef struct global_State
{
    stringtable strt;

    lua_Alloc frealloc;
    void* ud;

    uint8_t currentwhite;
    uint8_t gcstate;

    GCObject* gray;
    GCObject* grayagain;
    GCObject* weak;

    size_t GCthreshold;
    size_t totalbytes;

    int gcgoal;
    int gcstepmul;
    int gcstepsize;

    struct lua_Page* freepages[LUA_SIZECLASSES];
    struct lua_Page* freegcopages[LUA_SIZECLASSES];
    struct lua_Page* allpages;
    struct lua_Page* allgcopages;
    struct lua_Page* sweepgcopage;

    struct lua_State* mainthread;
    UpVal uvhead;
    struct LuaTable* mt[LUA_T_COUNT];
    TString* ttname[LUA_T_COUNT];
    TString* tmname[TM_N];

    lua_CageAlloc cagealloc;
    void* cageud;
    struct lua_Page* freegcopages_cage[LUA_SIZECLASSES];
    struct lua_Page* allgcopages_cage;
    struct lua_Page* sweepgcopage_cage;

    TValue pseudotemp;

    TValue registry;
    int registryfree;

    struct lua_jmpbuf* errorjmp;

    uint64_t rngstate;
    uint64_t ptrenckey[4];

    lua_Callbacks cb;

    lua_ExecutionCallbacks ecb;

    alignas(16) uint8_t ecbdata[LUA_EXECUTION_CALLBACK_STORAGE];

    lua_UdataDirectAccessData udatadirect[UTAG_INTERNAL_LIMIT];

    size_t memcatbytes[LUA_MEMORY_CATEGORIES];

    void (*udatagc[LUA_UTAG_LIMIT])(lua_State*, void*);
    lua_UserdataMark udatamark[LUA_UTAG_LIMIT];
    LuaTable* udatamt[LUA_UTAG_LIMIT];

    TValue weakregistry;
    int weakregistryfree;
    int weakregistrytop;
    lua_EmbedderGc embeddergc;

    TString* lightuserdataname[LUA_LUTAG_LIMIT];

    struct LuaTable* udatadirectfields[UTAG_INTERNAL_LIMIT];

    struct Closure* builtinPcall;
    struct Closure* builtinXpcall;

    uint64_t ptrenckeynew[8];
    bool ptrencactive;

    GCStats gcstats;
    uint32_t lastprotoid;

#ifdef LUAI_GCMETRICS
    GCMetrics gcmetrics;
#endif
} global_State;
#endif

#if LUAU_ROBLOX_INTEGRATION
struct lua_State
{
    CommonHeader;
    uint8_t status;
    uint8_t activememcat;
    bool singlestep;
    bool isactive;
    char gap_0[0x1];
    TString* namecall;
    GCObject* gclist;
    LSTATE_STACKSIZE_ENC<int> stacksize;
    int size_ci;
    UpVal* openupval;
    struct RobloxExtraSpace* userdata;
    LuaTable* finalizers;
    unsigned short nCcalls;
    unsigned short baseCcalls;
    unsigned int cachedslot;
    LuaTable* gt;
    CallInfo* end_ci;
    CallInfo* base_ci;
    CallInfo* ci;
    TValue* base;
    global_State* global;
    TValue* top;
    TValue* stack;
    TValue* stack_last;
};
#else
struct lua_State
{
    CommonHeader;
    uint8_t status;

    uint8_t activememcat;

    bool isactive;
    bool singlestep;

    StkId top;
    StkId base;
    global_State* global;
    CallInfo* ci;
    StkId stack_last;
    StkId stack;

    CallInfo* end_ci;
    CallInfo* base_ci;

    int stacksize;
    int size_ci;

    unsigned short nCcalls;
    unsigned short baseCcalls;

    int cachedslot;

    LuaTable* gt;
    UpVal* openupval;
    GCObject* gclist;

    TString* namecall;

    LuaTable* finalizers;

    void* userdata;
};
#endif

union GCObject
{
    GCheader gch;
    struct TString ts;
    struct Udata u;
    struct Closure cl;
    struct LuaTable h;
    struct Proto p;
    struct UpVal uv;
    struct lua_State th;
    struct LuauBuffer buf;
    struct LuauClass lclass;
    struct LuauObject lobject;
    struct LuauVector vec;
};

#define gco2ts(o) check_exp((o)->gch.tt == LUA_TSTRING, &((o)->ts))
#define gco2u(o) check_exp((o)->gch.tt == LUA_TUSERDATA, &((o)->u))
#define gco2cl(o) check_exp((o)->gch.tt == LUA_TFUNCTION, &((o)->cl))
#define gco2h(o) check_exp((o)->gch.tt == LUA_TTABLE, &((o)->h))
#define gco2p(o) check_exp((o)->gch.tt == LUA_TPROTO, &((o)->p))
#define gco2uv(o) check_exp((o)->gch.tt == LUA_TUPVAL, &((o)->uv))
#define gco2th(o) check_exp((o)->gch.tt == LUA_TTHREAD, &((o)->th))
#define gco2buf(o) check_exp((o)->gch.tt == LUA_TBUFFER, &((o)->buf))
#define gco2class(o) check_exp((o)->gch.tt == LUA_TCLASS, &((o)->lclass))
#define gco2object(o) check_exp((o)->gch.tt == LUA_TOBJECT, &((o)->lobject))
#define gco2vec(o) check_exp((o)->gch.tt == LUA_TVECTOR, &((o)->vec))

#define obj2gco(v) check_exp(iscollectable(v), cast_to(GCObject*, (v) + 0))

LUAI_FUNC lua_State* luaE_newthread(lua_State* L);
LUAI_FUNC void luaE_freethread(lua_State* L, lua_State* L1, struct lua_Page* page);

#if LUAU_ROBLOX_INTEGRATION

static_assert(sizeof(void*) == 8, "Supplied layouts require x64");
static_assert(offsetof(global_State, strt) == 0, "global_State.strt offset");
static_assert(offsetof(global_State, GCthreshold) == 16, "global_State.GCthreshold offset");
static_assert(offsetof(global_State, totalbytes) == 24, "global_State.totalbytes offset");
static_assert(offsetof(global_State, currentwhite) == 32, "global_State.currentwhite offset");
static_assert(offsetof(global_State, gcstate) == 33, "global_State.gcstate offset");
static_assert(offsetof(global_State, frealloc) == 40, "global_State.frealloc offset");
static_assert(offsetof(global_State, ud) == 48, "global_State.ud offset");
static_assert(offsetof(global_State, weak) == 56, "global_State.weak offset");
static_assert(offsetof(global_State, grayagain) == 64, "global_State.grayagain offset");
static_assert(offsetof(global_State, gray) == 72, "global_State.gray offset");
static_assert(offsetof(global_State, gcgoal) == 80, "global_State.gcgoal offset");
static_assert(offsetof(global_State, gcstepsize) == 84, "global_State.gcstepsize offset");
static_assert(offsetof(global_State, gcstepmul) == 88, "global_State.gcstepmul offset");
static_assert(offsetof(global_State, freepages) == 96, "global_State.freepages offset");
static_assert(offsetof(global_State, freegcopages) == 416, "global_State.freegcopages offset");
static_assert(offsetof(global_State, sweepgcopage) == 736, "global_State.sweepgcopage offset");
static_assert(offsetof(global_State, mainthread) == 744, "global_State.mainthread offset");
static_assert(offsetof(global_State, allpages) == 752, "global_State.allpages offset");
static_assert(offsetof(global_State, allgcopages) == 760, "global_State.allgcopages offset");
static_assert(offsetof(global_State, uvhead) == 768, "global_State.uvhead offset");
static_assert(offsetof(global_State, mt) == 808, "global_State.mt offset");
static_assert(offsetof(global_State, ttname) == 920, "global_State.ttname offset");
static_assert(offsetof(global_State, tmname) == 1032, "global_State.tmname offset");
static_assert(offsetof(global_State, freegcopages_cage) == 1200, "global_State.freegcopages_cage offset");
static_assert(offsetof(global_State, allgcopages_cage) == 1520, "global_State.allgcopages_cage offset");
static_assert(offsetof(global_State, sweepgcopage_cage) == 1528, "global_State.sweepgcopage_cage offset");
static_assert(offsetof(global_State, errorjmp) == 1536, "global_State.errorjmp offset");
static_assert(offsetof(global_State, cagealloc) == 1544, "global_State.cagealloc offset");
static_assert(offsetof(global_State, pseudotemp) == 1552, "global_State.pseudotemp offset");
static_assert(offsetof(global_State, registry) == 1568, "global_State.registry offset");
static_assert(offsetof(global_State, registryfree) == 1584, "global_State.registryfree offset");
static_assert(offsetof(global_State, cageud) == 1592, "global_State.cageud offset");
static_assert(offsetof(global_State, ptrenckey) == 1600, "global_State.ptrenckey offset");
static_assert(offsetof(global_State, rngstate) == 1632, "global_State.rngstate offset");
static_assert(offsetof(global_State, cb) == 1640, "global_State.cb offset");
static_assert(offsetof(global_State, ecb) == 1752, "global_State.ecb offset");
static_assert(offsetof(global_State, ecbdata) == 1824, "global_State.ecbdata offset");
static_assert(offsetof(global_State, udatadirect) == 2336, "global_State.udatadirect offset");
static_assert(offsetof(global_State, memcatbytes) == 11696, "global_State.memcatbytes offset");
static_assert(offsetof(global_State, udatagc) == 13744, "global_State.udatagc offset");
static_assert(offsetof(global_State, udatamark) == 14768, "global_State.udatamark offset");
static_assert(offsetof(global_State, udatamt) == 15792, "global_State.udatamt offset");
static_assert(offsetof(global_State, weakregistry) == 16816, "global_State.weakregistry offset");
static_assert(offsetof(global_State, weakregistryfree) == 16832, "global_State.weakregistryfree offset");
static_assert(offsetof(global_State, weakregistrytop) == 16836, "global_State.weakregistrytop offset");
static_assert(offsetof(global_State, embeddergc) == 16840, "global_State.embeddergc offset");
static_assert(offsetof(global_State, lightuserdataname) == 16848, "global_State.lightuserdataname offset");

static_assert(sizeof(((global_State*)nullptr)->lightuserdataname) == 2064, "global_State.lightuserdataname size");
static_assert(offsetof(global_State, udatadirectfields) == 18912, "global_State.udatadirectfields offset");
static_assert(offsetof(global_State, builtinPcall) == 19952, "global_State.builtinPcall offset");
static_assert(offsetof(global_State, builtinXpcall) == 19960, "global_State.builtinXpcall offset");
static_assert(offsetof(global_State, ptrenckeynew) == 19968, "global_State.ptrenckeynew offset");
static_assert(offsetof(global_State, ptrencactive) == 20032, "global_State.ptrencactive offset");
static_assert(offsetof(global_State, gcstats) == 20040, "global_State.gcstats offset");
static_assert(offsetof(global_State, lastprotoid) == 20224, "global_State.lastprotoid offset");
#ifdef LUAI_GCMETRICS
static_assert(sizeof(global_State) == 20704, "global_State metrics size");
#else
static_assert(sizeof(global_State) == 20240, "global_State size");
#endif
static_assert(offsetof(lua_State, status) == 3, "lua_State.status offset");
static_assert(offsetof(lua_State, activememcat) == 4, "lua_State.activememcat offset");
static_assert(offsetof(lua_State, singlestep) == 5, "lua_State.singlestep offset");
static_assert(offsetof(lua_State, isactive) == 6, "lua_State.isactive offset");
static_assert(offsetof(lua_State, namecall) == 8, "lua_State.namecall offset");
static_assert(offsetof(lua_State, gclist) == 16, "lua_State.gclist offset");
static_assert(offsetof(lua_State, stacksize) == 24, "lua_State.stacksize offset");
static_assert(offsetof(lua_State, size_ci) == 28, "lua_State.size_ci offset");
static_assert(offsetof(lua_State, openupval) == 32, "lua_State.openupval offset");
static_assert(offsetof(lua_State, userdata) == 40, "lua_State.userdata offset");
static_assert(offsetof(lua_State, finalizers) == 48, "lua_State.finalizers offset");
static_assert(offsetof(lua_State, nCcalls) == 56, "lua_State.nCcalls offset");
static_assert(offsetof(lua_State, baseCcalls) == 58, "lua_State.baseCcalls offset");
static_assert(offsetof(lua_State, cachedslot) == 60, "lua_State.cachedslot offset");
static_assert(offsetof(lua_State, gt) == 64, "lua_State.gt offset");
static_assert(offsetof(lua_State, end_ci) == 72, "lua_State.end_ci offset");
static_assert(offsetof(lua_State, base_ci) == 80, "lua_State.base_ci offset");
static_assert(offsetof(lua_State, ci) == 88, "lua_State.ci offset");
static_assert(offsetof(lua_State, base) == 96, "lua_State.base offset");
static_assert(offsetof(lua_State, global) == 104, "lua_State.global offset");
static_assert(offsetof(lua_State, top) == 112, "lua_State.top offset");
static_assert(offsetof(lua_State, stack) == 120, "lua_State.stack offset");
static_assert(offsetof(lua_State, stack_last) == 128, "lua_State.stack_last offset");
static_assert(sizeof(lua_State) == 136, "lua_State size");
static_assert(offsetof(CallInfo, base) == 0, "CallInfo.base offset");
static_assert(offsetof(CallInfo, func) == 8, "CallInfo.func offset");
static_assert(offsetof(CallInfo, top) == 16, "CallInfo.top offset");
static_assert(offsetof(CallInfo, p) == 24, "CallInfo.p offset");
static_assert(offsetof(CallInfo, nresults) == 40, "CallInfo.nresults offset");
static_assert(offsetof(CallInfo, flags) == 44, "CallInfo.flags offset");
static_assert(sizeof(CallInfo) == 48, "CallInfo size");
static_assert(offsetof(stringtable, hash) == 0, "stringtable.hash offset");
static_assert(offsetof(stringtable, nuse) == 8, "stringtable.nuse offset");
static_assert(offsetof(stringtable, size) == 12, "stringtable.size offset");
static_assert(sizeof(stringtable) == 16, "stringtable size");
#endif
