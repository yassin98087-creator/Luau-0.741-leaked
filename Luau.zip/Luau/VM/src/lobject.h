#pragma once

#include <cstddef>
#include "lua.h"
#include "lcommon.h"

typedef union GCObject GCObject;

#if LUAU_ROBLOX_INTEGRATION

#define CommonHeader \
    uint8_t memcat; \
    uint8_t tt; \
    uint8_t marked
#else
#define CommonHeader \
    uint8_t tt; \
    uint8_t marked; \
    uint8_t memcat
#endif

typedef struct GCheader
{
    CommonHeader;
} GCheader;

typedef union
{
    GCObject* gc;
    void* p;
    double n;
    int b;
    int64_t l;
    float v[2];
} Value;

typedef struct lua_TValue
{
    Value value;
    int extra[LUA_EXTRA_SIZE];
    int tt;
} TValue;

#if LUA_VECTOR_SIZE == 4
#define condvector4(vec4expr, vec3expr) vec4expr
#else
#define condvector4(vec4expr, vec3expr) vec3expr
#endif

#if LUA_VECTOR_DOUBLE == 1
#define condvectordouble(vecdoubleexpr, vecfloatexpr) vecdoubleexpr
#else
#define condvectordouble(vecdoubleexpr, vecfloatexpr) vecfloatexpr
#endif

#define ttisnil(o) (ttype(o) == LUA_TNIL)
#define ttisnumber(o) (ttype(o) == LUA_TNUMBER)
#define ttisinteger(o) (ttype(o) == LUA_TINTEGER)
#define ttisstring(o) (ttype(o) == LUA_TSTRING)
#define ttistable(o) (ttype(o) == LUA_TTABLE)
#define ttisfunction(o) (ttype(o) == LUA_TFUNCTION)
#define ttisboolean(o) (ttype(o) == LUA_TBOOLEAN)
#define ttisuserdata(o) (ttype(o) == LUA_TUSERDATA)
#define ttisthread(o) (ttype(o) == LUA_TTHREAD)
#define ttisbuffer(o) (ttype(o) == LUA_TBUFFER)
#define ttislightuserdata(o) (ttype(o) == LUA_TLIGHTUSERDATA)
#define ttisvector(o) (ttype(o) == LUA_TVECTOR)
#define ttisupval(o) (ttype(o) == LUA_TUPVAL)
#define ttisclass(o) (ttype(o) == LUA_TCLASS)
#define ttisobject(o) (ttype(o) == LUA_TOBJECT)

#define ttype(o) ((o)->tt)
#define gcvalue(o) check_exp(iscollectable(o), (o)->value.gc)
#define pvalue(o) check_exp(ttislightuserdata(o), (o)->value.p)
#define nvalue(o) check_exp(ttisnumber(o), (o)->value.n)
#define lvalue(o) check_exp(ttisinteger(o), (o)->value.l)
#define vvalue(o) check_exp(ttisvector(o), condvectordouble((o)->value.gc->vec.v, (o)->value.v))
#define tsvalue(o) check_exp(ttisstring(o), &(o)->value.gc->ts)
#define uvalue(o) check_exp(ttisuserdata(o), &(o)->value.gc->u)
#define clvalue(o) check_exp(ttisfunction(o), &(o)->value.gc->cl)
#define hvalue(o) check_exp(ttistable(o), &(o)->value.gc->h)
#define bvalue(o) check_exp(ttisboolean(o), (o)->value.b)
#define thvalue(o) check_exp(ttisthread(o), &(o)->value.gc->th)
#define bufvalue(o) check_exp(ttisbuffer(o), &(o)->value.gc->buf)
#define upvalue(o) check_exp(ttisupval(o), &(o)->value.gc->uv)
#define classvalue(o) check_exp(ttisclass(o), &(o)->value.gc->lclass)
#define objectvalue(o) check_exp(ttisobject(o), &(o)->value.gc->lobject)

#define l_isfalse(o) (ttisnil(o) || (ttisboolean(o) && bvalue(o) == 0))

#define lightuserdatatag(o) check_exp(ttislightuserdata(o), (o)->extra[0])

#define LU_TAG_ITERATOR LUA_UTAG_LIMIT

#define checkconsistency(obj) LUAU_ASSERT(!iscollectable(obj) || (ttype(obj) == (obj)->value.gc->gch.tt))

#define checkliveness(g, obj) LUAU_ASSERT(!iscollectable(obj) || ((ttype(obj) == (obj)->value.gc->gch.tt) && !isdead(g, (obj)->value.gc)))

#define setnilvalue(obj) ((obj)->tt = LUA_TNIL)

#define setnvalue(obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.n = (x); \
        i_o->tt = LUA_TNUMBER; \
    }

#define setlvalue(obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.l = (x); \
        i_o->tt = LUA_TINTEGER; \
    }

#if LUA_VECTOR_DOUBLE == 1
#define setvvalue(L, obj, x, y, z, w) \
    { \
        TValue* i_o = (obj); \
        LuauVector* i_vec = luaVec_newvector((L), double(x), double(y), double(z), condvector4(double(w), 0)); \
        i_o->value.gc = cast_to(GCObject*, i_vec); \
        i_o->tt = LUA_TVECTOR; \
        checkliveness((L)->global, i_o); \
    }
#else
#define setvvalue(L, obj, x, y, z, w) \
    { \
        TValue* i_o = (obj); \
        float* i_v = i_o->value.v; \
        i_v[0] = float(x); \
        i_v[1] = float(y); \
        i_v[2] = float(z); \
        condvector4(i_v[3] = float(w), (void)(w)); \
        i_o->tt = LUA_TVECTOR; \
    }
#endif

#define setpvalue(obj, x, tag) \
    { \
        TValue* i_o = (obj); \
        i_o->value.p = (x); \
        i_o->extra[0] = (tag); \
        i_o->tt = LUA_TLIGHTUSERDATA; \
    }

#define setbvalue(obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.b = (x); \
        i_o->tt = LUA_TBOOLEAN; \
    }

#define setsvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TSTRING; \
        checkliveness(L->global, i_o); \
    }

#define setuvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TUSERDATA; \
        checkliveness(L->global, i_o); \
    }

#define setthvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TTHREAD; \
        checkliveness(L->global, i_o); \
    }

#define setbufvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TBUFFER; \
        checkliveness(L->global, i_o); \
    }

#define setclvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TFUNCTION; \
        checkliveness(L->global, i_o); \
    }

#define sethvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TTABLE; \
        checkliveness(L->global, i_o); \
    }

#define setptvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TPROTO; \
        checkliveness(L->global, i_o); \
    }

#define setupvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TUPVAL; \
        checkliveness(L->global, i_o); \
    }

#define setobj(L, obj1, obj2) \
    { \
        const TValue* o2 = (obj2); \
        TValue* o1 = (obj1); \
        *o1 = *o2; \
        checkliveness(L->global, o1); \
    }

#define setclassvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TCLASS; \
        checkliveness(L->global, i_o); \
    }

#define setobjectvalue(L, obj, x) \
    { \
        TValue* i_o = (obj); \
        i_o->value.gc = cast_to(GCObject*, (x)); \
        i_o->tt = LUA_TOBJECT; \
        checkliveness(L->global, i_o); \
    }

#define setobj2s setobj

#define setobjt2t setobj

#define setobj2t setobj

#define setobj2n setobj

#define setobj2class setobj

#define setttype(obj, tt) (ttype(obj) = (tt))

#define iscollectable(o) (ttype(o) >= LUA_TSTRING)

struct DirectFieldResult
{
    lua_State* L;
    TValue* slot;
};

typedef TValue* StkId;

#if LUAU_ROBLOX_INTEGRATION
struct TString
{
    CommonHeader;
    uint16_t atomflag;
    int16_t atom;
    TString* next;
    TSTRING_HASH_ENC<unsigned int> hash;
    unsigned int len;
    char data[1];
};
#else
typedef struct TString
{
    CommonHeader;

    int16_t atom;

    TString* next;

    unsigned int hash;
    unsigned int len;

    char data[1];
} TString;
#endif

#define getstr(ts) (ts)->data
#define svalue(o) getstr(tsvalue(o))

#if LUAU_ROBLOX_INTEGRATION
struct Udata
{
    CommonHeader;
    unsigned char tag;
    int len;
    UDATA_META_ENC<struct LuaTable*> metatable;
    char data[1];
};
#else
typedef struct Udata
{
    CommonHeader;

    uint8_t tag;

    int len;

    struct LuaTable* metatable;

    alignas(8) char data[1];
} Udata;
#endif

typedef struct LuauBuffer
{
    CommonHeader;

    unsigned int len;

    alignas(8) char data[1];
} Buffer;

typedef struct LuauVector
{
    CommonHeader;

    LUA_VECTOR_TYPE v[LUA_VECTOR_SIZE];
} LuauVector;

enum FeedbackVectorSlotKind
{
    CALL_TARGET
};

struct FeedbackVectorSlot
{
    FeedbackVectorSlotKind kind;

    union
    {
        struct
        {
            uint32_t pc;
            uint32_t proto;
            uint32_t hits;
        } call_target;
    };
};

#if LUAU_ROBLOX_INTEGRATION
struct Proto
{
    CommonHeader;
    unsigned char flags;
    unsigned char is_vararg;
    unsigned char numparams;
    unsigned char nups;
    unsigned char maxstacksize;
    PROTO_SOURCE_ENC<TString*> source;
    PROTO_LOCVARS_ENC<struct LocVar*> locvars;
    PROTO_LINEINFO_ENC<unsigned char*> lineinfo;
    PROTO_DEBUGNAME_ENC<TString*> debugname;
    Proto** p;
    GCObject* gclist;
    PROTO_USERDATA_ENC<void*> userdata;
    PROTO_TYPEINFO_ENC<unsigned char*> typeinfo;
    TValue* k;
    unsigned int* code;
    PROTO_DEBUGINSN_ENC<unsigned char*> debuginsn;
    void* execdata;
    uintptr_t exectarget;
    PROTO_ABSLINEINFO_ENC<int*> abslineinfo;
    const Instruction* codeentry;
    PROTO_UPVALUES_ENC<TString**> upvalues;
    int linedefined;
    int sizelineinfo;
    int sizelocvars;
    int bytecodeid;
    int sizetypeinfo;
    int sizeupvalues;
    int sizep;
    int sizek;
    int linegaplog2;
    int sizecode;
    struct FeedbackVectorSlot* feedbackvec;
    int feedbackvecsize;
    int funid;
    Proto* optimized;
    Proto* deoptimized;
    uint64_t cost;
};
#else
typedef struct Proto
{
    CommonHeader;

    uint8_t nups;
    uint8_t numparams;
    uint8_t is_vararg;
    uint8_t maxstacksize;
    uint8_t flags;

    TValue* k;
    Instruction* code;
    struct Proto** p;
    const Instruction* codeentry;

    void* execdata;
    uintptr_t exectarget;

    uint8_t* lineinfo;
    int* abslineinfo;
    struct LocVar* locvars;
    TString** upvalues;
    TString* source;

    TString* debugname;
    uint8_t* debuginsn;

    uint8_t* typeinfo;

    void* userdata;

    GCObject* gclist;

    int sizecode;
    int sizep;
    int sizelocvars;
    int sizeupvalues;
    int sizek;
    int sizelineinfo;
    int linegaplog2;
    int linedefined;
    int bytecodeid;
    int sizetypeinfo;

    FeedbackVectorSlot* feedbackvec;
    uint32_t feedbackvecsize;
    uint32_t funid;
    Proto* optimized;
    Proto* deoptimized;
    uint64_t cost;
} Proto;
#endif

typedef struct LocVar
{
    TString* varname;
    int startpc;
    int endpc;
    uint8_t reg;
} LocVar;

typedef struct UpVal
{
    CommonHeader;
    uint8_t markedopen;

    TValue* v;
    union
    {
        TValue value;
        struct
        {

            struct UpVal* prev;
            struct UpVal* next;

            struct UpVal* threadnext;
        } open;
    } u;
} UpVal;

#define upisopen(up) ((up)->v != &(up)->u.value)

#if LUAU_ROBLOX_INTEGRATION
struct Closure
{
    CommonHeader;
    unsigned char preload;
    unsigned char nupvalues;
    unsigned char stacksize;
    unsigned char isC;
    char gap_0[0x1];
    GCObject* gclist;
    LuaTable* env;
    union
    {
        struct
        {
            TString* debugname;
            CLOSURE_CONT_ENC<lua_Continuation> cont;
            lua_CFunction f;
            TValue upvals[1];
        } c;
        struct
        {
            Proto* p;
            TValue uprefs[1];
        } l;
    };
};
#else
typedef struct Closure
{
    CommonHeader;

    uint8_t isC;
    uint8_t nupvalues;
    uint8_t stacksize;
    uint8_t preload;

    GCObject* gclist;
    struct LuaTable* env;

    union
    {
        struct
        {
            lua_CFunction f;
            lua_Continuation cont;
            TString* debugname;
            TValue upvals[1];
        } c;

        struct
        {
            struct Proto* p;
            TValue uprefs[1];
        } l;
    };
} Closure;
#endif

#define iscfunction(o) (ttype(o) == LUA_TFUNCTION && clvalue(o)->isC)
#define isLfunction(o) (ttype(o) == LUA_TFUNCTION && !clvalue(o)->isC)

typedef struct TKey
{
    ::Value value;
    int extra[LUA_EXTRA_SIZE];
    unsigned tt : 4;
    int next : 28;
} TKey;

typedef struct LuaNode
{
    TValue val;
    TKey key;
} LuaNode;

#define setnodekey(L, node, obj) \
    { \
        LuaNode* n_ = (node); \
        const TValue* i_o = (obj); \
        n_->key.value = i_o->value; \
        memcpy(n_->key.extra, i_o->extra, sizeof(n_->key.extra)); \
        n_->key.tt = i_o->tt; \
        checkliveness(L->global, i_o); \
    }

#define getnodekey(L, obj, node) \
    { \
        TValue* i_o = (obj); \
        const LuaNode* n_ = (node); \
        i_o->value = n_->key.value; \
        memcpy(i_o->extra, n_->key.extra, sizeof(i_o->extra)); \
        i_o->tt = n_->key.tt; \
        checkliveness(L->global, i_o); \
    }

#if LUAU_ROBLOX_INTEGRATION
struct LuaTable
{
    CommonHeader;
    uint8_t tmcache;
    uint8_t lsizenode;
    uint8_t nodemask8;
    uint8_t safeenv;
    uint8_t readonly;
    int sizearray;
    union
    {
        int lastfree;
        int aboundary;
    };
    GCObject* gclist;
    LuaNode* node;
    TValue* array;
    LuaTable* metatable;
};
#else
typedef struct LuaTable
{
    CommonHeader;

    uint8_t tmcache;
    uint8_t readonly;
    uint8_t safeenv;
    uint8_t lsizenode;
    uint8_t nodemask8;

    int sizearray;
    union
    {
        int lastfree;
        int aboundary;
    };

    struct LuaTable* metatable;
    TValue* array;
    LuaNode* node;
    GCObject* gclist;
} LuaTable;
#endif

typedef struct LuauClass
{
    CommonHeader;

    GCObject* gclist;

    TString* name;

    LuauClass* super;

    TValue* staticmembers;

    LuaTable* memberstooffset;

    TString** offsettomember;

    LuaTable* metatable;

    LuaTable* instancemetatable;

    uint32_t numberofinstancemembers;

    uint32_t numberofallmembers;

    bool isopen;

    bool hasuserinitinchain;
} LuauClass;

typedef struct LuauObject
{
    CommonHeader;

    GCObject* gclist;

    LuauClass* lclass;

    uint32_t numberofmembers;

    TValue* members;

} LuauObject;

#define lmod(s, size) (check_exp((size & (size - 1)) == 0, (cast_to(int, (s) & ((size) - 1)))))

#define twoto(x) ((int)(1 << (x)))
#define sizenode(t) (twoto((t)->lsizenode))
#define hasmetacache(t) (((t)->readonly & 2) != 0)
#define getmetacache(t, event) ((t)->array - (1 + (event)))

#if LUAU_ROBLOX_INTEGRATION
#define luaO_nilobject reinterpret_cast<TValue*>(Offsets::Luau::LuaO_NilObject)
#else
#define luaO_nilobject (&luaO_nilobject_)
#endif

LUAI_DATA const TValue luaO_nilobject_;

#define ceillog2(x) (luaO_log2((x) - 1) + 1)

LUAI_FUNC int luaO_log2(unsigned int x);
LUAI_FUNC int luaO_rawequalObj(const TValue* t1, const TValue* t2);
LUAI_FUNC int luaO_rawequalKey(const TKey* t1, const TValue* t2);
LUAI_FUNC int luaO_str2d(const char* s, double* result);
LUAI_FUNC int luaO_str2l(const char* s, int64_t* result, int base = 10);
LUAI_FUNC const char* luaO_pushvfstring(lua_State* L, const char* fmt, va_list argp);
LUAI_FUNC const char* luaO_pushfstring(lua_State* L, const char* fmt, ...);
LUAI_FUNC const char* luaO_chunkid(char* buf, size_t buflen, const char* source, size_t srclen);

#if LUAU_ROBLOX_INTEGRATION

static_assert(sizeof(void*) == 8, "Supplied layouts require x64");
static_assert(offsetof(GCheader, memcat) == 0, "GCheader.memcat offset");
static_assert(offsetof(GCheader, tt) == 1, "GCheader.tt offset");
static_assert(offsetof(GCheader, marked) == 2, "GCheader.marked offset");
static_assert(offsetof(LuaTable, tmcache) == 3, "LuaTable.tmcache offset");
static_assert(offsetof(LuaTable, lsizenode) == 4, "LuaTable.lsizenode offset");
static_assert(offsetof(LuaTable, nodemask8) == 5, "LuaTable.nodemask8 offset");
static_assert(offsetof(LuaTable, safeenv) == 6, "LuaTable.safeenv offset");
static_assert(offsetof(LuaTable, readonly) == 7, "LuaTable.readonly offset");
static_assert(offsetof(LuaTable, sizearray) == 8, "LuaTable.sizearray offset");
static_assert(offsetof(LuaTable, gclist) == 16, "LuaTable.gclist offset");
static_assert(offsetof(LuaTable, node) == 24, "LuaTable.node offset");
static_assert(offsetof(LuaTable, array) == 32, "LuaTable.array offset");
static_assert(offsetof(LuaTable, metatable) == 40, "LuaTable.metatable offset");
static_assert(sizeof(LuaTable) == 48, "LuaTable size");
static_assert(offsetof(Udata, tag) == 3, "Udata.tag offset");
static_assert(offsetof(Udata, len) == 4, "Udata.len offset");
static_assert(offsetof(Udata, metatable) == 8, "Udata.metatable offset");
static_assert(offsetof(Udata, data) == 16, "Udata.data offset");
static_assert(sizeof(Udata) == 24, "Udata size");
static_assert(offsetof(TString, atomflag) == 4, "TString.atomflag offset");
static_assert(offsetof(TString, atom) == 6, "TString.atom offset");
static_assert(offsetof(TString, next) == 8, "TString.next offset");
static_assert(offsetof(TString, hash) == 16, "TString.hash offset");
static_assert(offsetof(TString, len) == 20, "TString.len offset");
static_assert(offsetof(TString, data) == 24, "TString.data offset");
static_assert(sizeof(TString) == 32, "TString size");
static_assert(offsetof(Proto, flags) == 3, "Proto.flags offset");
static_assert(offsetof(Proto, is_vararg) == 4, "Proto.is_vararg offset");
static_assert(offsetof(Proto, numparams) == 5, "Proto.numparams offset");
static_assert(offsetof(Proto, nups) == 6, "Proto.nups offset");
static_assert(offsetof(Proto, maxstacksize) == 7, "Proto.maxstacksize offset");
static_assert(offsetof(Proto, source) == 8, "Proto.source offset");
static_assert(offsetof(Proto, locvars) == 16, "Proto.locvars offset");
static_assert(offsetof(Proto, lineinfo) == 24, "Proto.lineinfo offset");
static_assert(offsetof(Proto, debugname) == 32, "Proto.debugname offset");
static_assert(offsetof(Proto, p) == 40, "Proto.p offset");
static_assert(offsetof(Proto, gclist) == 48, "Proto.gclist offset");
static_assert(offsetof(Proto, userdata) == 56, "Proto.userdata offset");
static_assert(offsetof(Proto, typeinfo) == 64, "Proto.typeinfo offset");
static_assert(offsetof(Proto, k) == 72, "Proto.k offset");
static_assert(offsetof(Proto, code) == 80, "Proto.code offset");
static_assert(offsetof(Proto, debuginsn) == 88, "Proto.debuginsn offset");
static_assert(offsetof(Proto, execdata) == 96, "Proto.execdata offset");
static_assert(offsetof(Proto, exectarget) == 104, "Proto.exectarget offset");
static_assert(offsetof(Proto, abslineinfo) == 112, "Proto.abslineinfo offset");
static_assert(offsetof(Proto, codeentry) == 120, "Proto.codeentry offset");
static_assert(offsetof(Proto, upvalues) == 128, "Proto.upvalues offset");
static_assert(offsetof(Proto, linedefined) == 136, "Proto.linedefined offset");
static_assert(offsetof(Proto, sizelineinfo) == 140, "Proto.sizelineinfo offset");
static_assert(offsetof(Proto, sizelocvars) == 144, "Proto.sizelocvars offset");
static_assert(offsetof(Proto, bytecodeid) == 148, "Proto.bytecodeid offset");
static_assert(offsetof(Proto, sizetypeinfo) == 152, "Proto.sizetypeinfo offset");
static_assert(offsetof(Proto, sizeupvalues) == 156, "Proto.sizeupvalues offset");
static_assert(offsetof(Proto, sizep) == 160, "Proto.sizep offset");
static_assert(offsetof(Proto, sizek) == 164, "Proto.sizek offset");
static_assert(offsetof(Proto, linegaplog2) == 168, "Proto.linegaplog2 offset");
static_assert(offsetof(Proto, sizecode) == 172, "Proto.sizecode offset");
static_assert(offsetof(Proto, feedbackvec) == 176, "Proto.feedbackvec offset");
static_assert(offsetof(Proto, feedbackvecsize) == 184, "Proto.feedbackvecsize offset");
static_assert(offsetof(Proto, funid) == 188, "Proto.funid offset");
static_assert(offsetof(Proto, optimized) == 192, "Proto.optimized offset");
static_assert(offsetof(Proto, deoptimized) == 200, "Proto.deoptimized offset");
static_assert(offsetof(Proto, cost) == 208, "Proto.cost offset");
static_assert(sizeof(Proto) == 216, "Proto size");
static_assert(offsetof(Closure, preload) == 3, "Closure.preload offset");
static_assert(offsetof(Closure, nupvalues) == 4, "Closure.nupvalues offset");
static_assert(offsetof(Closure, stacksize) == 5, "Closure.stacksize offset");
static_assert(offsetof(Closure, isC) == 6, "Closure.isC offset");
static_assert(offsetof(Closure, gclist) == 8, "Closure.gclist offset");
static_assert(offsetof(Closure, env) == 16, "Closure.env offset");
static_assert(sizeof(Closure) == 64, "Closure size");
#endif
