#pragma once

#include <stdint.h>

namespace Luau
{
const char* findConfusable(uint32_t codepoint);
}
